# ExtFASM – FASM 1 Tools per VS Code

Estensione JavaScript per l'assembly **FASM 1 (x86, 16/32/64 bit)**. Specifica del progetto: `dev/docs/ExtFASM_Prompt_Completissimo.txt`.
Ambito attuale: **solo FASM 1 x86** (fasmarm, fasmg e fasm2 sono rimandati). Nessuna funzione richiede AI né rete.

**Lingue**: tutto ciò che l'estensione scrive (pulsanti, impostazioni di `package.json`, messaggi, diagnostiche, hover, pannello) è in **inglese, italiano, francese, spagnolo, polacco e tedesco**, secondo la lingua di VS Code (altre lingue → inglese). I termini tecnici (`format`, `segment`, registri, nomi delle quattro sezioni…) restano inglesi. I cataloghi si generano da un'unica sorgente (`scripts/locales/*.js`) con `npm run locales`, e un test verifica che ogni chiave esista in tutte e sei le lingue.

## Come è stato verificato (e cosa no)

| Cosa | Verifica |
|---|---|
| Comportamento di FASM (formato degli errori, estensioni di output, direttive e flag per formato, opzioni PE incompatibili, `format` duplicato/tardivo, header raw) | **fasm 1.73.35 reale** (`fasm-1.73.35.tgz` dell'autore): misurato con `dev/scripts/probe-fasm-formats.js` → `src/data/fasm-format-matrix.json`; i test confrontano l'esito con quello del fasm reale se presente (`FASM_BIN` o `./fasm_real`), altrimenti saltano |
| Ricostruzione degli header raw (ELF, PE/MZ, MENUET01) | confrontata byte per byte con l'output del fasm reale su 8 sorgenti (`dev/test/fixtures/raw`) |
| Registri CPU, passi, fine del processo | **GDB 15.1 reale** su Linux x86-64 (ELF), anche nei test (saltano senza gdb) |
| Cronologia Git | **git reale** su repository temporanei creati dai test (rinominazioni, eliminazioni, copia di lavoro modificata) |
| Campionamento di CPU/RAM/I/O | processi figli reali, lettura di `/proc` (solo Linux) |
| Pannello «Apri Debugger» | disegnato in **Chromium reale** (Playwright) con dati reali nelle sei lingue; test su CSP, assenza di HTML iniettato, tastiera |
| Il resto dell'estensione dentro **VS Code** | **mai eseguita in VS Code** (non disponibile qui): i test usano un `vscode` finto. Grammatica provata con un tokenizer JS, non con Oniguruma. Da provare con `F5` |
| Sistemi operativi | solo **Linux x86-64** provato. Windows e macOS: non provati (il campionamento per processo e i registri risultano «non supportati» fuori da Linux) |

`npm test` → 168 test, tutti passati in questo ambiente.

## I cinque componenti

1. **Syntax highlighting** – mnemonic (tabelle reali di FASM 1: x86, x87, MMX, SSE…AVX-512, x86-64), registri, direttive, macro/preprocessore, parole di formato, dati, stringhe senza escape, numeri FASM, label, operatori. Colori contestuali per le **syscall**. Istruzioni in 8 famiglie (salti, stack, movimento, aritmetica, logica, FPU, SIMD, sistema), registri in 5 classi, numeri per base, etichette locali. **Macro, `struc`, etichette, dati e costanti definiti nel file** sono colorati sia dove nascono sia dove sono usati (token semantici, disattivabili con `fasm1.semanticSymbols`); i nomi definiti solo in file inclusi non si vedono e restano non colorati. La grammatica nasce da `src/data/fasm-tables.json`, importato da `tables.inc` di fasm 1.73.35.
**Blocchi comprimibili** (folding, `fasm1.folding`): `macro`/`struc` (e `irp`, `rept`, `match`), `if … end if`, `repeat`, `while`, `virtual`, `proc … endp`, `segment`/`section`, ogni etichetta globale fino alla successiva, la **preparazione di una syscall** (le istruzioni che precedono `syscall`/`int` fino all'etichetta o a un'altra syscall), i blocchi di commenti e le regioni `; region` … `; endregion`. Non si riconoscono i blocchi di macro definite dall'utente.

2. **Errori nell'editor** – tre origini, sempre dichiarate: *assemblatore* (messaggio del vero fasm; fasm dà la riga, non la colonna), *analisi statica* (parentesi, stringhe, controlli sul formato: vedi sotto), *syscall*. Un elemento non compreso non è mai dichiarato errato (potrebbe essere una macro).
3. **Pulsanti** – **Assembla**, **Assembla ed esegui**, **Interrompi**, **Apri Debugger**.
4. **Apri Debugger** (Deep Debug) – quattro sezioni, vedi sotto.
5. **Instruction Prediction** – vedi sotto.

### Formato integrato *e* header scritto a mano

Evidenziazione, errori e prediction funzionano sia con `format ELF64 executable 3`, `format PE console`, `format MZ`, `format binary as 'KEK'`… sia con l'header scritto a mano con `db`/`dw`/`dd`/`dq`: ELF (classe, ABI, tipo, macchina, PT_INTERP/PT_DYNAMIC), MZ/PE (`e_lfanew`, firma, `Machine`, magic, sottosistema, DLL), `MENUET01/02/64`. I valori sono ricavati ricostruendo i byte emessi (`dup`, `times`, etichette, `$`, `org`, costanti); un byte non calcolabile resta sconosciuto e non viene indovinato.

**Controlli sul formato** (`src/formatcheck.js`, solo ciò che fasm reale ha rifiutato): direttive assenti nel formato (`section` in ELF eseguibile, `segment` in PE, `extrn` in binary…), flag non ammessi dopo `section`/`segment`, `align` non potenza di due, parole non ammesse dopo `format`, opzioni PE in conflitto (`console gui`), `format` dopo istruzioni/dati o ripetuto, `as '.KEK'` (fasm produce `nome..KEK`) ed estensioni con caratteri non sicuri, header raw a 64 bit con codice mai assemblato a 64 bit. Errore solo al livello più esterno e senza `include`; con `include` diventa avviso; senza `format` nel file (può essere un frammento) non si controlla nulla; nomi ridefiniti con `macro`/`struc`/`equ`/`fix` sono ignorati.

## Percorso di FASM (impostazioni di VS Code)

1. L'estensione legge `fasm1.compilerPath` dalle **impostazioni utente di VS Code** (persistono tra riavvii e aggiornamenti).
2. Se è vuoto prova `fasm` nel `PATH` (senza modificarlo). Se il valore è impostato ma sbagliato **non** ripiega in silenzio sul `PATH`.
3. Se FASM non si trova: avviso con **Inserisci comando…** (basta il nome, es. `fasm`: viene salvato il nome, non un percorso), **Scegli file…** e **Apri impostazioni**. Funzionano i comandi presenti nel `PATH`; gli alias definiti nella shell (`alias fasm=…` in `.bashrc`) non sono visibili all'estensione.
   `gdb` non si imposta: viene cercato nel `PATH` e, se manca, la sezione CPU Registers lo dice.
4. `compilerPath` e `confirmBeforeRun` sono di tipo *machine*: un `.vscode/settings.json` di un repository non può imporli.

Altre impostazioni: `fasm1.includePath` (passata a FASM come `INCLUDE` solo per quel processo), `outputDirectory`, `buildOnSave`, `staticAnalysis`, `syscalls.enabled`, `target.os`, `target.windowsVersion`, `prediction.enabled`, `prediction.level` (`certain` | `likely` | `all`), `deepDebug.enabled`, `deepDebug.sampleIntervalMs`, `deepDebug.maxCommits`.

## Syscall (Linux, FreeBSD, Windows, KolibriOS, MenuetOS)

Riconosce `syscall`, `sysenter` e `int 0x80` / `0x2e` / `0x40` / `0x60`, ricava il **numero** dal codice e lo cerca nella tabella del sistema di destinazione (hover: nome, numero, registri, fonte con commit).

**Destinazione** (in ordine): `fasm1.target.os` → `format` → header raw / firma del programma.

| Formato | Destinazione |
|---|---|
| `format ELF[64] executable 3` | Linux (tabelle x86-64 e i386; `int 0x80` a 64 bit usa la tabella i386) |
| `format ELF[64] executable` (ABI 0) | Linux **assunto** (l'ABI 0 non lo garantisce: l'avviso lo dice) |
| `format ELF[64] executable 9` | FreeBSD (`syscalls.master`) |
| ELF ABI 1, 2, 4–8 | riconosciuti ma **senza tabella**: «non verificabile» |
| `format PE`, `PE64`, `MS COFF`, `MS64 COFF` | Windows; il numero dipende dalla **versione** (`target.windowsVersion`) |
| `format MZ` | DOS: `int 21h` e simili non analizzati |
| `format binary` (anche `as '.KEK'`) o header raw | sconosciuta, salvo impostazione o header/firma `MENUET01/02` (KolibriOS assunto) / `MENUET64` (MenuetOS) |

Categorie: *riconosciuta*, *numero assente nella tabella* e *non valida per il sistema* (avviso), *non verificabile* (suggerimento). Il riconoscimento non dice che la chiamata riuscirà a runtime.

Fonti (in `src/data/*.json`, importatori `dev/scripts/import-*.js`): Linux `syscall_64.tbl`/`syscall_32.tbl` e **prototipi C** (`include/linux/syscalls.h`, 372/405 syscall x86-64 e 423/441 i386 con prototipo; il resto → «numero di argomenti sconosciuto»), numeri Windows per versione (j00ru/windows-syscalls), KolibriOS, FreeBSD. Limiti: MenuetOS senza tabella delle funzioni; Windows senza versione non verificabile; `sysenter` su Linux richiede il vDSO; valori da memoria, `call` o macro non vengono indovinati; per `clone` l'ordine degli argomenti cambia tra architetture (su i386 i nomi non sono mostrati).

## Instruction Prediction

Deterministica (`src/prediction.js`): nessuna AI, nessuna statistica, nessuna percentuale. Ogni proposta ha una **ragione** e una confidenza qualitativa: *certain* (da dati verificati: tabelle, matrice misurata con fasm, specifiche), *likely* (idioma convenzionale o stato dedotto dal blocco corrente), *uncertain* (più scelte ugualmente sensate: sono tutte elencate e marcate). Se il contesto non basta, non propone nulla. Compare come voce di completamento (Ctrl+Spazio) e come testo fantasma solo per la proposta migliore non incerta; si ignora con Esc. Non modifica nulla da sola.

- **Syscall**: numero noto nel blocco → registri degli argomenti ancora da preparare, con nome e tipo dal prototipo reale (`mov rdi, fd`), poi `syscall` / `int 0x80` quando tutti sono pronti. Convenzione e tabella dipendono da sistema, modalità e ABI; con destinazione solo assunta la confidenza scende e lo dice. Windows: nessuna ipotesi.
- **Stack**: `push rbp` → `mov rbp, rsp`; `pop` in ordine inverso; `ret` a pila bilanciata.
- **Flag**: dopo `test r, r` → `jz`/`jnz`; dopo `cmp` → salti condizionati (incerti).
- **Formato integrato**: scheletro (`entry`, `segment readable executable`, `section '.text' …`, etichetta d'ingresso mancante) filtrato su ciò che fasm ha confermato per quel formato.
- **Header raw**: campo successivo di un header ELF32/ELF64 (fino al primo program header), MZ/PE (fino al magic dell'optional header) o MENUET01, con il valore coerente con quanto già scritto (es. `e_machine` secondo `EI_CLASS`) e distinguendo valori fissati dalla specifica, convenzionali e dipendenti dal programma.

Limite: l'analisi segue il flusso lineare del **blocco corrente**; un registro preparato prima di un'etichetta non viene visto.

## Apri Debugger (Deep Debug)

Quattro sezioni, tutte con dati reali o con lo stato esplicito «N/D / non misurabile / non supportato / assente / non rilevabile».

1. **File Commits** – da `git` reale (eseguito senza shell, pager, hook né fsmonitor del repository; richiede area di lavoro attendibile). Asse orizzontale = data del commit; altezza = dimensione del **sorgente** in byte a quel commit; i binari non sono versionati e compaiono solo come dimensione attuale. Rinominazioni seguite, eliminazioni senza dimensione, copia di lavoro con «modifiche non committate», Δ rispetto al precedente, confronto tra due barre (Maiusc+clic). Senza Git/repository/commit lo dice, senza inventare nulla.
2. **File Errors** – lista `Error: Line L | Column C "messaggio"` con **origine** (assemblatore / analisi statica / syscall / esecuzione) e motivo, filtro per origine, salto alla riga. Si aggiorna con le diagnostiche. I problemi a runtime (segnale, codice di uscita ≠ 0) restano separati e senza posizione.
3. **Resources & Performance** – *A statico* (sorgente, binario), *B consumo* e *C osservato* (di **una** prova: «Esegui e misura» assembla, chiede conferma, esegue e campiona `/proc` ogni `sampleIntervalMs`: tempo CPU utente/sistema, picco di memoria residua, byte letti/scritti, file creati/modificati/eliminati, andamento, overhead del campionamento), *D hardware* (modello e core della CPU, RAM del sistema, volume, GPU da `/sys/class/drm` con nome/memoria/utilizzo di sistema se c'è `nvidia-smi`, NPU da `/sys/class/accel`). Un programma troppo breve per un campione risulta «non misurabile», non zero. L'uso per processo di GPU/NPU è sempre «non misurabile». Non è un benchmark: niente punteggi né requisiti minimi.
4. **CPU Registers** – sessione **GDB/MI** reale (`gdb --nx`, senza shell): avvio fermo alla prima istruzione, passo singolo, ×10, continua, ferma. Mostra solo i registri che gdb espone (x86-64 o i386), esadecimale e decimale, flag, PC/SP con i nomi dell'architettura, istruzione corrente, valori cambiati evidenziati. Stato dichiarato: **LIVE** (letti ora dal processo fermo), **SNAPSHOT** (processo finito: ultimi valori), **non disponibile**. Il programma gira davvero, quindi parte solo dopo la tua conferma e in area attendibile; durante il debug il suo output è scartato. Solo Linux/ELF; altri formati e sistemi spiegano perché non sono supportati. ExtFASM non installa mai gdb.

## Uso

- **Assembla questo file** / **Assembla ed esegui** / **Interrompi** / **Apri Debugger**: pulsanti nella barra del titolo e Command Palette (`FASM: …`).
- Output separati: canale **FASM 1** (assemblatore, con codice di uscita) e **FASM 1 – Programma**.
- File prodotto: `<nome sorgente>` + estensione del formato (nessuna per ELF eseguibile, `.exe` PE/MZ, `.o` ELF oggetto, `.bin` binary; `as 'x'` → `nome.x`), nella cartella del sorgente o in `outputDirectory`; non sovrascrive mai `.asm`, `.inc`, `.fas`.
- L'esecuzione parte solo su azione esplicita, chiede conferma (disattivabile), richiede area attendibile, funziona solo per formati nativi del sistema; stdin chiuso.

## Limiti noti

- **Mai eseguita dentro VS Code** (vedi tabella): API reali (provider, webview, comandi) non provate; da verificare con `F5`.
- Solo Linux x86-64 provato; Windows/macOS non provati.
- Le stime di lunghezza delle istruzioni sono `exact`/`estimated`/`unknown`; con SIMD/AVX non si inventano numeri.
- L'estensione si associa a `.asm`, `.inc`, `.fas` e può confliggere con altre estensioni assembly.
- Macro e `\` di continuazione riga non sono interpretate dall'analisi statica.
- Il debugger non ha simboli sorgente (fasm non li emette per ELF): mostra istruzioni e registri, non righe.

## Sviluppo

- `F5` avvia l'Extension Development Host (prova con `TEST/main.asm`).
- `npm test` esegue tutto; `npm run grammar`, `npm run locales`, `npm run sync` rigenerano grammatica, cataloghi lingua e impostazioni derivate dai dati.
- Struttura:

```
ExtFASM/
  extension.js          punto d'ingresso (API di VS Code)
  package.json, package.nls*.json, language-configuration.json
  syntaxes/             grammatica TextMate
  media/                icona e interfaccia del pannello debugger
  src/
    analysis/           folding, symbols, analyzer, formats, formatcheck, rawheader, expression, registers, instructions, prediction
    build/              assembler, runProgram, config, diagnostics
    deepdebug/          git, errors, resources, gdb, mi, panel
    syscalls/           os, tables, engine, expr, presentation
    ui/                 debuggerView
    i18n/               i18n.js e locales/ (en, it, fr, es, pl, de)
    data/               tabelle importate (fasm, syscall, prototipi Linux, matrice dei formati)
  dev/                  test, scripts (importatori, generatori, probe di fasm), docs: non entra nel pacchetto
```
