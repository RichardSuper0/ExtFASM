'use strict';

/**
 * Importa le funzioni di sistema di KolibriOS da due file originali del repository:
 *  - kernel/trunk/core/syscall.inc   -> tabella `servetable2` (quali numeri sono funzioni valide);
 *  - kernel/trunk/docs/sysfuncs.txt  -> titoli delle funzioni e delle sotto-funzioni.
 * Scrive src/data/kolibrios.json.
 *
 * Uso: node dev/scripts/import-kolibrios-syscalls.js <cartella-del-clone-kolibrios>
 */

const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const repo = path.resolve(process.argv[2] || '');
const syscallFile = path.join(repo, 'kernel', 'trunk', 'core', 'syscall.inc');
const docsFile = path.join(repo, 'kernel', 'trunk', 'docs', 'sysfuncs.txt');
if (!process.argv[2] || !fs.existsSync(syscallFile) || !fs.existsSync(docsFile)) {
    console.error('Uso: node dev/scripts/import-kolibrios-syscalls.js <cartella-del-clone-kolibrios>');
    process.exit(1);
}

const git = (...args) => execFileSync('git', ['-C', repo, ...args], { encoding: 'utf8' }).trim();
const [commit, date] = git('log', '-1', '--format=%H|%cI').split('|');

// --- servetable2: ogni riga `dd <gestore>  ; commento` è una funzione, in ordine a partire da 0 -----------
const lines = fs.readFileSync(syscallFile, 'utf8').split(/\r?\n/);
const start = lines.findIndex((line) => /^\s*servetable2:/.test(line));
if (start < 0) {
    throw new Error('servetable2 non trovata in syscall.inc');
}
const functions = [];
let endHandler = null;
for (let index = start + 1; index < lines.length; index += 1) {
    const line = lines[index];
    if (/^\s*endg\b/.test(line)) {
        break;
    }
    const match = /^\s*dd\s+(\w+)\s*(?:;\s*(.*))?$/.exec(line);
    if (!match) {
        continue; // righe `times 255 - ...` e vuote
    }
    const [, handler, comment = ''] = match;
    if (/-1-end application/.test(comment)) {
        endHandler = { handler, comment: comment.trim() };
        continue;
    }
    const undefinedCall = handler === 'undefined_syscall';
    const text = comment.replace(/^\s*-?\d+\s*-\s*/, '').trim();
    functions.push({
        number: functions.length,
        handler: undefinedCall ? null : handler,
        kernelName: undefinedCall ? null : (text || null),
        status: undefinedCall ? (/deprecated/i.test(text) ? 'deprecated' : /free/i.test(text) ? 'free' : 'reserved') : 'active',
        note: undefinedCall ? (text || null) : null
    });
}
if (!endHandler) {
    throw new Error('Voce -1 (sys_end) non trovata nella tabella');
}

// --- sysfuncs.txt: titoli ---------------------------------------------------------------------------------
const titles = new Map();
const subfunctions = new Map();
for (const raw of fs.readFileSync(docsFile, 'utf8').split(/\r?\n/)) {
    const line = raw.replace(/^=+\s*/, '').replace(/\s*=+$/, '').trim();
    let match = /^Function\s+(-?\d+)\s+-\s+(.+?)\.?$/i.exec(line);
    if (match) {
        titles.set(Number(match[1]), match[2].trim());
        continue;
    }
    match = /^Function\s+(-?\d+),\s*subfunctions?\s+([\d,\s]+?)\s*(?:-|,)\s*(.+?)\.?$/i.exec(line);
    if (match) {
        const number = Number(match[1]);
        const list = subfunctions.get(number) || {};
        for (const sub of match[2].split(',').map((item) => item.trim()).filter(Boolean)) {
            list[sub] = match[3].trim();
        }
        subfunctions.set(number, list);
    }
}

for (const entry of functions) {
    entry.title = titles.get(entry.number) || null;
    if (subfunctions.has(entry.number)) {
        entry.subfunctions = subfunctions.get(entry.number);
    }
}
functions.push({
    number: 255,
    alias: -1,
    handler: endHandler.handler,
    kernelName: 'end application',
    status: 'active',
    note: 'eax = -1',
    title: titles.get(-1) || null
});

// Coerenza: ogni funzione descritta nei documenti dovrebbe esistere ed essere attiva nel kernel.
const documentedButNotActive = [...titles.keys()].filter((number) => {
    const entry = functions.find((item) => item.number === (number === -1 ? 255 : number));
    return !entry || entry.status !== 'active';
});

const payload = {
    source: {
        repository: 'https://github.com/KolibriOS/kolibrios',
        commit,
        commitDate: date,
        files: ['kernel/trunk/core/syscall.inc', 'kernel/trunk/docs/sysfuncs.txt']
    },
    note: 'Chiamata: eax = numero della funzione (solo il byte basso: -1 equivale a 255), argomenti in ebx, ecx, edx, esi, edi, ebp; risultato in eax. Istruzioni di ingresso: int 0x40, sysenter, syscall (stessa tabella).',
    documentedButNotActive,
    functions
};
const file = path.join(__dirname, '..', '..', 'src', 'data', 'kolibrios.json');
fs.mkdirSync(path.dirname(file), { recursive: true });
fs.writeFileSync(file, `${JSON.stringify(payload)}\n`);
const count = (status) => functions.filter((entry) => entry.status === status).length;
console.log(`kolibrios.json: ${count('active')} attive, ${count('deprecated')} deprecate, ${count('reserved')} riservate, ${count('free')} libere; ${titles.size} titoli, ${[...subfunctions.values()].reduce((sum, item) => sum + Object.keys(item).length, 0)} sotto-funzioni; documentate ma non attive: ${JSON.stringify(documentedButNotActive)}`);
