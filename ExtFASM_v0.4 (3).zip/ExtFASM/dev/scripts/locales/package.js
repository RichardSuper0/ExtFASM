'use strict';

// Testi di package.json (bottoni, impostazioni): VS Code li sceglie in base alla lingua dell'interfaccia
// tramite package.nls.json (inglese) e package.nls.<lingua>.json. Ordine: it, en, fr, es, pl, de.
const m = (it, en, fr, es, pl, de) => ({ it, en, fr, es, pl, de });
const same = (text) => m(text, text, text, text, text, text);

module.exports = {
    'displayName': same('ExtFASM – FASM 1 Tools'),
    'description': m(
        "Assembly FASM 1 (x86) per VS Code: sintassi, errori nell'editor, assemblaggio ed esecuzione.",
        'FASM 1 (x86) assembly for VS Code: syntax, errors in the editor, assembling and running.',
        "Assembleur FASM 1 (x86) pour VS Code : syntaxe, erreurs dans l'éditeur, assemblage et exécution.",
        'Ensamblador FASM 1 (x86) para VS Code: sintaxis, errores en el editor, ensamblado y ejecución.',
        'Asembler FASM 1 (x86) dla VS Code: składnia, błędy w edytorze, asemblacja i uruchamianie.',
        'FASM-1-Assembler (x86) für VS Code: Syntax, Fehler im Editor, Assemblieren und Ausführen.'),
    'untrusted.description': m(
        "In un'area di lavoro non attendibile l'assemblaggio resta disponibile, ma l'esecuzione dei programmi è disabilitata.",
        'In an untrusted workspace assembling is still available, but running programs is disabled.',
        "Dans un espace de travail non approuvé, l'assemblage reste disponible, mais l'exécution des programmes est désactivée.",
        'En un área de trabajo no confiable el ensamblado sigue disponible, pero la ejecución de programas está desactivada.',
        'W niezaufanym obszarze roboczym asemblacja nadal działa, ale uruchamianie programów jest wyłączone.',
        'In einem nicht vertrauenswürdigen Arbeitsbereich bleibt das Assemblieren verfügbar, das Ausführen von Programmen ist jedoch deaktiviert.'),

    'cmd.build': m('Assembla questo file', 'Assemble this file', 'Assembler ce fichier', 'Ensamblar este archivo', 'Zasembluj ten plik', 'Diese Datei assemblieren'),
    'cmd.buildAndRun': m('Assembla ed esegui', 'Assemble and run', 'Assembler et exécuter', 'Ensamblar y ejecutar', 'Zasembluj i uruchom', 'Assemblieren und ausführen'),
    'cmd.stop': m('Interrompi il programma in esecuzione', 'Stop the running program', "Arrêter le programme en cours d'exécution", 'Detener el programa en ejecución', 'Zatrzymaj uruchomiony program', 'Laufendes Programm beenden'),
    'cmd.debugger': m('Apri Debugger', 'Open Debugger', 'Ouvrir le débogueur', 'Abrir depurador', 'Otwórz debugger', 'Debugger öffnen'),
    'cmd.selectCompiler': m("Scegli l'eseguibile di FASM 1…", 'Choose the FASM 1 executable…', "Choisir l'exécutable de FASM 1…", 'Elegir el ejecutable de FASM 1…', 'Wybierz plik wykonywalny FASM 1…', 'FASM-1-Programmdatei auswählen…'),
    'cmd.openSettings': m('Apri le impostazioni di FASM 1', 'Open the FASM 1 settings', 'Ouvrir les paramètres de FASM 1', 'Abrir la configuración de FASM 1', 'Otwórz ustawienia FASM 1', 'FASM-1-Einstellungen öffnen'),

    'cfg.compilerPath': m(
        "Percorso completo dell'eseguibile di **FASM 1** (`fasm` / `fasm.exe`). Se è vuoto, l'estensione cerca `fasm` nel `PATH` e, se non lo trova, ti chiede di impostarlo qui. Il valore resta salvato nelle impostazioni utente e non viene mai modificato senza una tua scelta.",
        'Full path of the **FASM 1** executable (`fasm` / `fasm.exe`). If empty, the extension looks for `fasm` in the `PATH` and, if it is not found, asks you to set it here. The value stays saved in your user settings and is never changed without your choice.',
        "Chemin complet de l'exécutable **FASM 1** (`fasm` / `fasm.exe`). S'il est vide, l'extension cherche `fasm` dans le `PATH` et, s'il est introuvable, vous demande de le définir ici. La valeur reste enregistrée dans vos paramètres utilisateur et n'est jamais modifiée sans votre choix.",
        'Ruta completa del ejecutable de **FASM 1** (`fasm` / `fasm.exe`). Si está vacía, la extensión busca `fasm` en el `PATH` y, si no lo encuentra, te pide que lo configures aquí. El valor se conserva en tu configuración de usuario y nunca se modifica sin tu decisión.',
        'Pełna ścieżka do pliku wykonywalnego **FASM 1** (`fasm` / `fasm.exe`). Jeśli jest pusta, rozszerzenie szuka `fasm` w `PATH`, a gdy go nie znajdzie, prosi o ustawienie go tutaj. Wartość pozostaje zapisana w ustawieniach użytkownika i nigdy nie jest zmieniana bez Twojej decyzji.',
        'Vollständiger Pfad der **FASM-1**-Programmdatei (`fasm` / `fasm.exe`). Ist er leer, sucht die Erweiterung `fasm` im `PATH` und bittet dich, ihn hier festzulegen, falls sie ihn nicht findet. Der Wert bleibt in deinen Benutzereinstellungen gespeichert und wird nie ohne deine Entscheidung geändert.'),
    'cfg.includePath': m(
        "Cartelle dove FASM cerca i file di `include` (come la variabile d'ambiente `INCLUDE`). Valgono solo per il processo di FASM: l'ambiente di sistema non viene modificato. Supporta `${workspaceFolder}` e `${fileDirname}`.",
        'Folders where FASM looks for `include` files (like the `INCLUDE` environment variable). They apply only to the FASM process: the system environment is not modified. Supports `${workspaceFolder}` and `${fileDirname}`.',
        "Dossiers où FASM cherche les fichiers `include` (comme la variable d'environnement `INCLUDE`). Ils ne valent que pour le processus FASM : l'environnement du système n'est pas modifié. Prend en charge `${workspaceFolder}` et `${fileDirname}`.",
        'Carpetas donde FASM busca los archivos `include` (como la variable de entorno `INCLUDE`). Solo valen para el proceso de FASM: el entorno del sistema no se modifica. Admite `${workspaceFolder}` y `${fileDirname}`.',
        'Foldery, w których FASM szuka plików `include` (jak zmienna środowiskowa `INCLUDE`). Dotyczą tylko procesu FASM: środowisko systemowe nie jest modyfikowane. Obsługuje `${workspaceFolder}` i `${fileDirname}`.',
        'Ordner, in denen FASM nach `include`-Dateien sucht (wie die Umgebungsvariable `INCLUDE`). Sie gelten nur für den FASM-Prozess: Die Systemumgebung wird nicht verändert. Unterstützt `${workspaceFolder}` und `${fileDirname}`.'),
    'cfg.outputDirectory': m(
        "Cartella dei file prodotti. Vuota = la cartella del sorgente. Un percorso relativo parte dalla cartella del sorgente; supporta `${workspaceFolder}` e `${fileDirname}`. Il nome è quello del sorgente con l'estensione del formato (`.exe`, `.o`, nessuna per ELF eseguibile…). Non sovrascrive mai file `.asm`, `.inc` o `.fas`.",
        'Folder for the generated files. Empty = the source folder. A relative path starts from the source folder; supports `${workspaceFolder}` and `${fileDirname}`. The name is the source name with the format extension (`.exe`, `.o`, none for executable ELF…). It never overwrites `.asm`, `.inc` or `.fas` files.',
        "Dossier des fichiers générés. Vide = le dossier de la source. Un chemin relatif part du dossier de la source ; prend en charge `${workspaceFolder}` et `${fileDirname}`. Le nom est celui de la source avec l'extension du format (`.exe`, `.o`, aucune pour un ELF exécutable…). N'écrase jamais les fichiers `.asm`, `.inc` ou `.fas`.",
        'Carpeta de los archivos generados. Vacía = la carpeta del fuente. Una ruta relativa parte de la carpeta del fuente; admite `${workspaceFolder}` y `${fileDirname}`. El nombre es el del fuente con la extensión del formato (`.exe`, `.o`, ninguna para ELF ejecutable…). Nunca sobrescribe archivos `.asm`, `.inc` ni `.fas`.',
        'Folder plików wynikowych. Pusty = folder pliku źródłowego. Ścieżka względna zaczyna się od folderu źródła; obsługuje `${workspaceFolder}` i `${fileDirname}`. Nazwa to nazwa źródła z rozszerzeniem formatu (`.exe`, `.o`, brak dla wykonywalnego ELF…). Nigdy nie nadpisuje plików `.asm`, `.inc` ani `.fas`.',
        'Ordner der erzeugten Dateien. Leer = der Ordner der Quelldatei. Ein relativer Pfad beginnt im Ordner der Quelldatei; unterstützt `${workspaceFolder}` und `${fileDirname}`. Der Name ist der der Quelldatei mit der Formaterweiterung (`.exe`, `.o`, keine bei ausführbarem ELF…). Überschreibt nie `.asm`-, `.inc`- oder `.fas`-Dateien.'),
    'cfg.buildOnSave': m(
        'Assembla il file FASM ogni volta che viene salvato (non lo esegue).',
        'Assemble the FASM file every time it is saved (does not run it).',
        'Assemble le fichier FASM à chaque enregistrement (ne l\'exécute pas).',
        'Ensambla el archivo FASM cada vez que se guarda (no lo ejecuta).',
        'Asembluje plik FASM przy każdym zapisie (nie uruchamia go).',
        'Assembliert die FASM-Datei bei jedem Speichern (führt sie nicht aus).'),
    'cfg.confirmBeforeRun': m(
        'Chiede conferma prima di eseguire un programma appena assemblato.',
        'Ask for confirmation before running a freshly assembled program.',
        "Demande confirmation avant d'exécuter un programme qui vient d'être assemblé.",
        'Pide confirmación antes de ejecutar un programa recién ensamblado.',
        'Prosi o potwierdzenie przed uruchomieniem świeżo zasemblowanego programu.',
        'Fragt vor dem Ausführen eines frisch assemblierten Programms nach.'),
    'cfg.staticAnalysis': m(
        "Mostra mentre scrivi gli avvisi dell'analisi statica (delimitatori, stringhe non chiuse, suggerimenti).",
        'Show static analysis warnings as you type (delimiters, unclosed strings, hints).',
        "Affiche pendant la saisie les avertissements de l'analyse statique (délimiteurs, chaînes non fermées, suggestions).",
        'Muestra mientras escribes los avisos del análisis estático (delimitadores, cadenas sin cerrar, sugerencias).',
        'Pokazuje podczas pisania ostrzeżenia analizy statycznej (ograniczniki, niezamknięte łańcuchy, wskazówki).',
        'Zeigt beim Tippen die Warnungen der statischen Analyse an (Begrenzer, nicht geschlossene Zeichenketten, Hinweise).'),
    'cfg.syscalls.enabled': m(
        'Riconosce le chiamate di sistema (`syscall`, `int 0x80`, `int 0x2e`, `int 0x40`, `int 0x60`, `sysenter`), le colora e mostra nome e convenzione al passaggio del mouse. Il numero è letto dal codice solo quando è determinabile in modo sicuro; altrimenti la chiamata è segnata come *non verificabile*.',
        'Recognizes system calls (`syscall`, `int 0x80`, `int 0x2e`, `int 0x40`, `int 0x60`, `sysenter`), colors them and shows name and convention on hover. The number is read from the code only when it can be determined safely; otherwise the call is marked as *unverifiable*.',
        "Reconnaît les appels système (`syscall`, `int 0x80`, `int 0x2e`, `int 0x40`, `int 0x60`, `sysenter`), les colore et affiche le nom et la convention au survol. Le numéro n'est lu dans le code que s'il peut être déterminé avec certitude ; sinon l'appel est marqué comme *non vérifiable*.",
        'Reconoce las llamadas al sistema (`syscall`, `int 0x80`, `int 0x2e`, `int 0x40`, `int 0x60`, `sysenter`), las colorea y muestra nombre y convención al pasar el ratón. El número se lee del código solo cuando se puede determinar con seguridad; si no, la llamada se marca como *no verificable*.',
        'Rozpoznaje wywołania systemowe (`syscall`, `int 0x80`, `int 0x2e`, `int 0x40`, `int 0x60`, `sysenter`), koloruje je i pokazuje nazwę oraz konwencję po najechaniu myszą. Numer jest odczytywany z kodu tylko wtedy, gdy można go ustalić pewnie; w przeciwnym razie wywołanie jest oznaczone jako *niemożliwe do zweryfikowania*.',
        'Erkennt Systemaufrufe (`syscall`, `int 0x80`, `int 0x2e`, `int 0x40`, `int 0x60`, `sysenter`), färbt sie ein und zeigt Name und Konvention beim Darüberfahren an. Die Nummer wird nur dann aus dem Code gelesen, wenn sie sicher bestimmbar ist; andernfalls wird der Aufruf als *nicht überprüfbar* markiert.'),
    'cfg.target.os': m(
        'Sistema operativo di destinazione delle chiamate di sistema. `auto` lo ricava dalla direttiva `format`; impostalo se il formato non lo dice (`format binary`, ELF oggetto).',
        'Target operating system of the system calls. `auto` derives it from the `format` directive; set it if the format does not tell (`format binary`, ELF object).',
        "Système d'exploitation cible des appels système. `auto` le déduit de la directive `format` ; définissez-le si le format ne l'indique pas (`format binary`, objet ELF).",
        'Sistema operativo de destino de las llamadas al sistema. `auto` lo deduce de la directiva `format`; configúralo si el formato no lo indica (`format binary`, objeto ELF).',
        'Docelowy system operacyjny wywołań systemowych. `auto` ustala go z dyrektywy `format`; ustaw go, gdy format tego nie określa (`format binary`, obiekt ELF).',
        'Zielbetriebssystem der Systemaufrufe. `auto` leitet es aus der `format`-Direktive ab; lege es fest, wenn das Format es nicht angibt (`format binary`, ELF-Objekt).'),
    'cfg.target.os.auto': m('Dal formato (`format ELF executable 3`, `format PE…`, firma `MENUET01`…)', 'From the format (`format ELF executable 3`, `format PE…`, `MENUET01` signature…)', 'Depuis le format (`format ELF executable 3`, `format PE…`, signature `MENUET01`…)', 'Desde el formato (`format ELF executable 3`, `format PE…`, firma `MENUET01`…)', 'Z formatu (`format ELF executable 3`, `format PE…`, sygnatura `MENUET01`…)', 'Aus dem Format (`format ELF executable 3`, `format PE…`, Signatur `MENUET01`…)'),
    'cfg.target.os.linux': m('Linux (tabelle x86-64 e i386)', 'Linux (x86-64 and i386 tables)', 'Linux (tables x86-64 et i386)', 'Linux (tablas x86-64 e i386)', 'Linux (tabele x86-64 i i386)', 'Linux (x86-64- und i386-Tabellen)'),
    'cfg.target.os.freebsd': m('FreeBSD (syscalls.master)', 'FreeBSD (syscalls.master)', 'FreeBSD (syscalls.master)', 'FreeBSD (syscalls.master)', 'FreeBSD (syscalls.master)', 'FreeBSD (syscalls.master)'),
    'cfg.target.os.windows': m('Windows (numeri per versione)', 'Windows (numbers per version)', 'Windows (numéros par version)', 'Windows (números por versión)', 'Windows (numery według wersji)', 'Windows (Nummern je Version)'),
    'cfg.target.os.kolibrios': same('KolibriOS (`int 0x40`)'),
    'cfg.target.os.menuetos': m('MenuetOS (ingressi controllati; tabella delle funzioni non inclusa)', 'MenuetOS (entry points checked; function table not included)', "MenuetOS (points d'entrée vérifiés ; table des fonctions non incluse)", 'MenuetOS (puntos de entrada comprobados; tabla de funciones no incluida)', 'MenuetOS (sprawdzane punkty wejścia; tabela funkcji nie jest dołączona)', 'MenuetOS (Einsprungpunkte geprüft; Funktionstabelle nicht enthalten)'),
    'cfg.target.windowsVersion': m(
        'Versione di Windows per cui verificare i numeri delle syscall (`syscall`/`int 0x2e`). I numeri **cambiano a ogni versione**: senza questa impostazione sono segnalati come non verificabili.',
        'Windows version against which to verify syscall numbers (`syscall`/`int 0x2e`). Numbers **change with every version**: without this setting they are reported as unverifiable.',
        'Version de Windows pour laquelle vérifier les numéros de syscall (`syscall`/`int 0x2e`). Les numéros **changent à chaque version** : sans ce paramètre, ils sont signalés comme non vérifiables.',
        'Versión de Windows con la que verificar los números de syscall (`syscall`/`int 0x2e`). Los números **cambian en cada versión**: sin esta configuración se indican como no verificables.',
        'Wersja Windows, względem której weryfikowane są numery syscall (`syscall`/`int 0x2e`). Numery **zmieniają się w każdej wersji**: bez tego ustawienia są zgłaszane jako niemożliwe do zweryfikowania.',
        'Windows-Version, gegen die die Syscall-Nummern geprüft werden (`syscall`/`int 0x2e`). Die Nummern **ändern sich mit jeder Version**: Ohne diese Einstellung werden sie als nicht überprüfbar gemeldet.'),
    'cfg.winver.none': m('Non specificata: i numeri di Windows non sono verificabili', 'Not specified: Windows numbers cannot be verified', 'Non spécifiée : les numéros Windows ne sont pas vérifiables', 'Sin especificar: los números de Windows no se pueden verificar', 'Nie podano: numerów Windows nie można zweryfikować', 'Nicht angegeben: Windows-Nummern sind nicht überprüfbar'),

    'token.syscall': m('Chiamata di sistema in codice FASM 1', 'System call in FASM 1 code', 'Appel système dans du code FASM 1', 'Llamada al sistema en código FASM 1', 'Wywołanie systemowe w kodzie FASM 1', 'Systemaufruf in FASM-1-Code'),
    'token.valid': m('Syscall riconosciuta nella tabella del sistema di destinazione', 'Syscall found in the target system table', 'Syscall trouvée dans la table du système cible', 'Syscall encontrada en la tabla del sistema de destino', 'Syscall znaleziony w tabeli systemu docelowego', 'Syscall in der Tabelle des Zielsystems gefunden'),
    'token.unknown': m('Numero assente nella tabella del sistema di destinazione', 'Number missing from the target system table', 'Numéro absent de la table du système cible', 'Número ausente en la tabla del sistema de destino', 'Numer nieobecny w tabeli systemu docelowego', 'Nummer fehlt in der Tabelle des Zielsystems'),
    'token.invalid': m('Syscall non valida per il sistema di destinazione', 'Syscall not valid for the target system', 'Syscall non valide pour le système cible', 'Syscall no válida para el sistema de destino', 'Syscall nieprawidłowy dla systemu docelowego', 'Syscall für das Zielsystem ungültig'),
    'token.unverifiable': m('Syscall non verificabile (numero non determinabile, tabella assente o versione mancante)', 'Unverifiable syscall (number cannot be determined, table missing or version missing)', 'Syscall non vérifiable (numéro indéterminable, table absente ou version manquante)', 'Syscall no verificable (número indeterminable, tabla ausente o versión faltante)', 'Syscall niemożliwy do zweryfikowania (nie da się ustalić numeru, brak tabeli lub wersji)', 'Syscall nicht überprüfbar (Nummer nicht bestimmbar, Tabelle oder Version fehlt)'),
    'cfg.prediction.enabled': m('Abilita Instruction Prediction (suggerisce la riga successiva in modo deterministico, senza AI).', 'Enable Instruction Prediction (suggests the next line deterministically, without AI).', "Active Instruction Prediction (suggère la ligne suivante de façon déterministe, sans IA).", 'Activa Instruction Prediction (sugiere la línea siguiente de forma determinista, sin IA).', 'Włącza Instruction Prediction (deterministycznie sugeruje następną linię, bez AI).', 'Aktiviert Instruction Prediction (schlägt die nächste Zeile deterministisch vor, ohne KI).'),
    'cfg.prediction.level': m('Quali suggerimenti mostrare, in base alla confidenza.', 'Which suggestions to show, by confidence.', 'Quelles suggestions afficher, selon la confiance.', 'Qué sugerencias mostrar, según la confianza.', 'Które sugestie pokazywać, według pewności.', 'Welche Vorschläge je nach Sicherheit angezeigt werden.'),
    'cfg.prediction.level.certain': m('Solo suggerimenti ricavati da dati di riferimento verificati.', 'Only suggestions derived from verified reference data.', 'Uniquement les suggestions issues de données de référence vérifiées.', 'Solo sugerencias derivadas de datos de referencia verificados.', 'Tylko sugestie oparte na zweryfikowanych danych referencyjnych.', 'Nur Vorschläge aus verifizierten Referenzdaten.'),
    'cfg.prediction.level.likely': m('Anche gli idiomi convenzionali dedotti dal blocco corrente.', 'Also conventional idioms inferred from the current block.', 'Aussi les idiomes conventionnels déduits du bloc courant.', 'También idiomas convencionales deducidos del bloque actual.', 'Także konwencjonalne idiomy wywnioskowane z bieżącego bloku.', 'Auch übliche Idiome, abgeleitet aus dem aktuellen Block.'),
    'cfg.prediction.level.all': m('Anche le proposte incerte (più scelte ugualmente sensate).', 'Also uncertain proposals (several equally sensible choices).', 'Aussi les propositions incertaines (plusieurs choix aussi sensés).', 'También propuestas inciertas (varias opciones igual de razonables).', 'Także niepewne propozycje (kilka równie sensownych wyborów).', 'Auch unsichere Vorschläge (mehrere gleich sinnvolle Möglichkeiten).'),
    'cfg.folding': m('Permette di comprimere macro, if/repeat/while, segment/section, etichette, la preparazione delle syscall e i blocchi di commenti.', 'Lets you fold macros, if/repeat/while, segment/section, labels, syscall setup and comment blocks.', 'Permet de replier macros, if/repeat/while, segment/section, étiquettes, préparation des syscalls et blocs de commentaires.', 'Permite plegar macros, if/repeat/while, segment/section, etiquetas, la preparación de syscalls y bloques de comentarios.', 'Umożliwia zwijanie makr, if/repeat/while, segment/section, etykiet, przygotowania syscalli i bloków komentarzy.', 'Ermöglicht das Einklappen von Makros, if/repeat/while, segment/section, Labels, Syscall-Vorbereitung und Kommentarblöcken.'),
    'cfg.semanticSymbols': m('Colora macro, etichette, dati e costanti definiti nel file (e dove vengono usati).', 'Highlights macros, labels, data and constants defined in the file (and where they are used).', 'Colore les macros, étiquettes, données et constantes définies dans le fichier (et leurs usages).', 'Resalta macros, etiquetas, datos y constantes definidos en el archivo (y dónde se usan).', 'Wyróżnia makra, etykiety, dane i stałe zdefiniowane w pliku (oraz ich użycia).', 'Hebt im Datei definierte Makros, Labels, Daten und Konstanten hervor (und ihre Verwendungen).'),
    'cfg.deepDebug.enabled': m("Abilita l'Apri Debugger (cronologia Git, errori, risorse, registri).", 'Enable the Open Debugger (Git history, errors, resources, registers).', "Active l'ouverture du débogueur (historique Git, erreurs, ressources, registres).", 'Activa Abrir depurador (historial de Git, errores, recursos, registros).', 'Włącza Otwórz debuger (historia Git, błędy, zasoby, rejestry).', 'Aktiviert „Debugger öffnen“ (Git-Verlauf, Fehler, Ressourcen, Register).'),
    'cfg.deepDebug.sampleIntervalMs': m('Intervallo di campionamento delle risorse in millisecondi (più basso = più dettaglio, più overhead).', 'Resource sampling interval in milliseconds (lower = more detail, more overhead).', "Intervalle d'échantillonnage des ressources en millisecondes (plus bas = plus de détail, plus de surcoût).", 'Intervalo de muestreo de recursos en milisegundos (menor = más detalle, más sobrecarga).', 'Interwał próbkowania zasobów w milisekundach (mniej = więcej szczegółów, większy narzut).', 'Abtastintervall der Ressourcen in Millisekunden (kleiner = mehr Detail, mehr Overhead).'),
    'cfg.deepDebug.maxCommits': m('Numero massimo di commit Git letti per il file (sezione File Commits).', 'Maximum number of Git commits read for the file (File Commits section).', 'Nombre maximal de commits Git lus pour le fichier (section File Commits).', 'Número máximo de commits de Git leídos para el archivo (sección File Commits).', 'Maksymalna liczba commitów Git odczytywanych dla pliku (sekcja File Commits).', 'Maximale Anzahl gelesener Git-Commits für die Datei (Abschnitt File Commits).')
};
