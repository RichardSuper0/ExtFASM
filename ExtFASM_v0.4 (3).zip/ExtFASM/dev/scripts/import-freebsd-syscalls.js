'use strict';

/**
 * Importa sys/kern/syscalls.master di FreeBSD (stessa tabella per amd64 e i386) in src/data/freebsd.json.
 * Uso: node dev/scripts/import-freebsd-syscalls.js <cartella-del-clone-freebsd-src>
 */

const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const repo = path.resolve(process.argv[2] || '');
const masterFile = path.join(repo, 'sys', 'kern', 'syscalls.master');
if (!process.argv[2] || !fs.existsSync(masterFile)) {
    console.error('Uso: node dev/scripts/import-freebsd-syscalls.js <cartella-del-clone-freebsd-src>');
    process.exit(1);
}

const git = (...args) => execFileSync('git', ['-C', repo, ...args], { encoding: 'utf8' }).trim();
const [commit, date] = git('log', '-1', '--format=%H|%cI').split('|');

const lines = fs.readFileSync(masterFile, 'utf8').split(/\r?\n/);
const syscalls = [];
for (let index = 0; index < lines.length; index += 1) {
    const match = /^(\d+)\s+(\w+)\s+([A-Z0-9|]+)\s*(.*)$/.exec(lines[index]);
    if (!match) {
        continue;
    }
    const [, number, , type, rest] = match;
    const flags = type.split('|');
    const kind = flags[0];
    let name = null;

    if (kind === 'OBSOL' || kind === 'UNIMPL' || kind === 'RESERVED') {
        name = rest.trim().split(/\s+/)[0] || null;
    } else {
        // Prototipo `{ tipo nome(args); }` su una o più righe: si prende l'identificatore prima di `(`.
        let prototype = rest;
        let cursor = index;
        while (!/}/.test(prototype) && cursor + 1 < lines.length && cursor - index < 40) {
            cursor += 1;
            prototype += ` ${lines[cursor]}`;
        }
        const proto = /\{\s*[^()]*?\b(\w+)\s*\(/.exec(prototype);
        name = proto ? proto[1] : null;
        const alias = /\}\s*(\w+)/.exec(prototype);
        if (alias && alias[1] !== 'NORETURN') {
            name = name; // l'alias dopo `}` è il nome alternativo della chiamata, non ci serve
        }
    }
    syscalls.push({
        number: Number(number),
        name,
        type: kind,
        flags: flags.slice(1),
        noreturn: flags.includes('NORETURN')
    });
}

const payload = {
    source: {
        repository: 'https://github.com/freebsd/freebsd-src',
        commit,
        commitDate: date,
        file: 'sys/kern/syscalls.master'
    },
    note: 'amd64: `syscall`, numero in rax, argomenti in rdi, rsi, rdx, r10, r8, r9. i386: `int 0x80`, numero in eax, argomenti sullo STACK. Tipi: STD/NOSTD/NODEF/NOARGS/NOPROTO = esistono; COMPATn = solo con le opzioni di compatibilità; OBSOL/UNIMPL/RESERVED = numero non utilizzabile.',
    syscalls
};
const file = path.join(__dirname, '..', '..', 'src', 'data', 'freebsd.json');
fs.mkdirSync(path.dirname(file), { recursive: true });
fs.writeFileSync(file, `${JSON.stringify(payload)}\n`);
const kinds = {};
syscalls.forEach((entry) => { kinds[entry.type] = (kinds[entry.type] || 0) + 1; });
const unnamed = syscalls.filter((entry) => !entry.name).map((entry) => entry.number);
console.log(`freebsd.json: ${syscalls.length} voci`, JSON.stringify(kinds), 'senza nome:', JSON.stringify(unnamed));
