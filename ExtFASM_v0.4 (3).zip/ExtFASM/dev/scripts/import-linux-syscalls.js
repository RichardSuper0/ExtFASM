'use strict';

/**
 * Importa le tabelle ufficiali delle syscall x86 del kernel Linux (arch/x86/entry/syscalls/*.tbl)
 * in src/data/linux-x86_64.json e src/data/linux-i386.json, con commit e data di provenienza.
 *
 * Uso: node dev/scripts/import-linux-syscalls.js <cartella-del-clone-linux>
 */

const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const repo = path.resolve(process.argv[2] || '');
const tableDirectory = path.join(repo, 'arch', 'x86', 'entry', 'syscalls');
if (!process.argv[2] || !fs.existsSync(tableDirectory)) {
    console.error('Uso: node dev/scripts/import-linux-syscalls.js <cartella-del-clone-linux>');
    process.exit(1);
}

const git = (...args) => execFileSync('git', ['-C', repo, ...args], { encoding: 'utf8' }).trim();
const [commit, date] = git('log', '-1', '--format=%H|%cI').split('|');

function parseTable(fileName) {
    const entries = [];
    for (const line of fs.readFileSync(path.join(tableDirectory, fileName), 'utf8').split(/\r?\n/)) {
        if (!line.trim() || line.trimStart().startsWith('#')) {
            continue;
        }
        const [number, abi, name, entry, ...rest] = line.trim().split(/\s+/);
        entries.push({
            number: Number(number),
            abi,
            name,
            entry: entry && entry !== '-' ? entry : null,
            noreturn: rest.includes('noreturn')
        });
    }
    return entries;
}

function write(target, table, extra) {
    const file = path.join(__dirname, '..', '..', 'src', 'data', target);
    fs.mkdirSync(path.dirname(file), { recursive: true });
    const payload = {
        source: { repository: 'https://github.com/torvalds/linux', commit, commitDate: date, file: `arch/x86/entry/syscalls/${table}` },
        ...extra,
        syscalls: parseTable(table)
    };
    fs.writeFileSync(file, `${JSON.stringify(payload)}\n`);
    console.log(`${target}: ${payload.syscalls.length} syscall (commit ${commit.slice(0, 12)})`);
}

write('linux-x86_64.json', 'syscall_64.tbl', {
    note: 'abi: "common" e "64" sono validi per x86-64 nativo; "x32" vale solo per l\'ABI x32 (numeri con bit 30 impostato).'
});
write('linux-i386.json', 'syscall_32.tbl', {
    note: 'Convenzione int 0x80 (e sysenter/vdso): numero in eax, argomenti in ebx, ecx, edx, esi, edi, ebp.'
});
