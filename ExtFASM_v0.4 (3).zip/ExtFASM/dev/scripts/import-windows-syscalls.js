'use strict';

/**
 * Importa le tabelle delle syscall di Windows raccolte da j00ru/windows-syscalls
 * (ntoskrnl.exe e win32k.sys, x86 e x64, per ogni versione) in src/data/windows-<arch>.json.
 * Formato compatto: un elenco di nomi condiviso e, per ogni versione, gli indici dei nomi
 * ordinati per numero di syscall (numero = base + posizione).
 *
 * Uso: node dev/scripts/import-windows-syscalls.js <cartella-del-clone-windows-syscalls>
 */

const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const repo = path.resolve(process.argv[2] || '');
if (!process.argv[2] || !fs.existsSync(path.join(repo, 'x64', 'json'))) {
    console.error('Uso: node dev/scripts/import-windows-syscalls.js <cartella-del-clone-windows-syscalls>');
    process.exit(1);
}

const git = (...args) => execFileSync('git', ['-C', repo, ...args], { encoding: 'utf8' }).trim();
const [commit, date] = git('log', '-1', '--format=%H|%cI').split('|');

/** "Windows 11 and Server" + "11 23H2" -> "Windows 11 23H2"; "Windows 10" + "22H2" -> "Windows 10 22H2". */
function label(family, version) {
    if (family === 'Windows 11 and Server') {
        return `Windows ${version}`;
    }
    return `${family} ${version}`;
}

function build(arch, service) {
    const perSystem = JSON.parse(fs.readFileSync(path.join(repo, arch, 'json', `${service}-per-system.json`), 'utf8'));
    const names = [];
    const nameIndex = new Map();
    const systems = {};
    let base = null;

    for (const [family, versions] of Object.entries(perSystem)) {
        for (const [version, table] of Object.entries(versions)) {
            const entries = Object.entries(table).sort((a, b) => a[1] - b[1]);
            const first = entries[0][1];
            base = base === null ? first : base;
            if (first !== base) {
                throw new Error(`${arch}/${service} ${family} ${version}: base ${first}, atteso ${base}`);
            }
            const indexes = [];
            for (const [name, number] of entries) {
                const position = number - base;
                if (indexes[position] !== undefined) {
                    throw new Error(`${arch}/${service} ${family} ${version}: numero ${number} duplicato`);
                }
                if (!nameIndex.has(name)) {
                    nameIndex.set(name, names.length);
                    names.push(name);
                }
                indexes[position] = nameIndex.get(name);
            }
            // Eventuali buchi nella numerazione restano null: il numero esiste ma il nome è sconosciuto.
            for (let position = 0; position < indexes.length; position += 1) {
                if (indexes[position] === undefined) {
                    indexes[position] = null;
                }
            }
            systems[label(family, version)] = indexes;
        }
    }
    return { base, names, systems };
}

for (const arch of ['x64', 'x86']) {
    const nt = build(arch, 'nt');
    const win32k = build(arch, 'win32k');
    const payload = {
        source: {
            repository: 'https://github.com/j00ru/windows-syscalls',
            commit,
            commitDate: date,
            files: [`${arch}/json/nt-per-system.json`, `${arch}/json/win32k-per-system.json`]
        },
        architecture: arch,
        note: 'Il numero di una syscall Windows (SSN) cambia da una versione all\'altra: vale solo per la versione indicata. nt = ntoskrnl.exe (tabella 0); win32k = win32k.sys (tabella 1, numeri da 0x1000).',
        nt,
        win32k
    };
    const file = path.join(__dirname, '..', '..', 'src', 'data', `windows-${arch}.json`);
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, `${JSON.stringify(payload)}\n`);
    console.log(`windows-${arch}.json: ${Object.keys(nt.systems).length} versioni, ${nt.names.length} nt + ${win32k.names.length} win32k nomi, ${(fs.statSync(file).size / 1024).toFixed(0)} KB`);
}
