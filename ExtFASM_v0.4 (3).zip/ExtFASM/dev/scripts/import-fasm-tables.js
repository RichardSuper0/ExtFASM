'use strict';

/**
 * Importa dalle tabelle del sorgente di FASM 1 (source/tables.inc) tutto ciò che il compilatore riconosce:
 * istruzioni (con il gestore che le codifica), registri, parole chiave di `format`/`section`/`segment`,
 * direttive del preprocessore, operatori e direttive dati.
 * Uso: node dev/scripts/import-fasm-tables.js <cartella-source-di-fasm> [versione]
 * Scrive src/data/fasm-tables.json. I dati sono i NOMI e le categorie, non il codice sorgente di FASM.
 */

const fs = require('node:fs');
const path = require('node:path');

const sourceDir = process.argv[2];
const version = process.argv[3] || '1.73.35';
if (!sourceDir) {
    console.error('Uso: node dev/scripts/import-fasm-tables.js <cartella-source-di-fasm> [versione]');
    process.exit(1);
}
const lines = fs.readFileSync(path.join(sourceDir, 'tables.inc'), 'utf8').split(/\r?\n/);

const labelAt = (name) => lines.findIndex((line) => line.trim() === `${name}:`);
const section = (from, to) => lines.slice(labelAt(from) + 1, labelAt(to));

/** `db N,'nome'` seguito da una riga `dw gestore-...`: nomi di direttive. */
function namedEntries(from, to) {
    const out = [];
    for (const line of section(from, to)) {
        const match = /^\s*db\s+\d+,'([^']+)'/.exec(line);
        if (match) {
            out.push(match[1]);
        }
    }
    return out;
}

// --- simboli: registri e parole chiave, per tipo -------------------------------------------------------
const SYMBOL_TYPES = {
    0x10: 'register', 0x14: 'specialRegister', 0x11: 'sizeOperator', 0x12: 'jumpDistance', 0x13: 'codeMode',
    0x18: 'format', 0x19: 'sectionFlag', 0x1a: 'peData', 0x1b: 'peOption', 0x1c: 'coffVariant',
    0x1d: 'coffStatic', 0x1e: 'elfSegment', 0x1f: 'evexOption'
};
const symbols = {};
for (const line of section('symbols_1', 'symbols_end')) {
    const match = /^\s*db\s+'([^']+)',([0-9A-F]+)h?,([0-9A-F]+)h?/i.exec(line);
    if (!match) {
        continue;
    }
    const type = SYMBOL_TYPES[parseInt(match[2], 16)] || `type${match[2]}`;
    (symbols[type] = symbols[type] || []).push(match[1]);
}

// --- istruzioni: nome e gestore -------------------------------------------------------------------------
const instructions = {};
const instructionLines = section('instructions_2', 'instructions_end');
for (let index = 0; index < instructionLines.length; index++) {
    const match = /^\s*db\s+'([^']+)',/.exec(instructionLines[index]);
    const handler = /^\s*dw\s+(\w+)-instruction_handler/.exec(instructionLines[index + 1] || '');
    if (match && handler) {
        instructions[match[1]] = handler[1];
        index++;
    }
}

// --- direttive dati ---------------------------------------------------------------------------------------
const dataDirectives = {};
const dataLines = section('data_directives_2', 'data_directives_end');
for (let index = 0; index < dataLines.length; index++) {
    const match = /^\s*db\s+'([^']+)',(\d+)/.exec(dataLines[index]);
    if (match) {
        dataDirectives[match[1]] = Number(match[2]); // dimensione dell'unità in byte
    }
}

const result = {
    source: {
        product: 'flat assembler 1',
        version,
        file: 'source/tables.inc',
        note: 'Elenchi di nomi ricavati dalle tabelle del compilatore: ciò che fasm riconosce davvero.'
    },
    preprocessorDirectives: namedEntries('preprocessor_directives', 'macro_directives'),
    macroDirectives: namedEntries('macro_directives', 'preprocessor_special_symbols'),
    preprocessorSpecialSymbols: namedEntries('preprocessor_special_symbols', 'operators'),
    operators: namedEntries('operators', 'single_operand_operators'),
    singleOperandOperators: namedEntries('single_operand_operators', 'directive_operators'),
    directiveOperators: namedEntries('directive_operators', 'address_sizes'),
    symbols,
    dataDirectives,
    instructions
};

fs.writeFileSync(path.join(__dirname, '..', '..', 'src', 'data', 'fasm-tables.json'), `${JSON.stringify(result)}\n`);
console.log(`istruzioni: ${Object.keys(instructions).length}, registri: ${symbols.register.length}, tipi di simbolo: ${Object.keys(symbols).length}`);
console.log(Object.entries(result).filter(([, v]) => Array.isArray(v)).map(([k, v]) => `${k}=${v.length}`).join(' '));
