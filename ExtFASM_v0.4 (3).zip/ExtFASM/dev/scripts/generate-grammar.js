'use strict';

/**
 * Genera syntaxes/fasm1.tmLanguage.json dalle tabelle reali di FASM 1 (src/instructions.js, che legge
 * src/data/fasm-tables.json), così grammatica, analisi e compilatore non possono divergere.
 * Uso:  node dev/scripts/generate-grammar.js   (o: npm run grammar)
 */

const fs = require('fs');
const path = require('path');
const {
    INSTRUCTIONS, PREFIXES, CONTROL_DIRECTIVES, DATA_DIRECTIVES, PREPROCESSOR_DIRECTIVES, WORD_OPERATORS,
    SYMBOLS, REGISTERS, SYMBOL_DEFINITION_WORDS
} = require('../../src/analysis/instructions');

const set = (...lists) => new Set(lists.flatMap((list) => [...list]));
const word = (list) => `(?i)(?<![\\w.$@#?~])(${[...list].sort((a, b) => b.length - a.length).join('|')})(?![\\w.$@#?~])`;

// Parole chiave del formato: formati, opzioni PE, tipi di dati speciali PE, segmenti ELF speciali, `static` di COFF.
const formatWords = set(SYMBOLS.format, SYMBOLS.peOption, SYMBOLS.peData, SYMBOLS.elfSegment, SYMBOLS.coffVariant, SYMBOLS.coffStatic);
const sectionFlags = set(SYMBOLS.sectionFlag);
const sizes = set(SYMBOLS.sizeOperator, SYMBOLS.jumpDistance);
const codeModes = set(SYMBOLS.codeMode);
const controlWords = set(CONTROL_DIRECTIVES, codeModes);
const preprocessorWords = set(PREPROCESSOR_DIRECTIVES, SYMBOL_DEFINITION_WORDS);
const dataWords = set(DATA_DIRECTIVES.keys());

// Opzioni EVEX (AVX-512): solo dentro le graffe, come `{k1}{z}`, `{rn-sae}`, `{1to8}`.
const evexOptions = [...SYMBOLS.evexOption].map((name) => name.replace(/^(r[dnuz])$/, '$1-sae'));
const evexRule = `(?i)\\{\\s*(?:${[...new Set([...SYMBOLS.evexOption, ...evexOptions, 'k[0-7]'])].join('|')})\\s*\\}`;

// Categorie di istruzioni: ricavate per nome dai mnemonic reali (INSTRUCTIONS), nell'ordine di priorità;
// ciò che non rientra resta `keyword.instruction.fasm1`.
const CATEGORIES = [
    ['flow', /^(j[a-z]+|call|ret[a-z]*|loop[a-z]*|int[o0-9a-z]*|iret[a-z]*|syscall|sysenter|sysexit|sysret|ud[0-2])$/],
    ['stack', /^(push[a-z]*|pop[a-z]*|enter|leave)$/],
    ['system', /^(in|out|ins[bwd]?|outs[bwd]?|cli|sti|hlt|cpuid|rdmsr|wrmsr|rdtsc[p]?|rdpmc|l[gil]dt|s[gil]dt|ltr|str|lmsw|smsw|clts|invd|wbinvd|invlpg|swapgs|monitor|mwait|xsave[a-z0-9]*|xrstor[a-z0-9]*|fxsave[0-9]*|fxrstor[0-9]*|rdrand|rdseed|rd[fg]sbase|wr[fg]sbase|vm[a-z]+|sgx[a-z]*|xbegin|xend|xabort|xtest|pause|lfence|mfence|sfence|prefetch[a-z0-9]*|clflush[a-z]*|clwb|nop)$/],
    ['fpu', /^f[a-z0-9]+$/],
    ['simd', /^(v[a-z0-9]+|p[a-z0-9]+|(?!pop|push)[a-z0-9]*(ps|pd|ss|sd)|emms|movq|movd|movd?q?[a-z]*dq[ua]|ld?mxcsr|stmxcsr)$/],
    ['move', /^(mov[a-z0-9]*|lea|xchg|cmov[a-z]+|lods[bwdq]?|stos[bwdq]?|scas[bwdq]?|cmps[bwdq]?|xlat[b]?|cbw|cwd[e]?|cdq[e]?|cqo|bswap|set[a-z]+|lahf|sahf|lds|les|lfs|lgs|lss)$/],
    ['arith', /^(add|adc|sub|sbb|mul|imul|div|idiv|inc|dec|neg|cmp|cmpxchg[0-9a-z]*|xadd|aaa|aas|aad|aam|daa|das|adcx|adox|mulx|crc32|popcnt|lzcnt|tzcnt)$/],
    ['logic', /^(and|or|xor|not|test|sh[lr]d?|sa[lr]|ro[lr]|rc[lr]|bt[a-z]*|bs[fr]|andn|bextr|blsi|blsmsk|blsr|bzhi|pdep|pext|rorx|sarx|shlx|shrx)$/]
];
const categorized = new Set();
const categoryRules = {};
for (const [name, pattern] of CATEGORIES) {
    const members = [...INSTRUCTIONS].filter((mnemonic) => !categorized.has(mnemonic) && pattern.test(mnemonic));
    members.forEach((mnemonic) => categorized.add(mnemonic));
    if (members.length) {
        categoryRules[`instr_${name}`] = { name: `keyword.instruction.${name}.fasm1`, match: word(members) };
    }
}
const restInstructions = [...INSTRUCTIONS].filter((mnemonic) => !categorized.has(mnemonic));

// Registri per classe.
const registerClasses = [
    ['general', (r) => /^(?:[re]?(?:ax|bx|cx|dx|si|di|bp|sp|ip)|[abcd][lh]|sil|dil|bpl|spl|r(?:8|9|1[0-5])[bdlw]?|eflags|rflags)$/.test(r)],
    ['segment', (r) => /^[cdefgs]s$/.test(r)],
    ['vector', (r) => /^[xyz]mm\d+$/.test(r)],
    ['fpu', (r) => /^(?:st\d?|mm\d)$/.test(r)],
    ['special', () => true]
];
const registerRules = {};
const usedRegisters = new Set();
for (const [name, test] of registerClasses) {
    const members = [...REGISTERS].filter((register) => !usedRegisters.has(register) && test(register));
    members.forEach((register) => usedRegisters.add(register));
    if (members.length) {
        registerRules[`reg_${name}`] = { name: `variable.language.register.${name}.fasm1`, match: word(members) };
    }
}

const grammar = {
    scopeName: 'source.fasm1',
    patterns: [
        { include: '#comments' },
        { include: '#strings' },
        { include: '#labels' },
        { include: '#preprocessor' },
        { include: '#directives' },
        { include: '#data' },
        { include: '#format' },
        { include: '#sectionFlags' },
        { include: '#sizes' },
        { include: '#prefixes' },
        ...Object.keys(categoryRules).map((key) => ({ include: `#${key}` })),
        { include: '#instructions' },
        { include: '#operators' },
        ...Object.keys(registerRules).map((key) => ({ include: `#${key}` })),
        { include: '#memory' },
        { include: '#punctuation' },
        { include: '#evex' },
        { include: '#specialSymbols' },
        { include: '#numbers' }
    ],
    repository: {
        comments: {
            patterns: [{ name: 'comment.line.semicolon.fasm1', match: ';.*$' }]
        },
        strings: {
            // FASM non usa sequenze di escape: ' e " delimitano la stringa, il delimitatore raddoppiato lo include.
            patterns: [
                { name: 'string.quoted.single.fasm1', begin: "'", end: "'|$" },
                { name: 'string.quoted.double.fasm1', begin: '"', end: '"|$' }
            ]
        },
        labels: {
            patterns: [
                {
                    name: 'entity.name.label.local.fasm1',
                    match: '^[ \\t]*\\.[\\w$?@]+(?=[ \\t]*:(?!:))'
                },
                {
                    // macro/struc nome: definizione di una macro o di una struttura
                    match: '(?i)^[ \\t]*(macro|struc|struct)[ \\t]+([A-Za-z_.$?@][\\w.$?@]*)',
                    captures: { 1: { name: 'keyword.control.preprocessor.fasm1' }, 2: { name: 'entity.name.function.macro.fasm1' } }
                },
                {
                    name: 'entity.name.label.fasm1',
                    match: '^[ \\t]*(?:[A-Za-z_.$?@][\\w.$?@]*|@@)(?=[ \\t]*:(?!:))'
                },
                {
                    name: 'entity.name.label.data.fasm1',
                    match: `(?i)^[ \\t]*[A-Za-z_.$?@][\\w.$?@]*(?=[ \\t]+(?:${[...dataWords, 'equ', 'fix', 'struc'].join('|')}|=)(?![\\w.$?@]))`
                }
            ]
        },
        preprocessor: {
            name: 'keyword.control.preprocessor.fasm1',
            match: word(preprocessorWords)
        },
        directives: {
            name: 'keyword.control.directive.fasm1',
            match: word(controlWords)
        },
        data: {
            name: 'storage.type.data.fasm1',
            match: word(dataWords)
        },
        format: {
            name: 'support.type.format.fasm1',
            match: word(formatWords)
        },
        sectionFlags: {
            name: 'storage.modifier.section.fasm1',
            match: word(sectionFlags)
        },
        sizes: {
            name: 'storage.type.size.fasm1',
            match: word(sizes)
        },
        prefixes: {
            name: 'storage.modifier.prefix.fasm1',
            match: word(PREFIXES)
        },
        ...categoryRules,
        instructions: {
            name: 'keyword.instruction.fasm1',
            match: word(restInstructions)
        },
        operators: {
            name: 'keyword.operator.word.fasm1',
            match: word(WORD_OPERATORS)
        },
        ...registerRules,
        memory: {
            // I corchetes delimitano un operando in memoria: [base + indice*scala + spostamento]
            name: 'punctuation.section.memory.fasm1',
            match: '[\\[\\]]'
        },
        punctuation: {
            name: 'punctuation.separator.operand.fasm1',
            match: ',|:(?!:)'
        },
        evex: {
            name: 'storage.modifier.evex.fasm1',
            match: evexRule
        },
        specialSymbols: {
            name: 'constant.language.fasm1',
            match: '(?i)\\$(?:%%|%|\\$)?(?![\\w$])|\\b__(?:file|line)__\\b'
        },
        numbers: {
            patterns: [
                { name: 'constant.numeric.hex.fasm1', match: '(?i)(?<![\\w.])(?:0x[0-9a-f]+|\\$[0-9][0-9a-f]*|[0-9][0-9a-f]*h)(?![\\w.])' },
                { name: 'constant.numeric.binary.fasm1', match: '(?i)(?<![\\w.])[01]+b(?![\\w.])' },
                { name: 'constant.numeric.octal.fasm1', match: '(?i)(?<![\\w.])[0-7]+o(?![\\w.])' },
                { name: 'constant.numeric.float.fasm1', match: '(?i)(?<![\\w.])[0-9]+(?:\\.[0-9]+(?:e[+-]?[0-9]+)?|e[+-]?[0-9]+)(?![\\w.])' },
                { name: 'constant.numeric.decimal.fasm1', match: '(?<![\\w.])[0-9]+(?![\\w.])' }
            ]
        }
    }
};

const target = path.join(__dirname, '..', '..', 'syntaxes', 'fasm1.tmLanguage.json');
fs.writeFileSync(target, `${JSON.stringify(grammar, null, 4)}\n`);
console.log(`Scritto ${path.relative(process.cwd(), target)}: ${INSTRUCTIONS.size} mnemonic, ${REGISTERS.size} registri, ${controlWords.size} direttive, ${formatWords.size} parole di formato`);
