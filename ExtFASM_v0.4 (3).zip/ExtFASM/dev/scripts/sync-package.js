'use strict';

/**
 * Aggiorna in package.json ciò che deriva dai dati: l'elenco delle versioni di Windows
 * (fasm1.target.windowsVersion). Eseguire dopo aver rigenerato src/data/windows-*.json.
 * Con --check non scrive: esce con errore se package.json non è allineato (usato dai test).
 */

const fs = require('node:fs');
const path = require('node:path');
const { windowsVersions } = require('../../src/syscalls/tables');

const file = path.join(__dirname, '..', '..', 'package.json');

function expectedVersionSettings() {
    const versions = windowsVersions();
    return {
        enum: ['', ...versions],
        enumDescriptions: ['%cfg.winver.none%', ...versions.map(() => '')]
    };
}

function sync(check) {
    const pkg = JSON.parse(fs.readFileSync(file, 'utf8'));
    const property = pkg.contributes.configuration.properties['fasm1.target.windowsVersion'];
    const expected = expectedVersionSettings();
    const aligned = JSON.stringify(property.enum) === JSON.stringify(expected.enum);
    if (check) {
        return aligned;
    }
    property.enum = expected.enum;
    property.enumDescriptions = expected.enumDescriptions;
    fs.writeFileSync(file, `${JSON.stringify(pkg, null, 4)}\n`);
    return true;
}

if (require.main === module) {
    const check = process.argv.includes('--check');
    const ok = sync(check);
    if (check && !ok) {
        console.error('package.json non è allineato alle versioni di Windows presenti nei dati: esegui `node dev/scripts/sync-package.js`.');
        process.exit(1);
    }
}

module.exports = { sync, expectedVersionSettings };
