'use strict';

/**
 * Genera i cataloghi src/i18n/locales/<lingua>.json a partire da scripts/locales/*.js
 * (ogni messaggio ha tutte le lingue affiancate) e i file package.nls*.json per i testi di package.json.
 * Uso: node dev/scripts/generate-locales.js
 */

const fs = require('node:fs');
const path = require('node:path');

const LANGUAGES = ['en', 'it', 'fr', 'es', 'pl', 'de'];
const sourceDir = path.join(__dirname, 'locales');
const catalogs = Object.fromEntries(LANGUAGES.map((language) => [language, {}]));
const nls = Object.fromEntries(LANGUAGES.map((language) => [language, {}]));

for (const file of fs.readdirSync(sourceDir).filter((name) => name.endsWith('.js')).sort()) {
    const messages = require(path.join(sourceDir, file));
    const target = file === 'package.js' ? nls : catalogs;
    for (const [key, translations] of Object.entries(messages)) {
        for (const language of LANGUAGES) {
            if (typeof translations[language] !== 'string') {
                throw new Error(`${file}: manca la traduzione "${language}" per ${key}`);
            }
            if (target[language][key] !== undefined) {
                throw new Error(`${file}: chiave duplicata ${key}`);
            }
            target[language][key] = translations[language];
        }
    }
}

const root = path.join(__dirname, '..', '..');
for (const language of LANGUAGES) {
    fs.writeFileSync(path.join(root, 'src', 'i18n', 'locales', `${language}.json`), `${JSON.stringify(catalogs[language], null, 2)}\n`);
    const suffix = language === 'en' ? '' : `.${language}`;
    fs.writeFileSync(path.join(root, `package.nls${suffix}.json`), `${JSON.stringify(nls[language], null, 4)}\n`);
}
console.log(`Lingue: ${LANGUAGES.join(', ')}; messaggi: ${Object.keys(catalogs.en).length}; testi di package.json: ${Object.keys(nls.en).length}`);
