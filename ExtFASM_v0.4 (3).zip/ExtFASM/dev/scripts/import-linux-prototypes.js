'use strict';

/**
 * Importa i prototipi C delle syscall Linux (include/linux/syscalls.h e arch/x86/include/asm/syscalls.h)
 * in src/data/linux-prototypes.json: serve a sapere quanti argomenti prende una syscall e come si chiamano,
 * senza scriverli a mano. Stessa provenienza (commit) delle tabelle dei numeri.
 *
 * Uso: node dev/scripts/import-linux-prototypes.js <cartella-del-clone-linux>
 */

const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const repo = path.resolve(process.argv[2] || '');
const FILES = ['include/linux/syscalls.h', 'arch/x86/include/asm/syscalls.h'];
if (!process.argv[2] || !FILES.every((file) => fs.existsSync(path.join(repo, file)))) {
    console.error('Uso: node dev/scripts/import-linux-prototypes.js <cartella-del-clone-linux>');
    process.exit(1);
}
const git = (...args) => execFileSync('git', ['-C', repo, ...args], { encoding: 'utf8' }).trim();
const [commit, date] = git('log', '-1', '--format=%H|%cI').split('|');

function splitTopLevel(text) {
    const parts = [];
    let depth = 0;
    let current = '';
    for (const character of text) {
        if (character === '(') depth += 1;
        if (character === ')') depth -= 1;
        if (character === ',' && depth === 0) {
            parts.push(current);
            current = '';
        } else {
            current += character;
        }
    }
    if (current.trim()) parts.push(current);
    return parts.map((part) => part.replace(/\s+/g, ' ').trim()).filter(Boolean);
}

function parseArgument(text) {
    const cleaned = text.replace(/__user|__kernel|__force|__percpu|__rcu/g, '').replace(/\s+/g, ' ').trim();
    const match = /^(.*?)(\**\s*)([A-Za-z_]\w*)(\[\])?$/.exec(cleaned);
    const C_WORDS = new Set(['long', 'int', 'char', 'short', 'unsigned', 'signed', 'void', 'float', 'double']);
    if (!match || cleaned.includes('(*') || !match[1].trim() || C_WORDS.has(match[3])) {
        return { type: cleaned.replace(/\s*\*/g, ' *').replace(/\*\s+\*/g, '**').trim(), name: null };
    }
    return { type: `${match[1].trim()}${match[2].trim() ? ' ' : ''}${match[2].replace(/\s+/g, '')}${match[4] || ''}`.trim(), name: match[3] };
}

const prototypes = {};
for (const file of FILES) {
    const text = fs.readFileSync(path.join(repo, file), 'utf8').replace(/\/\*[\s\S]*?\*\//g, ' ');
    const pattern = /(?:asmlinkage\s+)?long\s+(sys_\w+)\s*\(([^;{]*?)\)\s*;/g;
    let match;
    while ((match = pattern.exec(text)) !== null) {
        const argumentText = match[2].replace(/\s+/g, ' ').trim();
        const args = argumentText === 'void' || argumentText === '' ? [] : splitTopLevel(argumentText).map(parseArgument);
        prototypes[match[1]] = { args, header: file };
    }
}

const output = {
    source: {
        repository: 'https://github.com/torvalds/linux',
        commit,
        commitDate: date,
        files: FILES,
        note: 'Prototipi C delle syscall (non i numeri). Chiave: nome della funzione d\'ingresso (sys_xxx).'
    },
    prototypes
};
fs.writeFileSync(path.join(__dirname, '..', '..', 'src', 'data', 'linux-prototypes.json'), `${JSON.stringify(output)}\n`);

// Copertura rispetto alle tabelle dei numeri.
const normalize = (entry) => entry && entry.replace(/^__(?:x64|ia32|x32)_/, '');
for (const table of ['linux-x86_64', 'linux-i386']) {
    const data = require(`../../src/data/${table}.json`);
    const entries = data.syscalls.filter((item) => item.entry && item.entry !== 'sys_ni_syscall');
    const covered = entries.filter((item) => prototypes[normalize(item.entry)]);
    console.log(`${table}: ${covered.length}/${entries.length} syscall con prototipo`);
}
console.log(`Scritto src/data/linux-prototypes.json: ${Object.keys(prototypes).length} prototipi, commit ${commit.slice(0, 12)}`);
