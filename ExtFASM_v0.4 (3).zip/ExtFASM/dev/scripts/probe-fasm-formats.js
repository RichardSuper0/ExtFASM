'use strict';

/**
 * Interroga un FASM 1 reale e registra come risponde alle direttive di formato:
 *  - quali direttive (section, segment, entry, stack, heap, data, extrn, public…) esistono in ogni formato;
 *  - quali parole sono ammesse dopo `format X` (opzioni PE, `executable`, `dll`…);
 *  - quali flag sono ammessi dopo `section`/`segment` in ogni formato.
 * Il risultato è src/data/fasm-format-matrix.json: dati misurati, non dedotti dal manuale.
 *
 * Uso: node dev/scripts/probe-fasm-formats.js <eseguibile-fasm> [versione]
 * (richiede un fasm eseguibile su questa macchina, ad es. fasm.x64 di Linux)
 */

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { execFileSync } = require('node:child_process');

const fasm = process.argv[2];
const version = process.argv[3] || '1.73.35';
if (!fasm) {
    console.error('Uso: node dev/scripts/probe-fasm-formats.js <eseguibile-fasm> [versione]');
    process.exit(1);
}
const tables = require('../../src/data/fasm-tables.json');
const work = fs.mkdtempSync(path.join(os.tmpdir(), 'extfasm-probe-'));

/** Assembla `source` e restituisce 'ok' oppure il messaggio di errore di FASM (minuscolo, come lo stampa). */
function probe(source) {
    const input = path.join(work, 'probe.asm');
    const output = path.join(work, 'probe.out');
    fs.writeFileSync(input, `${source}\n`);
    try {
        fs.rmSync(output, { force: true });
        execFileSync(fasm, [input, output], { stdio: 'pipe', timeout: 10000 });
        return 'ok';
    } catch (error) {
        const text = `${error.stdout || ''}${error.stderr || ''}`;
        const match = /^error:\s*(.*)$/m.exec(text);
        return match ? match[1].trim() : `fallito: ${String(error.message).split('\n')[0]}`;
    }
}

// Formati: nome -> riga `format`.
const FORMATS = {
    'binary': 'format binary',
    'MZ': 'format MZ',
    'PE': 'format PE console',
    'PE64': 'format PE64 console',
    'COFF': 'format COFF',
    'MS COFF': 'format MS COFF',
    'MS64 COFF': 'format MS64 COFF',
    'ELF': 'format ELF',
    'ELF64': 'format ELF64',
    'ELF executable': 'format ELF executable 3',
    'ELF64 executable': 'format ELF64 executable 3'
};

// Direttive: ogni voce ha una o più prove; l'esito è la lista dei messaggi.
const DIRECTIVE_PROBES = {
    section: ["section '.t'"],
    segment: ['segment readable', 'segment s'],
    entry: ['entry 0', 'segment s\nentry s:0'],
    stack: ['stack 4096'],
    heap: ['heap 4096'],
    data: ['data import\nend data', 'data 0\nend data'],
    extrn: ['extrn foo'],
    public: ['foo:\npublic foo'],
    use16: ['use16'],
    use32: ['use32'],
    use64: ['use64'],
    org: ['org 0x1000'],
    label: ['label foo at 0'],
    virtual: ['virtual at 0\nend virtual']
};

const matrix = { directives: {}, flags: {}, formatWords: {} };

for (const [name, formatLine] of Object.entries(FORMATS)) {
    matrix.directives[name] = {};
    for (const [directive, sources] of Object.entries(DIRECTIVE_PROBES)) {
        matrix.directives[name][directive] = sources.map((body) => probe(`${formatLine}\n${body}\nnop`));
    }
}

// Flag e parole dopo `section '.t'` / `segment`.
const FLAG_WORDS = [
    ...tables.symbols.sectionFlag, ...tables.symbols.peData, ...tables.symbols.elfSegment,
    'align 16', 'align 3'
];
const INTRODUCERS = { section: (word) => `section '.t' ${word}`, segment: (word) => `segment ${word}` };
for (const [name, formatLine] of Object.entries(FORMATS)) {
    matrix.flags[name] = {};
    for (const [introducer, build] of Object.entries(INTRODUCERS)) {
        const exists = matrix.directives[name][introducer].some((message) => message !== 'illegal instruction');
        if (!exists) {
            continue;
        }
        matrix.flags[name][introducer] = {};
        for (const word of FLAG_WORDS) {
            matrix.flags[name][introducer][word] = probe(`${formatLine.replace(/ console| 3$/, '')}\n${build(word)}\nnop`);
        }
    }
}

// Parole dopo `format`: per ogni testa di formato.
const HEADS = ['binary', 'MZ', 'PE', 'PE64', 'COFF', 'MS COFF', 'MS64 COFF', 'ELF', 'ELF64', 'ELF executable', 'ELF64 executable', 'ELF dynamic', 'ELF64 dynamic'];
const FORMAT_WORDS = [
    ...tables.symbols.format, ...tables.symbols.peOption, ...tables.symbols.coffVariant,
    'executable', 'dynamic', '3', '9', '4.0', "at 0x400000", "as 'x'", "on 'stub.exe'"
];
for (const head of HEADS) {
    matrix.formatWords[head] = {};
    for (const word of FORMAT_WORDS) {
        matrix.formatWords[head][word] = probe(`format ${head} ${word}\nnop`);
    }
}

// Coppie di opzioni dopo `format PE`/`PE64`: quali combinazioni FASM rifiuta (es. `console gui`).
matrix.formatPairs = {};
for (const head of ['PE', 'PE64']) {
    const words = ['console', 'gui', 'native', 'efi', 'efiboot', 'efiruntime', 'dll', 'wdm', 'large', 'nx'];
    matrix.formatPairs[head] = {};
    for (const first of words) {
        for (const second of words) {
            const verdict = probe(`format ${head} ${first} ${second}\nnop`);
            if (verdict !== 'ok') {
                matrix.formatPairs[head][`${first} ${second}`] = verdict;
            }
        }
    }
}

// Cosa, prima di `format`, FASM considera "istruzione inattesa" (emette byte) e cosa no.
const BEFORE_FORMAT = {
    'nop': 'nop', 'db 1': 'db 1', 'rb 1': 'rb 1', 'times 2 db 0': 'times 2 db 0', 'align 4': 'align 4',
    'dd 0': 'dd 0', 'org 0': 'org 0x100', 'use32': 'use32', 'label': 'start:', 'constant': 'X = 5',
    'equ': 'Y equ 7', 'macro': 'macro m { }', 'display': "display 'x'", 'if': 'if 1\nend if', 'virtual': 'virtual at 0\ndb 1\nend virtual',
    'repeat': 'repeat 1\nend repeat', 'include': "include 'nofile.inc'"
};
matrix.beforeFormat = {};
for (const [name, body] of Object.entries(BEFORE_FORMAT)) {
    matrix.beforeFormat[name] = probe(`${body}\nformat binary\nnop`);
}

fs.rmSync(work, { recursive: true, force: true });

const result = {
    source: {
        product: 'flat assembler 1',
        version,
        note: 'Risposte misurate di un fasm reale alle direttive di formato (scripts/probe-fasm-formats.js). Ogni valore è "ok" oppure il messaggio di errore di FASM.'
    },
    ...matrix
};
fs.writeFileSync(path.join(__dirname, '..', '..', 'src', 'data', 'fasm-format-matrix.json'), `${JSON.stringify(result)}\n`);
const count = (tree) => JSON.stringify(tree).split('"').length;
console.log('Scritto src/data/fasm-format-matrix.json', fs.statSync(path.join(__dirname, '..', '..', 'src', 'data', 'fasm-format-matrix.json')).size, 'byte');
