<#
.SYNOPSIS
  Installs Node.js and VS Code (if missing), builds the ExtFASM .vsix and publishes it to the
  Visual Studio Marketplace.

.NOTES
  Run from anywhere:  pwsh -File dev\publish.ps1   (or Windows PowerShell 5.1)
  You need, beforehand:
    1. a publisher at https://marketplace.visualstudio.com/manage
    2. an Azure DevOps Personal Access Token (scope: Marketplace > Manage, organization: All accessible)
  The token is asked for at publish time, kept only in this process and never written to disk.
  The extension icon is media\icon.png (already set in package.json).
#>
[CmdletBinding()]
param(
    [string]$Publisher,
    [switch]$SkipTests,
    [switch]$PackageOnly
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

function Step($text) { Write-Host "`n==> $text" -ForegroundColor Cyan }
function Have($name) { [bool](Get-Command $name -ErrorAction SilentlyContinue) }
function Refresh-Path {
    $machine = [Environment]::GetEnvironmentVariable('Path', 'Machine')
    $user = [Environment]::GetEnvironmentVariable('Path', 'User')
    $env:Path = "$machine;$user"
}
function Install-WithWinget($id, $label) {
    if (-not (Have 'winget')) {
        throw "winget not found. Install $label manually, then run this script again."
    }
    winget install --id $id -e --accept-package-agreements --accept-source-agreements
    if ($LASTEXITCODE -ne 0) { throw "winget could not install $label (exit code $LASTEXITCODE)." }
    Refresh-Path
}

# --- 1. Node.js and VS Code -------------------------------------------------------------------
Step 'Checking Node.js'
if (-not (Have 'node') -or -not (Have 'npm')) {
    Install-WithWinget 'OpenJS.NodeJS.LTS' 'Node.js LTS'
}
if (-not (Have 'node')) { throw 'Node.js is installed but not visible yet: open a new terminal and run the script again.' }
Write-Host ("Node.js " + (node --version) + ", npm " + (npm --version))

Step 'Checking VS Code'
if (-not (Have 'code')) {
    Install-WithWinget 'Microsoft.VisualStudioCode' 'Visual Studio Code'
}
$haveCode = Have 'code'
if (-not $haveCode) { Write-Warning 'VS Code is installed but "code" is not in PATH yet; the local install test will be skipped.' }

# --- 2. Project checks ------------------------------------------------------------------------
Step 'Checking the extension files'
foreach ($required in 'package.json', 'extension.js', 'media\icon.png', 'LICENSE', 'README.md') {
    if (-not (Test-Path (Join-Path $root $required))) { throw "Missing file: $required" }
}
Write-Host 'Icon: media\icon.png'

if (-not $SkipTests) {
    Step 'Running the tests'
    npm test
    if ($LASTEXITCODE -ne 0) { throw 'Tests failed: not publishing. Fix them or use -SkipTests.' }
}

# --- 3. Publisher in package.json -------------------------------------------------------------
$pkg = Get-Content (Join-Path $root 'package.json') -Raw | ConvertFrom-Json
if (-not $Publisher) {
    $Publisher = Read-Host "Marketplace publisher ID (current: $($pkg.publisher))"
    if (-not $Publisher) { $Publisher = $pkg.publisher }
}
if ($Publisher -notmatch '^[A-Za-z0-9][A-Za-z0-9-]*$') { throw "Invalid publisher ID: $Publisher" }
if ($Publisher -ne $pkg.publisher) {
    Step "Setting publisher to '$Publisher' in package.json"
    # Edit through node so the file formatting and key order stay exactly as they are.
    node -e "const fs=require('fs');const p=JSON.parse(fs.readFileSync('package.json','utf8'));p.publisher=process.argv[1];fs.writeFileSync('package.json',JSON.stringify(p,null,4)+'\n')" $Publisher
    if ($LASTEXITCODE -ne 0) { throw 'Could not update package.json.' }
}

# --- 4. Package -------------------------------------------------------------------------------
Step 'Building the .vsix'
$vsix = Join-Path $root "extfasm-$($pkg.version).vsix"
npx --yes @vscode/vsce package --no-dependencies --allow-missing-repository --out $vsix
if ($LASTEXITCODE -ne 0 -or -not (Test-Path $vsix)) { throw 'vsce package failed.' }
Write-Host "Built: $vsix"

if ($haveCode) {
    Step 'Installing the .vsix in your VS Code to try it'
    code --install-extension $vsix --force
    Write-Host 'Open a .asm file in VS Code and check it works before publishing.'
}

if ($PackageOnly) { Write-Host "`nDone (package only)."; return }

# --- 5. Publish -------------------------------------------------------------------------------
Step 'Publishing to the Visual Studio Marketplace'
$answer = Read-Host "Publish $($pkg.name) $($pkg.version) as '$Publisher' now? (y/N)"
if ($answer -notmatch '^[yYsS]') { Write-Host "Not published. The package is here: $vsix"; return }

$secure = Read-Host 'Personal Access Token (hidden)' -AsSecureString
$bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
try {
    $env:VSCE_PAT = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
    npx --yes @vscode/vsce publish --packagePath $vsix --no-dependencies --allow-missing-repository
    if ($LASTEXITCODE -ne 0) { throw 'vsce publish failed (check the token scope and the publisher ID).' }
}
finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
    Remove-Item Env:\VSCE_PAT -ErrorAction SilentlyContinue
}

Write-Host "`nPublished. It usually appears in the Marketplace within a few minutes:" -ForegroundColor Green
Write-Host "https://marketplace.visualstudio.com/items?itemName=$Publisher.$($pkg.name)"
