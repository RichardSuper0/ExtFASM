'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { resolveCompiler, describeCompilerProblem, parseIncludePath, buildAssemblerEnv } = require('../../src/build/config');

function makeTempDir() {
    return fs.mkdtempSync(path.join(os.tmpdir(), 'extfasm-config-'));
}

function makeExecutable(directory, name) {
    const file = path.join(directory, name);
    fs.writeFileSync(file, '#!/bin/sh\n');
    fs.chmodSync(file, 0o755);
    return file;
}

test('empty setting and no fasm in PATH reports "not-set" without guessing', () => {
    const dir = makeTempDir();
    const result = resolveCompiler('', { env: { PATH: dir }, platform: 'linux' });
    assert.deepEqual(result, { ok: false, reason: 'not-set', configured: '' });
    assert.match(describeCompilerProblem(result), /non impostato/);
});

test('empty setting finds fasm in PATH', () => {
    const dir = makeTempDir();
    const file = makeExecutable(dir, 'fasm');
    const result = resolveCompiler('', { env: { PATH: dir }, platform: 'linux' });
    assert.deepEqual(result, { ok: true, path: file, source: 'path' });
});

test('an explicit path is used only if valid (no silent fallback to PATH)', () => {
    const dirInPath = makeTempDir();
    makeExecutable(dirInPath, 'fasm');
    const result = resolveCompiler(path.join(makeTempDir(), 'missing-fasm'), { env: { PATH: dirInPath }, platform: 'linux' });
    assert.equal(result.ok, false);
    assert.equal(result.reason, 'not-found');
});

test('explicit path to an executable file is accepted and reported as coming from settings', () => {
    const file = makeExecutable(makeTempDir(), 'my fasm (1)');
    const result = resolveCompiler(file, { env: { PATH: '' }, platform: 'linux' });
    assert.deepEqual(result, { ok: true, path: file, source: 'settings' });
});

test('a directory is not a compiler', () => {
    const result = resolveCompiler(makeTempDir(), { env: { PATH: '' }, platform: 'linux' });
    assert.equal(result.reason, 'not-a-file');
});

test('non-executable file is reported as such on POSIX', { skip: process.platform === 'win32' }, () => {
    const dir = makeTempDir();
    const file = path.join(dir, 'fasm');
    fs.writeFileSync(file, 'x');
    fs.chmodSync(file, 0o644);
    const result = resolveCompiler(file, { env: { PATH: '' }, platform: 'linux' });
    assert.equal(result.reason, 'not-executable');
});

test('a bare command name is looked up in PATH', () => {
    const dir = makeTempDir();
    const file = makeExecutable(dir, 'fasm');
    assert.equal(resolveCompiler('fasm', { env: { PATH: dir }, platform: 'linux' }).path, file);
    assert.equal(resolveCompiler('fasm', { env: { PATH: '' }, platform: 'linux' }).reason, 'not-found');
});

test('include path keeps existing directories and reports missing ones', () => {
    const dir = makeTempDir();
    const missing = path.join(dir, 'nope');
    const result = parseIncludePath([dir, '  ', missing]);
    assert.deepEqual(result, { valid: [dir], missing: [missing] });
});

test('INCLUDE is prepended to the child environment only and never mutates the base', () => {
    const base = { PATH: '/bin', INCLUDE: '/old' };
    const env = buildAssemblerEnv(base, ['/a b', '/c'], 'linux');
    assert.equal(env.INCLUDE, '/a b:/c:/old');
    assert.equal(base.INCLUDE, '/old');
    assert.equal(buildAssemblerEnv(base, [], 'linux').INCLUDE, '/old');
    assert.equal(buildAssemblerEnv({}, ['C:\\inc'], 'win32').INCLUDE, 'C:\\inc');
});

test('output path: next to the source by default, extension from the format', () => {
    const { computeOutputPath } = require('../../src/build/config');
    const elf = { extension: '' };
    const pe = { extension: '.exe' };
    assert.equal(computeOutputPath(path.join('/p', 'main.asm'), elf, '').path, path.join('/p', 'main'));
    assert.equal(computeOutputPath(path.join('/p', 'main.asm'), pe, '').path, path.join('/p', 'main.exe'));
    assert.equal(computeOutputPath(path.join('/p', 'main.asm'), pe, 'build').path, path.join('/p', 'build', 'main.exe'));
    assert.equal(computeOutputPath(path.join('/p', 'main.asm'), pe, '/out').path, path.resolve('/out', 'main.exe'));
});

test('output path never overwrites the source or another assembly file', () => {
    const { computeOutputPath } = require('../../src/build/config');
    assert.equal(computeOutputPath(path.join('/p', 'prog'), { extension: '' }, '').reason, 'would-overwrite-source');
    assert.equal(computeOutputPath(path.join('/p', 'a.asm'), { extension: '.inc' }, '').ok, false);
});
