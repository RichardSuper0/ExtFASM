'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { analyzeSymbols } = require('../../src/analysis/symbols');

const SOURCE = [
    'format ELF64 executable 3',
    'macro print msg, len {',
    '  mov rsi, msg',
    '}',
    'SYS_WRITE = 1',
    'start:',
    '  print hello, 5   ; hello',
    '  mov eax, SYS_WRITE',
    '  call func',
    '  jmp .done',
    '.done:',
    '  ret',
    'func:',
    '  ret',
    "hello db 'start', 10"
].join('\n');

const textOf = (token) => SOURCE.split('\n')[token.line].slice(token.start, token.end);
const find = (type, text, line) => analyzeSymbols(SOURCE).tokens.find((t) => t.type === type && textOf(t) === text && (line === undefined || t.line === line));

test('macro: definition and every invocation are marked as macro', () => {
    assert.ok(find('macro', 'print', 1));
    assert.ok(find('macro', 'print', 6));
});

test('labels, data and constants are marked where defined and where used', () => {
    assert.ok(find('label', 'start', 5));
    assert.ok(find('label', 'func', 8), 'call target');
    assert.ok(find('label', '.done', 9), 'local label used by jmp');
    assert.ok(find('constant', 'SYS_WRITE', 7));
    assert.ok(find('variable', 'hello', 6), 'data label used as operand');
    assert.ok(find('variable', 'hello', 14), 'data label definition');
});

test('comments, strings and macro bodies never produce tokens; undefined names stay unmarked', () => {
    const tokens = analyzeSymbols(SOURCE).tokens;
    assert.ok(!tokens.some((t) => t.line === 6 && t.start > 20), 'comment');
    assert.ok(!tokens.some((t) => t.line === 14 && textOf(t) === 'start'), 'inside a string');
    assert.ok(!tokens.some((t) => t.line === 2), 'macro body');
    assert.deepEqual(analyzeSymbols('  call unknown_thing\n').tokens, []);
});

test('local labels belong to the previous global label', () => {
    const text = 'a:\n.x:\n  jmp .x\nb:\n  jmp .x\n';
    const tokens = analyzeSymbols(text).tokens.filter((t) => text.split('\n')[t.line].slice(t.start, t.end) === '.x');
    assert.deepEqual(tokens.map((t) => t.line), [1, 2]);
});
