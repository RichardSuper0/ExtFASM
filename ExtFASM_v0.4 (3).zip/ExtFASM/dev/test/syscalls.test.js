'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { analyzeSyscalls } = require('../../src/syscalls/engine');
const tables = require('../../src/syscalls/tables');

const run = (source, options) => analyzeSyscalls(source, options);
const only = (source, options) => {
    const { findings } = run(source, options);
    assert.equal(findings.length, 1, `attesa una sola syscall, trovate ${findings.length}: ${JSON.stringify(findings.map((f) => f.message))}`);
    return findings[0];
};
const ELF64 = 'format ELF64 executable 3\nentry start\nstart:\n';

// ---------------------------------------------------------------------------------------------------------
// Linux
// ---------------------------------------------------------------------------------------------------------

test('Linux x86-64: write and exit are recognised from the kernel table; an unknown number is reported', () => {
    const { findings } = run(`${ELF64}mov eax, 1\nmov edi, 1\nsyscall\nmov eax, 60\nxor edi, edi\nsyscall\nmov eax, 9999\nsyscall`);
    assert.deepEqual(findings.map((f) => [f.category, f.name, f.number]), [
        ['valid', 'write', 1], ['valid', 'exit', 60], ['unknown', null, 9999]
    ]);
    assert.equal(findings[0].table.repository, 'https://github.com/torvalds/linux');
    assert.match(findings[0].table.commit, /^[0-9a-f]{40}$/);
    assert.deepEqual(findings[0].convention.args, ['rdi', 'rsi', 'rdx', 'r10', 'r8', 'r9']);
});

test('Linux i386: int 0x80 uses the 32-bit table (write = 4, exit = 1)', () => {
    const { findings } = run('format ELF executable 3\nmov eax, 4\nint 0x80\nmov eax, 1\nint 80h');
    assert.deepEqual(findings.map((f) => [f.category, f.name, f.number]), [['valid', 'write', 4], ['valid', 'exit', 1]]);
    assert.match(findings[0].message, /i386/);
});

test('Linux x86-64: int 0x80 is valid but warns that it uses the i386 table', () => {
    const finding = only(`${ELF64}mov eax, 1\nint 0x80`);
    assert.equal(finding.category, 'valid');
    assert.equal(finding.name, 'exit'); // numero 1 nella tabella i386
    assert.ok(finding.notes.some((note) => /tabella i386/.test(note)));
});

test('syscall in 32-bit code and any entry in 16-bit code are not valid on Linux', () => {
    assert.equal(only('format ELF executable 3\nmov eax, 1\nsyscall').kind, 'wrong-mode');
    assert.equal(only('format ELF executable 3\nuse16\nmov eax, 1\nint 0x80').kind, 'wrong-mode');
});

test('sysenter on Linux is flagged as not verifiable (needs the vDSO)', () => {
    const finding = only('format ELF executable 3\nmov eax, 1\nsysenter');
    assert.equal(finding.category, 'unverifiable');
    assert.match(finding.message, /vDSO/);
});

test('ELF ABI 0 is treated as Linux but the assumption is stated', () => {
    const finding = only('format ELF64 executable\nmov eax, 60\nsyscall');
    assert.equal(finding.category, 'valid');
    assert.ok(finding.target.assumed);
    assert.ok(finding.notes.some((note) => /ABI 0/.test(note)));
});

test('entry points of other systems are reported for the selected target', () => {
    assert.equal(only(`${ELF64}mov eax, 1\nint 0x2e`).kind, 'wrong-entry');
    assert.match(only(`${ELF64}mov eax, 1\nint 0x2e`).message, /Windows/);
    const onWindows = only('format PE console\nmov eax, 1\nint 0x80');
    assert.equal(onWindows.category, 'invalid-for-target');
    assert.match(onWindows.message, /Linux, FreeBSD/);
});

test('interrupts that are not syscall entries (int 0x10, int 0x21) are ignored', () => {
    assert.equal(run(`${ELF64}mov eax, 3\nint 0x10\nint 21h`).findings.length, 0);
});

// ---------------------------------------------------------------------------------------------------------
// Numero della syscall: tracciamento dei registri
// ---------------------------------------------------------------------------------------------------------

test('xor eax, eax gives 0 (read); partial registers merge; arithmetic is evaluated', () => {
    assert.equal(only(`${ELF64}xor eax, eax\nsyscall`).name, 'read');
    assert.equal(only(`${ELF64}xor eax, eax\nmov al, 60\nsyscall`).name, 'exit');
    assert.equal(only(`${ELF64}mov eax, 58\nadd eax, 2\nsyscall`).name, 'exit');
    assert.equal(only(`${ELF64}mov eax, 61\ndec eax\nsyscall`).name, 'exit');
    assert.equal(only(`${ELF64}mov eax, 30\nshl eax, 1\nsyscall`).name, 'exit');
});

test('push imm / pop reg and register copies are followed', () => {
    assert.equal(only(`${ELF64}push 60\npop rax\nsyscall`).name, 'exit');
    assert.equal(only(`${ELF64}mov ebx, 60\nmov eax, ebx\nsyscall`).name, 'exit');
    assert.equal(only(`${ELF64}mov ebx, 60\nxchg eax, ebx\nsyscall`).name, 'exit');
});

test('named constants (= and equ, also defined after use) are resolved; unresolved ones are not guessed', () => {
    const resolved = only(`${ELF64}mov eax, SYS_exit\nsyscall\nSYS_exit = 60`);
    assert.equal(resolved.name, 'exit');
    assert.equal(only(`${ELF64}mov eax, SYS_write\nsyscall\nSYS_write equ 1`).name, 'write');
    assert.equal(only(`${ELF64}mov eax, SYS_exit\nsyscall`).kind, 'number-unknown');
    assert.equal(only(`${ELF64}mov eax, BASE + 1\nsyscall\nBASE = 59`).name, 'exit');
});

test('labels, calls, jumps, macros, preprocessor lines and unknown instructions forget the register values', () => {
    const cases = {
        label: `${ELF64}mov eax, 60\nagain:\nsyscall`,
        call: `${ELF64}mov eax, 60\ncall helper\nsyscall`,
        jmp: `${ELF64}mov eax, 60\njmp somewhere\nsyscall`,
        macro: `${ELF64}mov eax, 60\nmy_macro eax\nsyscall`,
        conditional: `${ELF64}mov eax, 60\nif defined X\nsyscall`,
        cpuid: `${ELF64}mov eax, 60\ncpuid\nsyscall`,
        load: `${ELF64}mov eax, [number]\nsyscall`,
        mul: `${ELF64}mov eax, 60\nmul ebx\nsyscall`
    };
    for (const [name, source] of Object.entries(cases)) {
        assert.equal(only(source).kind, 'number-unknown', name);
    }
});

test('conditional jumps keep the known value on the fall-through path', () => {
    assert.equal(only(`${ELF64}mov eax, 60\ncmp edi, 0\njz skip\nsyscall`).name, 'exit');
});

test('the result of a syscall is not reused as the next number', () => {
    const { findings } = run(`${ELF64}mov eax, 1\nsyscall\nsyscall`);
    assert.deepEqual(findings.map((f) => f.category), ['valid', 'unverifiable']);
});

test('macro bodies are not treated as code executed in place', () => {
    const source = `${ELF64.replace('start:\n', '')}macro set_exit {\n  mov eax, 60\n}\nstart:\n  syscall`;
    assert.equal(only(source).kind, 'number-unknown');
    const oneLine = `${ELF64.replace('start:\n', '')}macro set_exit { mov eax, 60 }\n  syscall`;
    assert.equal(only(oneLine).kind, 'number-unknown');
});

test('syscall words inside comments and strings are not syscalls; positions cover the instruction', () => {
    assert.equal(run(`${ELF64}db 'syscall', 0\n; syscall\nmsg db "int 0x80"`).findings.length, 0);
    const finding = only(`${ELF64}mov eax, 60\n    syscall ; fine`);
    assert.deepEqual([finding.line, finding.start, finding.end, finding.text], [4, 4, 11, 'syscall']);
    const withInt = only('format ELF executable 3\nmov eax, 1\n  int 0x80');
    assert.deepEqual([withInt.start, withInt.end, withInt.text], [2, 10, 'int 0x80']);
});

test('rep/lock prefixes and labels on the same line do not hide or move the syscall', () => {
    const finding = only(`${ELF64}mov eax, 60\nlast: syscall`);
    assert.equal(finding.category, 'unverifiable'); // l'etichetta azzera lo stato
    assert.equal(finding.start, 6);
});

// ---------------------------------------------------------------------------------------------------------
// Windows
// ---------------------------------------------------------------------------------------------------------

test('Windows without a version: the number is listed per version and flagged not verifiable', () => {
    const finding = only('format PE64 console\nmov eax, 0x18\nsyscall');
    assert.equal(finding.category, 'unverifiable');
    assert.equal(finding.kind, 'windows-version-missing');
    assert.equal(finding.detail.candidates[0].name, 'NtAllocateVirtualMemory');
    assert.match(finding.message, /fasm1\.target\.windowsVersion/);
});

test('Windows with a version: Win10 22H2 NtAllocateVirtualMemory = 0x18, Win7 SP1 = 0x15, win32k from 0x1000', () => {
    const win10 = only('format PE64 console\nmov eax, 0x18\nsyscall', { windowsVersion: 'Windows 10 22H2' });
    assert.deepEqual([win10.category, win10.name], ['valid', 'NtAllocateVirtualMemory']);
    const win7 = only('format PE64 console\nmov eax, 0x15\nsyscall', { windowsVersion: 'Windows 7 SP1' });
    assert.equal(win7.name, 'NtAllocateVirtualMemory');
    const wrong = only('format PE64 console\nmov eax, 0x15\nsyscall', { windowsVersion: 'Windows 10 22H2' });
    assert.notEqual(wrong.name, 'NtAllocateVirtualMemory');
    const gui = only('format PE64 console\nmov eax, 0x1000\nsyscall', { windowsVersion: 'Windows 10 22H2' });
    assert.equal(gui.category, 'valid');
    assert.match(gui.name, /^Nt(User|Gdi)/);
});

test('Windows: a number that exists in no version is unknown; x86 uses int 0x2e / sysenter with the x86 tables', () => {
    assert.equal(only('format PE64 console\nmov eax, 0x7777\nsyscall').category, 'unknown');
    const x86 = only('format PE console\nmov eax, 0x1\nint 0x2e', { windowsVersion: 'Windows XP SP2' });
    assert.equal(x86.category, 'valid');
    assert.match(x86.message, /x86/);
    const missing = only('format PE console\nmov eax, 0x1\nint 0x2e', { windowsVersion: 'Windows 11 24H2' });
    assert.equal(missing.kind, 'windows-version-arch');
    assert.equal(only('format PE console\nmov eax, 1\nsyscall').kind, 'wrong-mode'); // syscall solo a 64 bit
});

test('COFF objects are treated as Windows targets', () => {
    assert.equal(run('format MS64 COFF\nmov eax, 0x18\nsyscall').target.os, 'windows');
});

// ---------------------------------------------------------------------------------------------------------
// KolibriOS / MenuetOS
// ---------------------------------------------------------------------------------------------------------

const KOLIBRI = "use32\norg 0\ndb 'MENUET01'\n";

test('KolibriOS: function numbers come from the kernel table (0 draw window, -1 end, 6 deprecated, 200 undefined)', () => {
    const { findings, target } = run(`${KOLIBRI}mov eax, 0\nint 0x40\nmov eax, -1\nint 0x40\nmov eax, 6\nint 0x40\nmov eax, 200\nint 0x40\nmov eax, 11\nint 0x40`);
    assert.equal(target.os, 'kolibrios');
    assert.deepEqual(findings.map((f) => f.category), ['valid', 'valid', 'invalid-for-target', 'unknown', 'valid']);
    assert.match(findings[0].name, /window/i);
    assert.equal(findings[1].number, 255);
    assert.equal(findings[3].number, 200);
    assert.equal(findings[0].table.repository, 'https://github.com/KolibriOS/kolibrios');
});

test('KolibriOS: only the low byte of eax counts, and the 64-bit mode is not valid', () => {
    const finding = only(`${KOLIBRI}mov eax, 0x100\nint 0x40`);
    assert.equal(finding.number, 0);
    assert.ok(finding.notes.some((note) => /byte basso/.test(note)));
    assert.equal(only('use64\nmov eax, 0\nint 0x40', { os: 'kolibrios' }).kind, 'wrong-mode');
});

test('KolibriOS also exposes syscall and sysenter on the same table (32-bit)', () => {
    assert.equal(only(`${KOLIBRI}mov eax, 5\nsysenter`).name, 'delay');
    assert.equal(only(`${KOLIBRI}mov eax, 5\nsyscall`).category, 'valid');
});

test('MenuetOS: entries are checked but the function table is not shipped, so numbers are not verifiable', () => {
    const finding = only('use64\nmov rax, 1\nint 0x60', { os: 'menuetos' });
    assert.equal(finding.category, 'unverifiable');
    assert.equal(finding.kind, 'no-table');
    assert.equal(only('use64\nmov rax, 1\nint 0x80', { os: 'menuetos' }).kind, 'wrong-entry');
    assert.equal(run("format binary\ndb 'MENUET64'\nmov rax, 1\nint 0x60").target.os, 'menuetos');
});

test('MENUET01 is ambiguous between KolibriOS and MenuetOS: the assumption is stated', () => {
    const finding = only(`${KOLIBRI}mov eax, 0\nint 0x40`);
    assert.ok(finding.target.assumed);
    assert.equal(finding.target.ambiguousWith, 'menuetos');
    assert.ok(finding.notes.some((note) => /MenuetOS/.test(note)));
    assert.equal(only(`${KOLIBRI}mov eax, 0\nint 0x40`, { os: 'menuetos' }).kind, 'no-table');
});

// ---------------------------------------------------------------------------------------------------------
// FreeBSD, ABI ELF senza tabella, target sconosciuto, DOS, impostazioni
// ---------------------------------------------------------------------------------------------------------

test('FreeBSD (ELF ABI 9): write = 4 from syscalls.master; amd64 syscall and i386 int 0x80 share the table', () => {
    const i386 = only('format ELF executable 9\nmov eax, 4\nint 0x80');
    assert.deepEqual([i386.category, i386.name], ['valid', 'write']);
    assert.ok(i386.notes.some((note) => /stack/.test(note)));
    assert.equal(only('format ELF64 executable 9\nmov eax, 1\nsyscall').name, '_exit');
    assert.equal(only('format ELF executable 9\nmov eax, 91\nint 0x80').category, 'invalid-for-target'); // numero riservato
    assert.equal(only('format ELF executable 9\nmov eax, 4000\nint 0x80').category, 'unknown');
});

test('the same number means different things on Linux and FreeBSD', () => {
    assert.equal(only('format ELF executable 3\nmov eax, 4\nint 0x80').name, 'write');
    assert.equal(only('format ELF executable 3\nmov eax, 20\nint 0x80').name, 'getpid');
    // 3 = read su entrambi, ma 5 = open su Linux/FreeBSD, 2 = fork (Linux) / fork (FreeBSD)
    assert.equal(only('format ELF executable 9\nmov eax, 20\nint 0x80').name, 'getpid');
    assert.notEqual(only('format ELF executable 3\nmov eax, 11\nint 0x80').name, only('format ELF executable 9\nmov eax, 11\nint 0x80').name);
});

test('ELF ABIs without a table (NetBSD 2, Solaris 6, ...) are not verifiable and say so', () => {
    for (const abi of [1, 2, 4, 5, 6, 7, 8]) {
        const finding = only(`format ELF executable ${abi}\nmov eax, 1\nint 0x80`);
        assert.equal(finding.category, 'unverifiable', `abi ${abi}`);
        assert.equal(finding.kind, 'no-target');
        assert.match(finding.message, new RegExp(`ABI ${abi}`));
    }
});

test('unknown target (plain binary, ELF object) is not verifiable, never invalid', () => {
    assert.equal(only('mov eax, 1\nint 0x80').kind, 'no-target');
    assert.equal(only('format ELF\nmov eax, 1\nint 0x80').kind, 'no-target');
});

test('the target can be forced from the settings and overrides the format', () => {
    const finding = only('format ELF executable 3\nmov eax, 0\nint 0x40', { os: 'kolibrios' });
    assert.equal(finding.os, 'kolibrios');
    assert.equal(finding.category, 'valid');
    assert.equal(run('format PE console\nmov eax, 1\nsyscall', { os: 'bogus' }).findings[0].category, 'unverifiable');
});

test('DOS (MZ) programs are not analysed: int 21h and friends are not system calls here', () => {
    assert.equal(run('format MZ\nmov ax, 4C00h\nint 21h\nint 0x80').findings.length, 0);
});

test('known entry points of every OS are reachable by name in the tables', () => {
    assert.ok(tables.windowsVersions().includes('Windows 10 22H2'));
    assert.ok(tables.windowsVersions().includes('Windows XP SP2'));
    assert.ok(tables.windowsVersions().length > 40);
    assert.equal(tables.lookupLinux('linux-x86_64', 1).name, 'write');
    assert.equal(tables.lookupKolibri(70).status, 'found');
    assert.equal(tables.lookupFreeBsd(4).name, 'write');
});
