'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const { parseCompilerOutput, findErrorMessage } = require('../../src/build/diagnostics');

const source = path.resolve('main.asm');

test('parses the specified error format and converts to a zero-based line', () => {
    const result = parseCompilerOutput('error: file main.asm line 42: undefined symbol', source);
    assert.deepEqual(result, [{ line: 41, message: 'undefined symbol' }]);
});

test('parses the one-line variant "file [line]: error: message"', () => {
    const result = parseCompilerOutput('main.asm [7]: error: invalid operand', source);
    assert.deepEqual(result, [{ line: 6, message: 'invalid operand' }]);
});

test('parses the multi-line native FASM layout and keeps the real message', () => {
    const output = [
        'flat assembler  version 1.73.32  (1048576 kilobytes memory)',
        'main.asm [7]:',
        'mov eax,',
        'Processed: mov eax,',
        'Error: invalid operand.'
    ].join('\n');
    assert.deepEqual(parseCompilerOutput(output, source), [{ line: 6, message: 'invalid operand.' }]);
});

test('multi-line layout works with CRLF and with spaces in the file name', () => {
    const spaced = path.resolve('my project', 'main file.asm');
    const output = 'main file.asm [3]:\r\nfoo\r\nProcessed: foo\r\nError: undefined symbol \'foo\'.\r\n';
    assert.deepEqual(parseCompilerOutput(output, spaced), [{ line: 2, message: "undefined symbol 'foo'." }]);
});

test('error inside an include is reported on the include line of the open file', () => {
    const output = [
        'main.asm [5]:',
        "include 'lib.inc'",
        'lib.inc [3]:',
        'bad line',
        'Processed: bad line',
        'Error: illegal instruction.'
    ].join('\n');
    assert.deepEqual(parseCompilerOutput(output, source), [
        { line: 4, message: 'illegal instruction.', via: 'lib.inc riga 3' }
    ]);
});

test('ignores diagnostics belonging only to included files', () => {
    assert.deepEqual(parseCompilerOutput('library.inc [3]: error: unknown name', source), []);
    assert.deepEqual(parseCompilerOutput('library.inc [3]:\nx\nError: unknown name.', source), []);
});

test('a second error block does not inherit the previous location', () => {
    const output = 'main.asm [2]:\nx\nError: first.\nError: orphan.';
    assert.deepEqual(parseCompilerOutput(output, source), [{ line: 1, message: 'first.' }]);
});

test('findErrorMessage returns errors that have no location', () => {
    assert.equal(findErrorMessage('flat assembler version 1.73\nError: source file not found.'), 'source file not found.');
    assert.equal(findErrorMessage('2 passes, 42 bytes.'), null);
});
