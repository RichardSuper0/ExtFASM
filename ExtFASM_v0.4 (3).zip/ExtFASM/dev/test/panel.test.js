'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { execFileSync } = require('node:child_process');
const { DebuggerPanel } = require('../../src/deepdebug/panel');

const FASM = [process.env.FASM_BIN, '/home/claude/fasm_real/fasm/fasm.x64'].filter(Boolean).find((file) => fs.existsSync(file));
const hasGdb = (() => { try { execFileSync('gdb', ['--version'], { stdio: 'ignore' }); return true; } catch { return false; } })();

const SOURCE = 'format ELF64 executable 3\nentry start\nsegment readable executable\nstart:\n mov eax, 60\n xor edi, edi\n syscall\n';

function setup(source = SOURCE, config = {}) {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'extfasm panel '));
    const file = path.join(dir, 'main.asm');
    fs.writeFileSync(file, source);
    const posted = [];
    const handlers = {};
    const panel = { webview: { html: '', postMessage: (message) => posted.push(message), onDidReceiveMessage: (handler) => { handlers.message = handler; } }, reveal() { }, onDidDispose: (handler) => { handlers.dispose = handler; } };
    const vscode = { ViewColumn: { Beside: 2 }, window: { createWebviewPanel: () => panel, showInformationMessage: (message) => posted.push({ info: message }) } };
    const document = { uri: { fsPath: file, toString: () => `file://${file}` }, getText: () => fs.readFileSync(file, 'utf8') };
    const calls = { confirm: 0, reveal: [] };
    const host = {
        settings: () => ({ get: (key, fallback) => (key in config ? config[key] : fallback) }),
        isTrusted: () => true,
        diagnostics: () => ({ assembler: [{ range: { start: { line: 4, character: 0 } }, message: 'illegal instruction.', severity: 0 }], static: [], syscall: [] }),
        lastRun: () => null,
        outputPathFor: () => path.join(dir, 'main'),
        assemble: async () => {
            execFileSync(FASM, [file, path.join(dir, 'main')], { stdio: 'ignore' });
            return { outputPath: path.join(dir, 'main'), format: { kind: 'elf64' } };
        },
        confirmRun: async () => { calls.confirm += 1; return true; },
        runMeasured: async () => null,
        reveal: (uri, line, column) => calls.reveal.push([line, column])
    };
    const debuggerPanel = new DebuggerPanel({ vscode, host });
    debuggerPanel.open(document);
    return { dir, posted, handlers, debuggerPanel, calls };
}
const last = (posted, type) => posted.filter((message) => message.type === type).pop();
const settle = (ms = 300) => new Promise((resolve) => setTimeout(resolve, ms));

test('panel: html has a strict CSP; on ready it sends labels and the four sections of data', async () => {
    const { dir, posted, handlers, debuggerPanel } = setup();
    try {
        assert.match(debuggerPanel.panel.webview.html, /Content-Security-Policy.*default-src 'none'/);
        assert.doesNotMatch(debuggerPanel.panel.webview.html, /<script src=/);
        await handlers.message({ command: 'ready' });
        await settle(600);
        assert.ok(posted.find((message) => message.type === 'init').labels['dbg.tab.commits']);
        assert.equal(last(posted, 'errors').data.items[0].origin, 'assembler');
        assert.equal(last(posted, 'commits').data.available, false); // cartella temporanea: nessun repository o file non tracciato
        const resources = last(posted, 'resources').data;
        assert.equal(resources.sourceSize, SOURCE.length);
        assert.equal(resources.binarySize, null);
        assert.ok(resources.hardware.cpu.logicalCores > 0);
        assert.ok(last(posted, 'registers'));
        await handlers.message({ command: 'goto', line: 4, column: 2 });
        await handlers.message({ command: 'goto', line: -1, column: 0 });
    } finally {
        fs.rmSync(dir, { recursive: true, force: true });
    }
});

test('panel: registers need an ELF target; a PE file is explained, nothing is started', { skip: process.platform !== 'linux' }, async () => {
    const { dir, posted, handlers, calls } = setup('format PE console\nentry start\nsection \'.text\' code readable executable\nstart:\n nop\n');
    try {
        await handlers.message({ command: 'ready' });
        await settle(400);
        const registers = last(posted, 'registers').data;
        assert.equal(registers.unsupported.key, 'dbg.reg.unsupported.format');
        await handlers.message({ command: 'regStart' });
        await settle(200);
        assert.equal(calls.confirm, 0);
    } finally {
        fs.rmSync(dir, { recursive: true, force: true });
    }
});

test('panel: registers through a real gdb session (step changes are flagged, process end becomes a snapshot)', { skip: !FASM || !hasGdb || process.platform !== 'linux' ? 'needs Linux + fasm + gdb' : false }, async () => {
    const { dir, posted, handlers, debuggerPanel, calls } = setup();
    try {
        await handlers.message({ command: 'ready' });
        await settle(500);
        await handlers.message({ command: 'regStart' });
        let data = last(posted, 'registers').data;
        assert.equal(calls.confirm, 1);
        assert.equal(data.snapshot.status, 'live');
        assert.equal(data.snapshot.arch, 'x86-64');
        assert.equal(data.snapshot.pc.name, 'rip');
        assert.match(data.snapshot.instruction.text, /mov\s+eax,0x3c/);
        await handlers.message({ command: 'regStep', count: 1 });
        data = last(posted, 'registers').data;
        const rax = data.snapshot.registers.find((register) => register.name === 'rax');
        assert.equal(rax.hex, '0x3c');
        assert.equal(rax.changed, true);
        await handlers.message({ command: 'regContinue' });
        data = last(posted, 'registers').data;
        assert.equal(data.snapshot.status, 'snapshot');
        assert.equal(data.snapshot.exit.code, 0);
        assert.equal(data.snapshot.registers.every((register) => register.changed === false), true);
        debuggerPanel.stopSession();
    } finally {
        fs.rmSync(dir, { recursive: true, force: true });
    }
});

test('panel: disabled in the settings -> not opened', () => {
    const { dir, posted, debuggerPanel } = setup(SOURCE, { 'deepDebug.enabled': false });
    try {
        assert.equal(debuggerPanel.panel, null);
        assert.ok(posted.some((message) => message.info));
    } finally {
        fs.rmSync(dir, { recursive: true, force: true });
    }
});
