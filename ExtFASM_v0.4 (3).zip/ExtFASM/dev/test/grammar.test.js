'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { INSTRUCTIONS } = require('../../src/analysis/instructions');

const grammar = JSON.parse(fs.readFileSync(path.join(__dirname, '..', '..', 'syntaxes', 'fasm1.tmLanguage.json'), 'utf8'));

/**
 * Mini-tokenizer TextMate (una riga alla volta, regole `match` e `begin/end` su riga singola).
 * Usa le RegExp di JavaScript, non Oniguruma: è un controllo di regressione sulle regole,
 * non un sostituto della prova in VS Code.
 */
function compile(source) {
    const flags = source.startsWith('(?i)') ? 'iyd' : 'yd';
    return new RegExp(source.replace(/^\(\?i\)/, ''), flags);
}

function flatten(patterns) {
    const rules = [];
    for (const entry of patterns) {
        if (entry.include) {
            rules.push(...flatten(grammar.repository[entry.include.slice(1)].patterns || [grammar.repository[entry.include.slice(1)]]));
        } else {
            rules.push(entry);
        }
    }
    return rules;
}

function tokenize(line) {
    const rules = flatten(grammar.patterns).map((rule) => ({
        rule,
        regex: compile(rule.match || rule.begin),
        end: rule.end ? compile(rule.end) : null
    }));
    const tokens = [];
    let position = 0;
    while (position < line.length) {
        let best = null;
        for (let start = position; start < line.length && !best; start += 1) {
            for (const candidate of rules) {
                candidate.regex.lastIndex = start;
                const match = candidate.regex.exec(line);
                if (match && match[0].length > 0) {
                    best = { candidate, start, match };
                    break;
                }
            }
        }
        if (!best) {
            break;
        }
        let end = best.start + best.match[0].length;
        if (best.candidate.end) {
            best.candidate.end.lastIndex = end;
            let closing = null;
            for (let index = end; index <= line.length; index += 1) {
                best.candidate.end.lastIndex = index;
                const m = best.candidate.end.exec(line);
                if (m) {
                    closing = index + m[0].length;
                    break;
                }
            }
            end = closing === null ? line.length : closing;
        }
        if (best.candidate.rule.captures) {
            // Regole con `captures`: un token per gruppo (come fa TextMate).
            for (const [group, capture] of Object.entries(best.candidate.rule.captures)) {
                const [from, to] = best.match.indices[Number(group)];
                tokens.push({ text: line.slice(from, to), scope: capture.name.replace('.fasm1', '') });
            }
        } else {
            tokens.push({ text: line.slice(best.start, end), scope: best.candidate.rule.name.replace('.fasm1', '') });
        }
        position = end;
    }
    return tokens;
}

// Le sottocategorie (es. keyword.instruction.flow, variable.language.register.vector, constant.numeric.hex)
// si riconducono alla famiglia, così i test verificano "è un'istruzione", "è un registro", "è un numero".
const FAMILIES = ['keyword.instruction', 'variable.language.register', 'constant.numeric'];
const familyOf = (scope) => FAMILIES.find((family) => scope === family || scope?.startsWith(family + '.')) ?? scope;
const scopeOf = (line, text) => familyOf(tokenize(line).find((token) => token.text === text)?.scope);

test('every mnemonic known to the analyzer is highlighted as an instruction', () => {
    const missing = [...INSTRUCTIONS].filter((name) => scopeOf(`  ${name} eax`, name) !== 'keyword.instruction');
    assert.deepEqual(missing, []);
});

test('syscall, jmp and ret are instructions (they were missing before)', () => {
    for (const name of ['syscall', 'jmp', 'ret', 'cpuid']) {
        assert.equal(scopeOf(`  ${name}`, name), 'keyword.instruction', name);
    }
});

test('labels: with colon, with a space before the colon, anonymous, and data labels', () => {
    assert.equal(scopeOf('start:', 'start'), 'entity.name.label');
    assert.equal(scopeOf('start : ', 'start'), 'entity.name.label');
    assert.equal(scopeOf('@@: jmp @b', '@@'), 'entity.name.label');
    assert.equal(scopeOf('msg db "hi", 10', 'msg'), 'entity.name.label.data');
});

test('a mnemonic after a label is still an instruction, and a label may shadow a mnemonic name', () => {
    assert.equal(scopeOf('loop: rep movsb', 'rep'), 'storage.modifier.prefix');
    assert.equal(scopeOf('loop: rep movsb', 'movsb'), 'keyword.instruction');
    assert.equal(scopeOf('loop: rep movsb', 'loop'), 'entity.name.label');
});

test('strings use both quote kinds, have no escapes, and hide semicolons', () => {
    const tokens = tokenize("db 'it''s; ok', 10 ; real comment");
    assert.ok(tokens.some((token) => token.scope === 'string.quoted.single' && token.text.includes('; ok')));
    assert.equal(tokens.at(-1).scope, 'comment.line.semicolon');
    assert.ok(tokenize('db "a\\", 1').some((token) => token.scope === 'string.quoted.double' && token.text === '"a\\"'));
});

test('numbers in FASM notations and registers (including r8d, sil, rip)', () => {
    for (const number of ['0x1F', '0FFh', '$1F', '101b', '17o', '42']) {
        assert.equal(scopeOf(`  mov eax, ${number}`, number), 'constant.numeric', number);
    }
    for (const register of ['r8d', 'sil', 'rip', 'rax', 'st0']) {
        assert.equal(scopeOf(`  lea rax, [${register}]`, register), 'variable.language.register', register);
    }
});

test('a name that merely starts like a mnemonic is not highlighted', () => {
    assert.equal(scopeOf('  call movement', 'movement'), undefined);
});

test('SIMD, AVX and AVX-512 mnemonics and registers come from the real FASM tables', () => {
    for (const name of ['movaps', 'pshufb', 'vaddps', 'vfmadd231ps', 'vpternlogd', 'vgf2p8affineinvqb', 'aesenc', 'cmovz', 'jz']) {
        assert.equal(scopeOf(`  ${name} xmm0, xmm1`, name), 'keyword.instruction', name);
    }
    for (const register of ['xmm15', 'ymm31', 'zmm0', 'k7', 'cr8', 'dr7', 'bnd1', 'mm3']) {
        assert.equal(scopeOf(`  mov rax, ${register}`, register), 'variable.language.register', register);
    }
    assert.equal(scopeOf('  vaddps zmm0{k1}{z}, zmm1, zmm2', '{k1}'), 'storage.modifier.evex');
    assert.equal(scopeOf('  vaddps zmm0, zmm1, zmm2{rn-sae}', '{rn-sae}'), 'storage.modifier.evex');
});

test('names that are not FASM registers are not highlighted as such (eflags, ip, flags)', () => {
    for (const name of ['eflags', 'rflags', 'ip', 'flags']) {
        assert.equal(scopeOf(`  mov ax, ${name}`, name), undefined, name);
    }
});

test('built-in format declarations: every keyword of the real format table has its own scope', () => {
    const line = "format PE GUI 4.0 DLL at 7000000h on 'stub.exe'";
    assert.equal(scopeOf(line, 'format'), 'keyword.control.directive');
    for (const name of ['PE', 'GUI', 'DLL']) {
        assert.equal(scopeOf(line, name), 'support.type.format', name);
    }
    assert.equal(scopeOf(line, 'at'), 'keyword.operator.word');
    assert.equal(scopeOf(line, 'on'), 'keyword.operator.word');
    assert.equal(scopeOf(line, '4.0'), 'constant.numeric');
    assert.equal(scopeOf(line, "'stub.exe'"), 'string.quoted.single');
    assert.equal(scopeOf("format ELF64 executable 3", 'executable'), 'storage.modifier.section');
    assert.equal(scopeOf("format binary as 'KEK'", 'binary'), 'support.type.format');
    assert.equal(scopeOf("format MS64 COFF", 'MS64'), 'support.type.format');
});

test('sections and segments: flags, special PE data and special ELF segments', () => {
    const pe = "section '.text' code readable executable";
    assert.equal(scopeOf(pe, 'section'), 'keyword.control.directive');
    for (const flag of ['code', 'readable', 'executable']) {
        assert.equal(scopeOf(pe, flag), 'storage.modifier.section', flag);
    }
    assert.equal(scopeOf("section '.idata' import data readable writeable", 'import'), 'support.type.format');
    assert.equal(scopeOf("section '.reloc' data readable discardable fixups", 'fixups'), 'support.type.format');
    assert.equal(scopeOf('segment readable executable', 'segment'), 'keyword.control.directive');
    assert.equal(scopeOf('segment interpreter readable', 'interpreter'), 'support.type.format');
    assert.equal(scopeOf('segment gnustack writeable', 'gnustack'), 'support.type.format');
    assert.equal(scopeOf('data import', 'data'), 'keyword.control.directive');
});

test('data directives (raw headers use them) have their own scope, including du, dp, rb…', () => {
    for (const name of ['db', 'dw', 'dd', 'dq', 'dt', 'du', 'dp', 'df', 'rb', 'rw', 'rd', 'rq', 'file']) {
        assert.equal(scopeOf(`  ${name} 1`, name), 'storage.type.data', name);
    }
    assert.equal(scopeOf("  db 0x7F, 'ELF', 2, 1, 1, 3", 'db'), 'storage.type.data');
    assert.equal(scopeOf('  dd 64 dup (0)', 'dup'), 'keyword.operator.word');
    assert.equal(scopeOf('  org 0x400000', 'org'), 'keyword.control.directive');
});

test('preprocessor directives and special symbols', () => {
    for (const name of ['macro', 'struc', 'match', 'irp', 'rept', 'purge', 'local', 'forward', 'common', 'reverse', 'define', 'include', 'restore']) {
        assert.equal(scopeOf(`${name} x`, name), 'keyword.control.preprocessor', name);
    }
    assert.equal(scopeOf('  dd $ - $$', '$'), 'constant.language');
    assert.equal(scopeOf('  dd $$', '$$'), 'constant.language');
    assert.equal(scopeOf('  dd $%', '$%'), 'constant.language');
});

test('use16 / use32 / use64 and size words', () => {
    for (const mode of ['use16', 'use32', 'use64']) {
        assert.equal(scopeOf(mode, mode), 'keyword.control.directive', mode);
    }
    assert.equal(scopeOf('  mov dword [eax], 1', 'dword'), 'storage.type.size');
    assert.equal(scopeOf('  jmp short done', 'short'), 'storage.type.size');
});

test('$%% and the other position symbols are a single token', () => {
    assert.equal(scopeOf('  dd $%%', '$%%'), 'constant.language');
    assert.equal(scopeOf('  dd $%', '$%'), 'constant.language');
});

test('rich highlighting: instruction categories, register classes, number bases, local labels, memory brackets, macro names', () => {
    const raw = (line, text) => tokenize(line).find((token) => token.text === text)?.scope;
    assert.equal(raw('  jmp short done', 'jmp'), 'keyword.instruction.flow');
    assert.equal(raw('  call func', 'call'), 'keyword.instruction.flow');
    assert.equal(raw('  push rbp', 'push'), 'keyword.instruction.stack');
    assert.equal(raw('  mov eax, 1', 'mov'), 'keyword.instruction.move');
    assert.equal(raw('  add eax, 1', 'add'), 'keyword.instruction.arith');
    assert.equal(raw('  xor eax, eax', 'xor'), 'keyword.instruction.logic');
    assert.equal(raw('  fld dword [x]', 'fld'), 'keyword.instruction.fpu');
    assert.equal(raw('  vaddps ymm0, ymm1, ymm2', 'vaddps'), 'keyword.instruction.simd');
    assert.equal(raw('  cli', 'cli'), 'keyword.instruction.system');
    assert.equal(raw('  mov rax, rbx', 'rax'), 'variable.language.register.general');
    assert.equal(raw('  mov ax, ds', 'ds'), 'variable.language.register.segment');
    assert.equal(raw('  vmovdqa xmm0, xmm1', 'xmm1'), 'variable.language.register.vector');
    assert.equal(raw('  fld st0', 'st0'), 'variable.language.register.fpu');
    assert.equal(raw('  mov cr3, rax', 'cr3'), 'variable.language.register.special');
    assert.equal(raw('  mov eax, 0x1F', '0x1F'), 'constant.numeric.hex');
    assert.equal(raw('  mov eax, 101b', '101b'), 'constant.numeric.binary');
    assert.equal(raw('  mov eax, 42', '42'), 'constant.numeric.decimal');
    assert.equal(raw('  dd 1.5', '1.5'), 'constant.numeric.float');
    assert.equal(raw('.loop:', '.loop'), 'entity.name.label.local');
    assert.equal(raw('  mov eax, [rbx]', '['), 'punctuation.section.memory');
    assert.equal(raw('macro print x', 'print'), 'entity.name.function.macro');
});

test('language contribution: named "Assembly FASM 1", with default colors scoped to this language only', () => {
    const pkg = require('../../package.json');
    assert.equal(pkg.contributes.languages[0].aliases[0], 'Assembly FASM 1');
    const defaults = pkg.contributes.configurationDefaults['[fasm1]'];
    assert.ok(defaults['editor.tokenColorCustomizations'].textMateRules.length >= 15);
});
