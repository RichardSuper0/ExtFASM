'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { predict } = require('../../src/analysis/prediction');
require('../../src/i18n/i18n').setLanguage('en');

/** Cursore alla fine del testo (riga vuota finale). */
const at = (source, options) => {
    const lines = source.split('\n');
    return predict(source, { line: lines.length - 1, character: lines[lines.length - 1].length }, { level: 'all', ...options }).suggestions;
};
const labels = (source, options) => at(source, options).map((item) => item.label);
const ELF64 = 'format ELF64 executable 3\nentry start\nsegment readable executable\nstart:\n';

test('syscall: the next missing argument register comes from the real prototype and ABI', () => {
    const found = at(`${ELF64} mov rax, 1\n `);
    assert.deepEqual(found.map((item) => item.label), ['mov rdi, fd', 'mov rsi, buf', 'mov rdx, count']);
    assert.match(found[0].reason, /write\(fd, buf, count\)/);
    assert.match(found[0].reason, /rdi on Linux x86-64/);
    assert.equal(found[0].confidence, 'likely');
});

test('syscall: with every argument prepared the kernel entry is proposed with certainty', () => {
    const found = at(`${ELF64} mov rax, 1\n mov rdi, 1\n mov rsi, msg\n mov rdx, 5\n `);
    assert.deepEqual(found.map((item) => [item.label, item.confidence]), [['syscall', 'certain']]);
});

test('syscall: exit still needs its argument; xor idiom counts as preparing the register', () => {
    assert.deepEqual(labels(`${ELF64} mov rax, 60\n `), ['mov rdi, error_code']);
    assert.deepEqual(labels(`${ELF64} mov rax, 60\n xor edi, edi\n `), ['syscall']);
});

test('syscall: 32-bit Linux uses int 0x80 and its own register order and table', () => {
    const source = 'format ELF executable 3\nsegment readable executable\nstart:\n mov eax, 4\n mov ebx, 1\n mov ecx, msg\n mov edx, 5\n ';
    assert.deepEqual(labels(source), ['int 0x80']);
    assert.deepEqual(labels('format ELF executable 3\nsegment readable executable\nstart:\n mov eax, 4\n ').slice(0, 1), ['mov ebx, fd']);
});

test('syscall: an unknown number, an unset number or a call right after a syscall give no suggestion', () => {
    assert.deepEqual(labels(`${ELF64} mov rax, 99999\n `), []);
    assert.deepEqual(labels(`${ELF64} mov rdi, 1\n `), []);
    assert.deepEqual(labels(`${ELF64} mov rax, 1\n mov rdi, 1\n mov rsi, m\n mov rdx, 1\n syscall\n `), []);
});

test('syscall: Windows targets get no guess (numbers depend on the build)', () => {
    assert.deepEqual(labels('format PE64 console\nsection \'.text\' code readable executable\nstart:\n mov eax, 1\n '), []);
});

test('syscall: a target that is only assumed lowers the confidence and says so', () => {
    const found = at('format ELF64 executable\nsegment readable executable\nstart:\nmov rax, 1\nmov rdi, 1\nmov rsi, m\nmov rdx, 1\n');
    assert.equal(found[0].label, 'syscall');
    assert.notEqual(found[0].confidence, 'certain');
    assert.match(found[0].reason, /assumed/);
});

test('stack: frame, reverse pops, ret', () => {
    assert.deepEqual(labels(`${ELF64} push rbp\n `), ['mov rbp, rsp']);
    assert.deepEqual(labels(`${ELF64} push rbx\n push r12\n pop r12\n `), ['pop rbx']);
    assert.deepEqual(labels(`${ELF64} push rbx\n pop rbx\n `), ['ret']);
    assert.deepEqual(labels(`${ELF64} leave\n `), ['ret']);
    assert.deepEqual(labels(`${ELF64} push rbx\n push r12\n pop rbx\n `), []); // ordine sbagliato: nessuna ipotesi
});

test('flags: test reg,reg proposes jz/jnz; cmp proposes jumps marked uncertain', () => {
    assert.deepEqual(labels(`${ELF64} test eax, eax\n `).slice(0, 2), ['jz label', 'jnz label']);
    const cmp = at(`${ELF64} cmp eax, 1\n `);
    assert.ok(cmp.length > 4 && cmp.every((item) => item.confidence === 'uncertain'));
    assert.deepEqual(at(`${ELF64} cmp eax, 1\n `, { level: 'likely' }), []);
});

test('level filter: certain keeps only verified suggestions', () => {
    assert.deepEqual(at(`${ELF64} mov rax, 1\n `, { level: 'certain' }), []);
    assert.deepEqual(labels(`${ELF64} mov rax, 60\n xor edi, edi\n `, { level: 'certain' }), ['syscall']);
});

test('built-in format: skeleton follows measured availability and what is already written', () => {
    assert.deepEqual(labels('format ELF64 executable 3\n'), ['segment readable executable', 'entry start']);
    assert.deepEqual(labels('format ELF64 executable 3\nentry start\n'), ['segment readable executable']);
    assert.deepEqual(labels('format ELF64 executable 3\nentry start\nsegment readable executable\n'), ['start:']);
    assert.deepEqual(labels("format PE console\n").sort(), ["entry start", "section '.text' code readable executable"].sort());
    assert.ok(!labels('format ELF executable 3\n').some((label) => label.startsWith('section')), 'ELF executable has no `section` in fasm 1');
    assert.deepEqual(labels("format MS COFF\n"), ["section '.text' code"]);
    assert.deepEqual(labels('format MZ\n'), ['segment main']);
});

test('built-in format: no `format` yet offers the choices as uncertain; code already written offers none', () => {
    const choices = at('');
    assert.ok(choices.some((item) => item.label === 'format ELF64 executable 3'));
    assert.ok(choices.every((item) => item.confidence === 'uncertain'));
    assert.deepEqual(labels('nop\n').filter((label) => label.startsWith('format')), []);
});

test('raw ELF64 header: next field, value consistent with what was written', () => {
    const header = 'db 0x7f, "ELF", 2, 1, 1, 0\ndq 0\n';
    const found = at(`${header}dw 2\n`);
    assert.equal(found[0].label, 'dw 62 ; e_machine');
    assert.equal(found[0].confidence, 'certain');
    assert.match(found[0].reason, /EI_CLASS = 2/);
    assert.equal(at('db 0x7f, "ELF"\n')[0].label.endsWith('EI_CLASS'), true);
    assert.deepEqual(labels(`${header}dw 2, 62\n`), ['dd 1 ; e_version']);
});

test('raw ELF32 header uses the 32-bit layout', () => {
    const found = at('db 0x7f, "ELF", 1, 1, 1, 0\ndq 0\ndw 2, 3\ndd 1\n');
    assert.match(found[0].label, /^dd \$?\{?.*start.*e_entry|^dd start ; e_entry$/);
    const sizes = at('db 0x7f, "ELF", 1, 1, 1, 0\ndq 0\ndw 2, 3\ndd 1\ndd 0, 52, 0, 0\n');
    assert.equal(sizes[0].label, 'dw 52 ; e_ehsize');
});

test('raw PE header: signature at e_lfanew, then COFF fields coherent with Machine', () => {
    const dos = 'db "MZ"\ndw 29 dup 0\ndd 0x40\n';
    assert.deepEqual(labels(dos), ["db 'PE', 0, 0 ; Signature"]);
    const withMachine = at(`${dos}db "PE", 0, 0\ndw 0x8664\n`);
    assert.equal(withMachine[0].label, 'dw ${1:count} ; NumberOfSections'.replace('${1:count}', 'count'));
    const size = at(`${dos}db "PE", 0, 0\ndw 0x8664, 1\ndd 0, 0, 0\n`);
    assert.equal(size[0].label, 'dw 240 ; SizeOfOptionalHeader');
});

test('raw MENUET01 header fields', () => {
    assert.equal(labels('db "MENUET01"\n')[0], 'dd 1 ; header version');
});

test('no suggestion while typing operands, in comments, inside macro bodies', () => {
    assert.deepEqual(predict(`${ELF64} mov rax, 1\n mov r`, { line: 5, character: 6 }).suggestions, []);
    assert.deepEqual(predict(`${ELF64} mov rax, 1\n ; `, { line: 5, character: 3 }).suggestions, []);
    assert.deepEqual(labels('macro m {\n  mov rax, 1\n  '), []);
});

test('typed prefix filters the suggestions', () => {
    const source = `${ELF64} mov rax, 1\n mov rd`;
    const lines = source.split('\n');
    const found = predict(source, { line: lines.length - 1, character: lines[lines.length - 1].length }, { level: 'all' }).suggestions;
    assert.deepEqual(found.map((item) => item.label), ['mov rdi, fd', 'mov rdx, count'].filter(() => false));
});

test('reasons are translated; the engine never returns percentages', () => {
  const { setLanguage } = require('../../src/i18n/i18n');
  try {
    setLanguage('it');
    assert.match(at(`${ELF64} push rbp\n `)[0].reason, /apre un frame/);
    setLanguage('de');
    assert.match(at(`${ELF64} push rbp\n `)[0].reason, /öffnet einen Frame/);
  } finally {
    setLanguage('en');
  }
  for (const item of at(`${ELF64} mov rax, 1\n `)) assert.doesNotMatch(item.reason + item.detail, /%/);
});
