'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { execFileSync } = require('node:child_process');
const { readFileHistory } = require('../../src/deepdebug/git');

let hasGit = true;
try {
    execFileSync('git', ['--version'], { stdio: 'ignore' });
} catch {
    hasGit = false;
}
const skip = hasGit ? false : 'git non disponibile';

function makeRepo() {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'extfasm git '));
    const run = (...args) => execFileSync('git', ['-C', dir, '-c', 'user.name=T', '-c', 'user.email=t@example.com', '-c', 'commit.gpgsign=false', ...args], { stdio: 'pipe' });
    run('init', '-q');
    return { dir, run };
}
const commit = (run, date, message) => {
    run('add', '-A');
    execFileSync('git', ['-C', run.dirPath, '-c', 'user.name=T', '-c', 'user.email=t@example.com', '-c', 'commit.gpgsign=false', 'commit', '-q', '-m', message], {
        stdio: 'pipe', env: { ...process.env, GIT_AUTHOR_DATE: date, GIT_COMMITTER_DATE: date }
    });
};

test('history: sizes per commit, deltas, renames followed, uncommitted changes flagged', { skip }, async () => {
    const { dir, run } = makeRepo();
    run.dirPath = dir;
    try {
        fs.writeFileSync(path.join(dir, 'a.asm'), 'nop\n');
        commit(run, '2024-01-01T10:00:00Z', 'first');
        fs.writeFileSync(path.join(dir, 'a.asm'), 'nop\nnop\nnop\n');
        commit(run, '2024-01-02T10:00:00Z', 'second');
        run('mv', 'a.asm', 'main file.asm');
        commit(run, '2024-01-03T10:00:00Z', 'rename');
        fs.writeFileSync(path.join(dir, 'main file.asm'), 'nop\n'.repeat(10));
        const history = await readFileHistory({ file: path.join(dir, 'main file.asm'), maxCommits: 10 });
        assert.equal(history.available, true);
        assert.deepEqual(history.commits.map((item) => item.subject), ['rename', 'second', 'first']);
        assert.deepEqual(history.commits.map((item) => item.status), ['R', 'M', 'A']);
        assert.deepEqual(history.commits.map((item) => item.size), [12, 12, 4]);
        assert.deepEqual(history.commits.map((item) => item.delta), [0, 8, null]);
        assert.equal(history.commits[0].oldPath, 'a.asm');
        assert.equal(history.commits[0].time, Date.parse('2024-01-03T10:00:00Z') / 1000);
        assert.equal(history.worktree.size, 40);
        assert.equal(history.worktree.dirty, true);
        assert.equal(history.truncated, false);
        const limited = await readFileHistory({ file: path.join(dir, 'main file.asm'), maxCommits: 2 });
        assert.equal(limited.commits.length, 2);
        assert.equal(limited.truncated, true);
    } finally {
        fs.rmSync(dir, { recursive: true, force: true });
    }
});

test('history: not a repository, untracked file and missing git are reported, never invented', { skip }, async () => {
    const plain = fs.mkdtempSync(path.join(os.tmpdir(), 'extfasm nogit '));
    try {
        fs.writeFileSync(path.join(plain, 'a.asm'), 'nop\n');
        const outside = await readFileHistory({ file: path.join(plain, 'a.asm'), gitPath: 'git' });
        // La cartella temporanea potrebbe stare dentro un repository del sistema: in tal caso il file non è tracciato.
        assert.equal(outside.available, false);
        assert.ok(['not-a-repository', 'not-tracked'].includes(outside.reason));
        const missing = await readFileHistory({ file: path.join(plain, 'a.asm'), gitPath: path.join(plain, 'no-such-git') });
        assert.deepEqual(missing, { available: false, reason: 'git-missing' });
    } finally {
        fs.rmSync(plain, { recursive: true, force: true });
    }
    const { dir, run } = makeRepo();
    try {
        fs.writeFileSync(path.join(dir, 'a.asm'), 'nop\n');
        void run;
        const untracked = await readFileHistory({ file: path.join(dir, 'a.asm') });
        assert.equal(untracked.available, false);
        assert.ok(['not-tracked', 'error'].includes(untracked.reason));
    } finally {
        fs.rmSync(dir, { recursive: true, force: true });
    }
});

test('history: deleted-then-restored files mark the deleting commit without a size', { skip }, async () => {
    const { dir, run } = makeRepo();
    run.dirPath = dir;
    try {
        const file = path.join(dir, 'a.asm');
        fs.writeFileSync(file, 'nop\n');
        commit(run, '2024-02-01T10:00:00Z', 'add');
        fs.rmSync(file);
        commit(run, '2024-02-02T10:00:00Z', 'remove');
        fs.writeFileSync(file, 'nop\nnop\n');
        commit(run, '2024-02-03T10:00:00Z', 'restore');
        const history = await readFileHistory({ file });
        assert.deepEqual(history.commits.map((item) => [item.subject, item.status, item.size]), [['restore', 'A', 8], ['remove', 'D', null], ['add', 'A', 4]]);
    } finally {
        fs.rmSync(dir, { recursive: true, force: true });
    }
});
