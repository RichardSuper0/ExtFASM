'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
require('../../src/i18n/i18n').setLanguage('en');
const { buildErrorList } = require('../../src/deepdebug/errors');

const diag = (line, start, message, severity, code) => ({ range: { start: { line, character: start } }, message, severity, code });

test('every error keeps its origin; assembler errors have a line but no column', () => {
    const list = buildErrorList({
        assembler: [diag(4, 0, 'illegal instruction.', 0)],
        static: [diag(2, 6, 'unclosed string', 1, 'FASM_UNCLOSED_STRING')],
        syscall: [diag(7, 2, 'unknown syscall', 1, 'FASM_SYSCALL_UNKNOWN')],
        run: null
    });
    assert.deepEqual(list.map((item) => [item.origin, item.line, item.column, item.severity]), [
        ['assembler', 5, null, 'error'], ['static', 3, 7, 'warning'], ['syscall', 8, 3, 'warning']
    ]);
    assert.match(list[0].reason, /real fasm assembler/);
    assert.match(list[1].reason, /FASM_UNCLOSED_STRING/);
    assert.match(list[2].reason, /does not predict/);
});

test('runtime problems are separate from compile errors and have no source position', () => {
    assert.deepEqual(buildErrorList({ run: { exitCode: 0, signal: null, error: null } }), []);
    const [crash] = buildErrorList({ run: { exitCode: null, signal: 'SIGSEGV', error: null } });
    assert.equal(crash.origin, 'runtime');
    assert.equal(crash.line, null);
    assert.match(crash.message, /SIGSEGV/);
    const [nonZero] = buildErrorList({ run: { exitCode: 3, signal: null, error: null } });
    assert.equal(nonZero.severity, 'warning');
    assert.match(nonZero.message, /: 3\./);
    const [spawnFail] = buildErrorList({ run: { exitCode: null, signal: null, error: 'EACCES' } });
    assert.match(spawnFail.message, /EACCES/);
});

test('the list is recomputed from the current diagnostics: a fixed error disappears', () => {
    assert.equal(buildErrorList({ assembler: [diag(0, 0, 'x', 0)] }).length, 1);
    assert.equal(buildErrorList({ assembler: [] }).length, 0);
});

test('ordered by origin, then line, then severity', () => {
    const list = buildErrorList({ static: [diag(9, 0, 'b', 1), diag(1, 0, 'a', 1), diag(1, 0, 'e', 0)] });
    assert.deepEqual(list.map((item) => item.message), ['e', 'a', 'b']);
});
