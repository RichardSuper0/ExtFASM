format binary as 'exe'
use16
org 0
    db 'MZ'
    dw last_page, pages, 0, 4, 0, 0xFFFF, 0, 0x100, 0, 0, 0, 0x1C, 0
    dw 0, 0, 0, 0
    nop
last_page = 16
pages = 1
