; PE32 console scritto a mano
format binary as 'exe'
use32
org 0x400000

dos:
    db 'MZ'
    times 0x3C - ($ - dos) db 0
    dd pe - dos                         ; e_lfanew
pe:
    db 'PE', 0, 0
    dw 0x14C                            ; Machine: i386
    dw 1                                ; NumberOfSections
    dd 0, 0, 0
    dw opt_end - opt                    ; SizeOfOptionalHeader
    dw 0x103                            ; Characteristics: EXECUTABLE_IMAGE | RELOCS_STRIPPED | 32BIT
opt:
    dw 0x10B                            ; PE32
    db 1, 0
    dd 0x200, 0, 0
    dd 0x1000                           ; AddressOfEntryPoint
    dd 0x1000, 0x2000
    dd 0x400000                         ; ImageBase
    dd 0x1000, 0x200
    dw 4, 0, 0, 0, 4, 0
    dd 0
    dd 0x2000
    dd 0x200
    dd 0
    dw 3                                ; Subsystem: console
    dw 0
    dd 0x100000, 0x1000, 0x100000, 0x1000
    dd 0
    dd 16
    times 16 dd 0, 0
opt_end:
