format binary as ''
use64
org 0
    db 'MENUET64'
    dq 0x01, start, i_end, 0x100000, 0x7FFF0, 0, 0
start:
    mov rax, 512
    int 0x60
i_end:
