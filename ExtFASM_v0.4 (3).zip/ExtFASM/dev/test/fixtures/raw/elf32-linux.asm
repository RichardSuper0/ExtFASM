; ELF32 scritto a mano (Linux, ABI 3)
format binary as ''
use32
org 0x08048000

ehdr:
    db 0x7F, 'ELF', 1, 1, 1, 3
    dq 0
    dw 2                                ; ET_EXEC
    dw 3                                ; EM_386
    dd 1
    dd _start                           ; e_entry
    dd phdr - $$                        ; e_phoff
    dd 0
    dd 0
    dw ehdrsize
    dw phdrsize
    dw 1
    dw 0, 0, 0
ehdrsize = $ - ehdr

phdr:
    dd 1                                ; PT_LOAD
    dd 0                                ; p_offset
    dd $$                               ; p_vaddr
    dd $$                               ; p_paddr
    dd filesize
    dd filesize
    dd 5                                ; R + X
    dd 0x1000
phdrsize = $ - phdr

_start:
    mov eax, 1
    xor ebx, ebx
    int 0x80
filesize = $ - $$
