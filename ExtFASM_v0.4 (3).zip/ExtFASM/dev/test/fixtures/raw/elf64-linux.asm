; ELF64 scritto a mano con db/dw/dd/dq (Linux, ABI 3)
format binary as ''
use64
org 0x400000

ehdr:
    db 0x7F, 'ELF', 2, 1, 1, 3          ; magic, class 64, little endian, version, OSABI Linux
    times 16 - ($ - ehdr) db 0
    dw 2                                ; e_type: ET_EXEC
    dw 62                               ; e_machine: x86-64
    dd 1                                ; e_version
    dq _start                           ; e_entry
    dq phdr - $$                        ; e_phoff
    dq 0                                ; e_shoff
    dd 0                                ; e_flags
    dw ehdrsize                         ; e_ehsize
    dw phdrsize                         ; e_phentsize
    dw 1                                ; e_phnum
    dw 0, 0, 0
ehdrsize = $ - ehdr

phdr:
    dd 1                                ; PT_LOAD
    dd 5                                ; R + X
    dq 0
    dq $$
    dq $$
    dq filesize
    dq filesize
    dq 0x1000
phdrsize = $ - phdr

_start:
    mov eax, 1
    mov edi, 1
    mov esi, msg
    mov edx, 3
    syscall
    mov eax, 60
    xor edi, edi
    syscall
msg db 'hi', 10
filesize = $ - $$
