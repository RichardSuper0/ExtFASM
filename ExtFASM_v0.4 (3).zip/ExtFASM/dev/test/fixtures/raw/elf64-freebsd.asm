format binary as ''
use64
org 0x400000
ehdr:
    db 0x7F, 'ELF', 2, 1, 1, 9          ; OSABI 9 = FreeBSD
    times 16 - ($ - ehdr) db 0
    dw 2, 62
    dd 1
    dq _start
    dq 64
    dq 0
    dd 0
    dw 64, 56, 1, 0, 0, 0
    dd 1, 5
    dq 0, $$, $$, filesize, filesize, 0x1000
_start:
    mov eax, 1
    xor edi, edi
    syscall
filesize = $ - $$
