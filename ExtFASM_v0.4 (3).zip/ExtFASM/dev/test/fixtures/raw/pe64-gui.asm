format binary as 'exe'
use64
org 0x140000000
dos:
    db 'MZ'
    times 0x3C - ($ - dos) db 0
    dd pe - dos
pe:
    db 'PE', 0, 0
    dw 0x8664                           ; AMD64
    dw 1
    dd 0, 0, 0
    dw opt_end - opt
    dw 0x22                             ; EXECUTABLE_IMAGE | LARGE_ADDRESS_AWARE
opt:
    dw 0x20B                            ; PE32+
    db 1, 0
    dd 0x200, 0, 0, 0x1000, 0x1000
    dq 0x140000000
    dd 0x1000, 0x200
    dw 6, 0, 0, 0, 6, 0
    dd 0, 0x2000, 0x200, 0
    dw 2                                ; Subsystem: GUI
    dw 0
    dq 0x100000, 0x1000, 0x100000, 0x1000
    dd 0, 16
    times 16 dd 0, 0
opt_end:
