format binary as ''
use32
org 0
    db 'MENUET01'
    dd 1, start, i_end, mem, stk, 0, 0
start:
    mov eax, -1
    int 0x40
i_end:
    rb 256
stk:
mem = $
