'use strict';
// I test che verificano i testi italiani li fanno con la lingua italiana; i test sulle lingue la impostano da sé.
require('../../src/i18n/i18n').setLanguage('it');
