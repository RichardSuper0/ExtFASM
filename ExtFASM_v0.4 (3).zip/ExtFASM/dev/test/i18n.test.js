'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const i18n = require('../../src/i18n/i18n');

const root = path.join(__dirname, '..', '..');
const LANGUAGES = ['en', 'it', 'fr', 'es', 'pl', 'de'];
const catalog = (language) => JSON.parse(fs.readFileSync(path.join(root, 'src', 'i18n', 'locales', `${language}.json`), 'utf8'));
const placeholders = (text) => [...text.matchAll(/\{(\w+)\}/g)].map((match) => match[1]).sort().join(',');

test('every catalog has exactly the same keys and the same placeholders as English', () => {
    const english = catalog('en');
    for (const language of LANGUAGES) {
        const other = catalog(language);
        assert.deepEqual(Object.keys(other).sort(), Object.keys(english).sort(), language);
        for (const [key, text] of Object.entries(other)) {
            assert.ok(text.trim().length > 0, `${language}:${key} vuoto`);
            assert.equal(placeholders(text), placeholders(english[key]), `${language}:${key} placeholder diversi`);
        }
    }
});

test('every key used in the code with t(...) exists in the catalogs', () => {
    const english = catalog('en');
    const files = ['extension.js', ...fs.readdirSync(path.join(root, 'src')).filter((name) => name.endsWith('.js')).map((name) => `src/${name}`),
        ...fs.readdirSync(path.join(root, 'src', 'syscalls')).map((name) => `src/syscalls/${name}`)];
    const missing = [];
    for (const file of files) {
        const text = fs.readFileSync(path.join(root, file), 'utf8');
        for (const match of text.matchAll(/\bt\(\s*'([\w.]+)'/g)) {
            if (!(match[1] in english)) missing.push(`${file}: ${match[1]}`);
        }
    }
    assert.deepEqual(missing, []);
});

test('package.json texts: every %key% exists in package.nls.json and in all the translations', () => {
    const pkg = fs.readFileSync(path.join(root, 'package.json'), 'utf8');
    const keys = [...new Set([...pkg.matchAll(/"%([\w.]+)%"/g)].map((match) => match[1]))];
    assert.ok(keys.length > 20);
    const english = JSON.parse(fs.readFileSync(path.join(root, 'package.nls.json'), 'utf8'));
    for (const language of LANGUAGES) {
        const file = language === 'en' ? 'package.nls.json' : `package.nls.${language}.json`;
        const table = JSON.parse(fs.readFileSync(path.join(root, file), 'utf8'));
        for (const key of keys) {
            assert.ok(table[key], `${file}: manca ${key}`);
        }
        assert.deepEqual(Object.keys(table).sort(), Object.keys(english).sort(), file);
    }
});

test('language selection: VS Code codes are reduced to a supported language, unknown ones use English', () => {
    assert.equal(i18n.normalizeLanguage('de-DE'), 'de');
    assert.equal(i18n.normalizeLanguage('PL'), 'pl');
    assert.equal(i18n.normalizeLanguage('fr'), 'fr');
    assert.equal(i18n.normalizeLanguage('es-mx'), 'es');
    assert.equal(i18n.normalizeLanguage('it'), 'it');
    assert.equal(i18n.normalizeLanguage('ja'), 'en');
    assert.equal(i18n.normalizeLanguage(undefined), 'en');
});

test('the same message in every language, with parameters; a missing key shows the key', () => {
    const previous = i18n.getLanguage();
    try {
        const expected = {
            it: 'FASM non trovato: "/x".', en: 'FASM not found: "/x".', fr: 'FASM introuvable : « /x ».',
            es: 'No se encontró FASM: «/x».', pl: 'Nie znaleziono FASM: „/x”.', de: 'FASM nicht gefunden: „/x“.'
        };
        for (const [language, text] of Object.entries(expected)) {
            i18n.setLanguage(language);
            assert.equal(i18n.t('compiler.notFound', { path: '/x' }), text, language);
        }
        assert.equal(i18n.t('no.such.key'), 'no.such.key');
        i18n.setLanguage('en');
        assert.equal(i18n.t('compiler.notFound'), 'FASM not found: "{path}".');
    } finally {
        i18n.setLanguage(previous);
    }
});

test('the extension picks the language of VS Code at activation', () => {
    // Il test smoke usa un finto vscode: qui si verifica solo il collegamento con vscode.env.language.
    const source = fs.readFileSync(path.join(root, 'extension.js'), 'utf8');
    assert.match(source, /setLanguage\(vscode\.env\.language\)/);
});

test('syscall findings, notes and hover are translated in every language (and keep the technical terms)', () => {
    const { analyzeSyscalls } = require('../../src/syscalls/engine');
    const { hoverMarkdown } = require('../../src/syscalls/presentation');
    const source = 'format ELF64 executable\nmov eax, 9999\nsyscall\nmov eax, 1\nint 0x2e\nmov eax, 60\nsyscall';
    const previous = i18n.getLanguage();
    const seen = new Map();
    try {
        for (const language of LANGUAGES) {
            i18n.setLanguage(language);
            const { findings } = analyzeSyscalls(source, {});
            assert.equal(findings.length, 3, language);
            for (const finding of findings) {
                assert.doesNotMatch(finding.message, /\{\w+\}|undefined|\[object/, `${language}: ${finding.message}`);
                assert.match(finding.message, /syscall|int 0x2E|int 0x2e/, language);
            }
            assert.doesNotMatch(hoverMarkdown(findings[0]), /\{\w+\}|undefined/, language);
            seen.set(language, findings[0].message);
        }
    } finally {
        i18n.setLanguage(previous);
    }
    assert.equal(new Set(seen.values()).size, LANGUAGES.length, 'ogni lingua ha un testo diverso');
    assert.match(seen.get('de'), /existiert in der Linux-x86-64-Syscall-Tabelle nicht/);
    assert.match(seen.get('pl'), /nie istnieje w tabeli syscalli Linux x86-64/);
    assert.match(seen.get('fr'), /n'existe pas dans la table des syscalls Linux x86-64/);
    assert.match(seen.get('es'), /no existe en la tabla de syscalls de Linux x86-64/);
    assert.match(seen.get('en'), /does not exist in the Linux x86-64 syscall table/);
});
