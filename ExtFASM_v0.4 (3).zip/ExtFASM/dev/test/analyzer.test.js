'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { analyzeSource } = require('../../src/analysis/analyzer');
const { detectFormat, nativePlatform } = require('../../src/analysis/formats');

const summary = (result) => result.instructions.map(({ mnemonic, bytes, sizeKind }) => ({ mnemonic, bytes, sizeKind }));

test('lists instructions and estimates familiar register encodings', () => {
    const result = analyzeSource('use32\nmov eax, 1\nadd eax, ebx\nnop');
    assert.deepEqual(summary(result), [
        { mnemonic: 'mov', bytes: 5, sizeKind: 'estimated' },
        { mnemonic: 'add', bytes: 2, sizeKind: 'estimated' },
        { mnemonic: 'nop', bytes: 1, sizeKind: 'exact' }
    ]);
});

test('suggests repeat for adjacent identical instructions but ignores comments', () => {
    const result = analyzeSource('inc eax\ninc eax\n; comment\ninc eax');
    assert.equal(result.diagnostics.length, 1);
    assert.equal(result.diagnostics[0].code, 'FASM_DUPLICATE_RUN');
    assert.equal(result.diagnostics[0].count, 2);
});

test('flags unclosed strings and unmatched delimiters without treating macros as instructions', () => {
    const result = analyzeSource('db "unfinished\nmov eax, [ebx\nmy_macro eax');
    assert.ok(result.diagnostics.some(({ code }) => code === 'FASM_UNCLOSED_STRING'));
    assert.ok(result.diagnostics.some(({ code }) => code === 'FASM_UNCLOSED_BRACKET'));
    assert.equal(result.instructions.length, 1);
});

test('regression: jmp, ret, syscall and cpuid are recognised', () => {
    const result = analyzeSource('format ELF64 executable 3\nstart:\n  jmp start\n  ret\n  syscall\n  cpuid');
    assert.deepEqual(summary(result).map((item) => item.mnemonic), ['jmp', 'ret', 'syscall', 'cpuid']);
    assert.deepEqual(summary(result).slice(1).map((item) => item.bytes), [1, 2, 2]);
});

test('regression: cpuid is 2 bytes, not 1', () => {
    assert.equal(analyzeSource('cpuid').instructions[0].bytes, 2);
});

test('regression: the format directive sets the default mode instead of always assuming 16 bit', () => {
    const elf64 = analyzeSource('format ELF64 executable 3\nmov eax, 1\npush rax');
    assert.deepEqual(elf64.instructions.map((item) => item.mode), [64, 64]);
    const pe = analyzeSource('format PE console\nmov eax, 1');
    assert.equal(pe.instructions[0].mode, 32);
    assert.equal(pe.instructions[0].bytes, 5);
    const plain = analyzeSource('mov eax, 1');
    assert.equal(plain.instructions[0].mode, 16);
    assert.equal(plain.instructions[0].bytes, 6); // prefisso 0x66 in modalità 16 bit
});

test('regression: a 64-bit register immediate is not given an invented size', () => {
    const result = analyzeSource('use64\nmov rax, 1');
    assert.equal(result.instructions[0].bytes, null);
    assert.equal(result.instructions[0].sizeKind, 'unknown');
});

test('labels with a space before the colon and prefixes like rep do not hide the instruction', () => {
    const result = analyzeSource('start : \n  rep movsb\n@@: nop\nlock inc dword [x]');
    assert.deepEqual(result.instructions.map((item) => item.mnemonic), ['movsb', 'nop', 'inc']);
});

test('FASM strings: single quotes work, ; inside a string is not a comment, doubled quote stays inside', () => {
    const ok = analyzeSource("db 'a;b', 'it''s'\nmov eax, [ebx]");
    assert.deepEqual(ok.diagnostics, []);
    const bad = analyzeSource("db 'oops");
    assert.equal(bad.diagnostics[0].code, 'FASM_UNCLOSED_STRING');
    assert.deepEqual(analyzeSource("db '(', ']'").diagnostics, []);
});

test('int immediate is estimated, int 3 is left unknown', () => {
    assert.equal(analyzeSource('int 0x80').instructions[0].bytes, 2);
    assert.equal(analyzeSource('int 80h').instructions[0].bytes, 2);
    assert.equal(analyzeSource('int 3').instructions[0].bytes, null);
});

test('detectFormat knows the FASM 1 formats, output extensions and where they can run', () => {
    const elf64 = detectFormat('format ELF64 executable 3');
    assert.deepEqual(
        { kind: elf64.kind, bits: elf64.bits, executable: elf64.executable, extension: elf64.extension, abi: elf64.abi, abiName: elf64.abiName, linking: elf64.linking },
        { kind: 'elf64', bits: 64, executable: true, extension: '', abi: 3, abiName: 'Linux', linking: 'static' }
    );
    assert.equal(detectFormat('format ELF').extension, '.o');
    assert.equal(detectFormat('format PE64 GUI 5.0').extension, '.exe');
    assert.equal(detectFormat('format PE console dll').executable, false);
    assert.equal(detectFormat('; format ELF\nmov eax,1').kind, 'binary');
    assert.equal(detectFormat('org 100h').explicit, false);
    assert.equal(nativePlatform(detectFormat('format ELF executable')), 'linux');
    assert.equal(nativePlatform(detectFormat('format PE console')), 'win32');
    assert.equal(nativePlatform(detectFormat('format MS COFF')), null);
});

test('ELF ABI 0-9 is read after "executable", defaults to 0, and only ABI 0/3 is launched on Linux', () => {
    const names = ['UNIX System V', 'HP-UX', 'NetBSD', 'Linux', 'GNU Hurd', '86Open (riservato)', 'Solaris', 'AIX', 'IRIX', 'FreeBSD'];
    for (let abi = 0; abi <= 9; abi += 1) {
        const format = detectFormat(`format ELF executable ${abi}`);
        assert.equal(format.abi, abi);
        assert.equal(format.abiName, names[abi]);
        assert.equal(nativePlatform(format), abi === 0 || abi === 3 ? 'linux' : null, `abi ${abi}`);
    }
    assert.equal(detectFormat('format ELF64 executable').abi, 0);
    assert.equal(detectFormat('format ELF').abi, null);
});

test('ELF executable is "dynamic" when the source declares an interpreter or a dynamic segment', () => {
    assert.equal(detectFormat("format ELF executable 3\nsegment interpreter readable\ndb '/lib/ld-linux.so.2',0").linking, 'dynamic');
    assert.equal(detectFormat("format ELF64 executable 3\nsegment dynamic readable").linking, 'dynamic');
    assert.equal(detectFormat("format ELF executable 3\n; interpreter in a comment\nmov eax,1").linking, 'static');
    assert.equal(detectFormat('format ELF64').linking, null);
});

test('PE subsystems, DLL, EFI and MZ', () => {
    assert.equal(detectFormat('format PE64 console').subsystem, 'console');
    assert.equal(detectFormat('format PE').subsystem, 'gui');
    assert.equal(detectFormat('format PE GUI 4.0 DLL').extension, '.dll');
    assert.equal(detectFormat('format PE64 EFI').extension, '.efi');
    assert.equal(detectFormat('format PE64 native').executable, false);
    assert.equal(detectFormat('format MZ').kind, 'mz');
    assert.equal(nativePlatform(detectFormat('format MZ')), null);
    assert.equal(detectFormat('format MS64 COFF').kind, 'coff64');
});

test('format ... as \'ext\' follows real fasm 1.73.35: the name is <source>.<text>, any format, unsafe text ignored', () => {
    // Valori verificati con fasm.x64 1.73.35 (vedi dev/test/fasm-real.test.js).
    assert.equal(detectFormat("format binary as 'KEK'").extension, '.KEK');
    assert.equal(detectFormat("format binary as '.KEK'").extension, '..KEK'); // fasm aggiunge già il punto
    assert.equal(detectFormat("format binary as ''").extension, '.');
    assert.equal(detectFormat("format binary as 'tar.gz'").extension, '.tar.gz');
    assert.equal(detectFormat('format binary as ".com"').extension, '..com');
    assert.equal(detectFormat("format ELF executable 3 as 'x'").extension, '.x');
    assert.equal(detectFormat("format PE console as 'scr'").extension, '.scr');
    assert.equal(detectFormat("format MZ as 'com'").extension, '.com');
    assert.equal(detectFormat("format ELF as 'ob'").extension, '.ob');
    assert.equal(detectFormat("format binary").extension, '.bin');
    assert.equal(detectFormat("format binary as 'KEK' ; commento 'zzz'").customExtension, 'KEK');
    // Testo non sicuro per un nome di file: ignorato (estensione di default), ma ricordato per l'avviso.
    for (const unsafe of ["a/../b", "x y", "a\\b", "../x"]) {
        const format = detectFormat(`format binary as '${unsafe}'`);
        assert.equal(format.extension, '.bin', unsafe);
        assert.equal(format.customExtension, null, unsafe);
        assert.equal(format.customExtensionRaw, unsafe, unsafe);
    }
});
