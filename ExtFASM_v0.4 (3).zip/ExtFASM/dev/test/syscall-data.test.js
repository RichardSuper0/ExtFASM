'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const x64 = require('../../src/data/linux-x86_64.json');
const i386 = require('../../src/data/linux-i386.json');

const byName = (table, name) => table.syscalls.find((entry) => entry.name === name);

test('Linux tables carry their provenance (repository, commit, source file)', () => {
    for (const table of [x64, i386]) {
        assert.equal(table.source.repository, 'https://github.com/torvalds/linux');
        assert.match(table.source.commit, /^[0-9a-f]{40}$/);
        assert.match(table.source.file, /^arch\/x86\/entry\/syscalls\/syscall_(32|64)\.tbl$/);
    }
});

test('well-known Linux x86-64 numbers (rax) come from the kernel table', () => {
    assert.deepEqual([byName(x64, 'read').number, byName(x64, 'write').number, byName(x64, 'exit').number, byName(x64, 'exit_group').number], [0, 1, 60, 231]);
    assert.equal(byName(x64, 'write').abi, 'common');
    assert.equal(byName(x64, 'exit').noreturn, true);
});

test('well-known Linux i386 numbers (eax, int 0x80) differ from x86-64', () => {
    assert.deepEqual([byName(i386, 'exit').number, byName(i386, 'write').number, byName(i386, 'read').number], [1, 4, 3]);
    assert.notEqual(byName(i386, 'write').number, byName(x64, 'write').number);
});

test('x32 entries are kept apart (numbers with bit 30 set are not x86-64 syscalls)', () => {
    const x32 = x64.syscalls.filter((entry) => entry.abi === 'x32');
    assert.ok(x32.length > 0);
    assert.ok(x32.every((entry) => entry.number >= 512));
    const native = x64.syscalls.filter((entry) => entry.abi !== 'x32');
    assert.equal(new Set(native.map((entry) => entry.number)).size, native.length, 'numeri duplicati nel nativo');
});
