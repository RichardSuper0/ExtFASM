'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { runAssembler } = require('../../src/build/assembler');
const { startProgram } = require('../../src/build/runProgram');
const { parseCompilerOutput } = require('../../src/build/diagnostics');

const posixOnly = { skip: process.platform === 'win32' ? 'script di prova POSIX' : false };

function makeDir() {
    return fs.mkdtempSync(path.join(os.tmpdir(), 'extfasm proc $x '));
}

function writeScript(directory, name, body) {
    const file = path.join(directory, name);
    fs.writeFileSync(file, `#!/bin/sh\n${body}\n`);
    fs.chmodSync(file, 0o755);
    return file;
}

test('assembler receives source and output as separate arguments (spaces, quotes, $ and ; are inert)', posixOnly, async () => {
    const dir = makeDir();
    const compiler = writeScript(dir, 'fake fasm', 'printf "%s\\n%s\\n" "$1" "$2" > "$(dirname "$1")/args.txt"; echo "2 passes, 5 bytes."');
    const source = path.join(dir, "my 'prog'; echo pwned $(id).asm");
    fs.writeFileSync(source, 'nop');
    const output = path.join(dir, 'out put');
    const result = await runAssembler({ compiler, sourcePath: source, outputPath: output, env: process.env });
    assert.equal(result.exitCode, 0);
    assert.match(result.stdout, /2 passes/);
    assert.deepEqual(fs.readFileSync(path.join(dir, 'args.txt'), 'utf8').split('\n').slice(0, 2), [source, output]);
});

test('assembler reports exit code and the output is parseable into a diagnostic', posixOnly, async () => {
    const dir = makeDir();
    const compiler = writeScript(dir, 'fasm', 'echo "main.asm [4]:"; echo "mov eax,"; echo "Processed: mov eax,"; echo "Error: invalid operand."; exit 2');
    const source = path.join(dir, 'main.asm');
    fs.writeFileSync(source, '');
    const result = await runAssembler({ compiler, sourcePath: source, outputPath: path.join(dir, 'main'), env: process.env });
    assert.equal(result.exitCode, 2);
    assert.deepEqual(parseCompilerOutput(result.stdout + result.stderr, source), [{ line: 3, message: 'invalid operand.' }]);
});

test('a missing compiler is reported as a spawn error, not as an assembly error', async () => {
    const result = await runAssembler({ compiler: path.join(os.tmpdir(), 'no-such-fasm-xyz'), sourcePath: path.join(os.tmpdir(), 'a.asm'), outputPath: path.join(os.tmpdir(), 'a'), env: process.env });
    assert.equal(result.exitCode, null);
    assert.equal(result.spawnError, 'ENOENT');
});

test('program output is streamed separately and the exit code is returned', posixOnly, async () => {
    const dir = makeDir();
    const program = writeScript(dir, 'prog', 'echo out; echo err 1>&2; exit 3');
    let stdout = '';
    let stderr = '';
    const { done } = startProgram({ command: program, cwd: dir, onStdout: (text) => { stdout += text; }, onStderr: (text) => { stderr += text; } });
    const result = await done;
    assert.deepEqual({ stdout, stderr, exitCode: result.exitCode, signal: result.signal }, { stdout: 'out\n', stderr: 'err\n', exitCode: 3, signal: null });
});

test('a produced file without the execute bit is made owner-executable before running', posixOnly, async () => {
    const dir = makeDir();
    const program = path.join(dir, 'prog');
    fs.writeFileSync(program, '#!/bin/sh\nexit 0\n');
    fs.chmodSync(program, 0o644);
    const result = await startProgram({ command: program, cwd: dir }).done;
    assert.equal(result.exitCode, 0);
});

test('stop() interrupts a long-running program', posixOnly, async () => {
    const dir = makeDir();
    const program = writeScript(dir, 'slow', 'exec sleep 30');
    const run = startProgram({ command: program, cwd: dir });
    setTimeout(() => run.stop(), 100);
    const started = Date.now();
    const result = await run.done;
    assert.equal(result.signal, 'SIGTERM');
    assert.ok(Date.now() - started < 5000);
});

test('starting a missing program reports an error instead of throwing', async () => {
    const result = await startProgram({ command: path.join(os.tmpdir(), 'no-such-program-xyz'), cwd: os.tmpdir() }).done;
    assert.equal(result.exitCode, null);
    assert.equal(result.error, 'ENOENT');
});
