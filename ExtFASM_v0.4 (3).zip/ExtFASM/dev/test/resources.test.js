'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawn } = require('node:child_process');
const { describeHardware, ProcessSampler, snapshotDirectory, diffSnapshots } = require('../../src/deepdebug/resources');

const linuxOnly = { skip: process.platform === 'linux' ? false : 'campionamento /proc: solo Linux' };

test('hardware: real values from the OS, explicit status for what cannot be seen', async () => {
    const hardware = await describeHardware(os.tmpdir());
    assert.equal(hardware.cpu.logicalCores, os.cpus().length);
    assert.equal(hardware.ram.totalBytes, os.totalmem());
    assert.ok(hardware.disk.totalBytes > 0 && hardware.disk.freeBytes >= 0);
    for (const part of [hardware.gpu, hardware.npu]) {
        assert.ok(['ok', 'absent', 'undetectable'].includes(part.status));
        assert.ok(Array.isArray(part.devices));
        if (part.status !== 'ok') assert.equal(part.devices.length, 0);
    }
    // nessun dato per-processo sulla GPU/NPU: non si inventa
    assert.equal('usage' in hardware.gpu, false);
});

test('sampler: CPU time, peak memory and I/O of a real child process', linuxOnly, async () => {
    const script = "const t=Date.now();const b=Buffer.alloc(60*1024*1024,1);let x=0;while(Date.now()-t<500){x+=Math.sqrt(x+1)}require('fs').writeFileSync(require('os').tmpdir()+'/extfasm-sampler-io',Buffer.alloc(1<<20));";
    const child = spawn(process.execPath, ['-e', script], { stdio: 'ignore' });
    const sampler = new ProcessSampler({ pid: child.pid, executable: process.execPath, intervalMs: 20 });
    sampler.start();
    const started = Date.now();
    await new Promise((resolve) => child.once('close', resolve));
    const report = sampler.finish({ wallMs: Date.now() - started });
    fs.rmSync(path.join(os.tmpdir(), 'extfasm-sampler-io'), { force: true });
    assert.equal(report.cpu.status, 'ok');
    assert.ok(report.samples >= 5, `campioni: ${report.samples}`);
    assert.ok(report.cpu.sampledCpuMs > 150, `cpu ${report.cpu.sampledCpuMs}`);
    assert.ok(report.memory.peakRssKb > 55 * 1024, `picco ${report.memory.peakRssKb}`);
    assert.ok(report.overheadMs >= 0 && report.overheadMs < report.wallMs);
    assert.ok(report.series.every((point, index) => index === 0 || point.t >= report.series[index - 1].t));
});

test('sampler: a program too short to be sampled is reported as not measurable, not as zero', linuxOnly, async () => {
    const child = spawn('/bin/true', [], { stdio: 'ignore' });
    const sampler = new ProcessSampler({ pid: child.pid, executable: '/bin/true', intervalMs: 500 });
    sampler.start();
    const started = Date.now();
    await new Promise((resolve) => child.once('close', resolve));
    const report = sampler.finish({ wallMs: Date.now() - started });
    if (report.samples === 0) {
        assert.equal(report.cpu.status, 'not-measurable');
        assert.equal(report.cpu.sampledCpuMs, null);
        assert.equal(report.memory.peakRssKb, null);
    } else {
        assert.equal(report.cpu.status, 'ok');
    }
});

test('directory snapshots report created, modified and deleted files', () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'extfasm snap '));
    try {
        fs.writeFileSync(path.join(dir, 'keep.txt'), 'a');
        fs.writeFileSync(path.join(dir, 'change.txt'), 'a');
        fs.writeFileSync(path.join(dir, 'gone.txt'), 'a');
        const before = snapshotDirectory(dir);
        fs.writeFileSync(path.join(dir, 'change.txt'), 'abcd');
        fs.rmSync(path.join(dir, 'gone.txt'));
        fs.writeFileSync(path.join(dir, 'new.txt'), 'xy');
        const diff = diffSnapshots(before, snapshotDirectory(dir));
        assert.deepEqual(diff.created, [{ file: 'new.txt', size: 2 }]);
        assert.deepEqual(diff.modified, [{ file: 'change.txt', size: 4, previousSize: 1 }]);
        assert.deepEqual(diff.deleted, [{ file: 'gone.txt' }]);
    } finally {
        fs.rmSync(dir, { recursive: true, force: true });
    }
});
