'use strict';

/**
 * Smoke test di extension.js con un modulo `vscode` simulato.
 * Verifica il collegamento tra i moduli (percorsi, assemblatore, diagnostica, esecuzione),
 * NON il comportamento reale di VS Code: va comunque provata con F5 nell'Extension Development Host.
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const Module = require('node:module');

const posixOnly = { skip: process.platform === 'win32' ? 'script di prova POSIX' : false };

function makeFakeVscode({ config = {}, answers = {}, trusted = true, language = 'it' } = {}) {
    const calls = { warnings: [], errors: [], infos: [], executed: [], updates: [], diagnostics: new Map(), commands: new Map(), output: new Map(), providers: {}, webviewMessages: [] };
    const next = (kind) => Promise.resolve((answers[kind] || []).shift());
    const channel = (name) => {
        const lines = [];
        calls.output.set(name, lines);
        return { appendLine: (text) => lines.push(text), append: (text) => lines.push(text), show() { }, dispose() { } };
    };
    const disposable = { dispose() { } };
    class Range { constructor(startLine, startCharacter, endLine, endCharacter) { Object.assign(this, { startLine, startCharacter, endLine, endCharacter }); } }
    class Diagnostic { constructor(range, message, severity) { Object.assign(this, { range, message, severity }); } }
    class EventEmitter { constructor() { this.event = () => disposable; } fire() { calls.tokenRefreshes = (calls.tokenRefreshes || 0) + 1; } dispose() { } }
    class SemanticTokensLegend { constructor(tokenTypes, tokenModifiers) { Object.assign(this, { tokenTypes, tokenModifiers }); } }
    class SemanticTokensBuilder {
        constructor(legend) { this.legend = legend; this.tokens = []; }
        push(range, tokenType, tokenModifiers) { this.tokens.push({ line: range.startLine, start: range.startCharacter, end: range.endCharacter, tokenType, tokenModifiers }); }
        build() { return { tokens: this.tokens }; }
    }
    class MarkdownString { constructor(value) { this.value = value; } }
    class CompletionItem { constructor(label, kind) { Object.assign(this, { label, kind }); } }
    class SnippetString { constructor(value) { this.value = value; } }
    class InlineCompletionItem { constructor(insertText, range) { Object.assign(this, { insertText, range }); } }
    class FoldingRange { constructor(start, end, kind) { Object.assign(this, { start, end, kind }); } }
    class Hover { constructor(contents, range) { Object.assign(this, { contents, range }); } }
    const vscode = {
        env: { language },
        Range,
        Diagnostic,
        EventEmitter,
        SemanticTokensLegend,
        SemanticTokensBuilder,
        MarkdownString,
        CompletionItem,
        CompletionItemKind: { Snippet: 14 },
        SnippetString,
        InlineCompletionItem,
        Hover,
        FoldingRange,
        FoldingRangeKind: { Comment: 1, Region: 3 },
        Uri: class Uri { },
        DiagnosticSeverity: { Error: 0, Warning: 1, Information: 2, Hint: 3 },
        ProgressLocation: { Window: 10 },
        ConfigurationTarget: { Global: 1 },
        ViewColumn: { Beside: -2 },
        languages: {
            registerFoldingRangeProvider: (selector, provider) => { calls.providers.folding = provider; return disposable; },
            createDiagnosticCollection: (name) => ({
                set: (uri, items) => calls.diagnostics.set(`${name}:${uri.fsPath}`, items),
                delete: (uri) => calls.diagnostics.delete(`${name}:${uri.fsPath}`),
                dispose() { }
            }),
            registerDocumentSemanticTokensProvider: (selector, provider, legend) => { calls.providers.tokens = { provider, legend }; return disposable; },
            registerHoverProvider: (selector, provider) => { calls.providers.hover = provider; return disposable; },
            registerCompletionItemProvider: (selector, provider) => { calls.providers.completion = provider; return disposable; },
            registerInlineCompletionItemProvider: (selector, provider) => { calls.providers.inline = provider; return disposable; }
        },
        window: {
            activeTextEditor: null,
            createOutputChannel: channel,
            createWebviewPanel: () => {
                const panel = { webview: { html: '', postMessage: (message) => calls.webviewMessages.push(message), onDidReceiveMessage: (handler) => { calls.webviewHandler = handler; } }, reveal() { }, onDidDispose() { } };
                calls.panel = panel;
                return panel;
            },
            showWarningMessage: (...args) => { calls.warnings.push(args); return next('warning'); },
            showErrorMessage: (...args) => { calls.errors.push(args); return next('error'); },
            showInformationMessage: (...args) => { calls.infos.push(args); return next('info'); },
            showOpenDialog: () => next('openDialog'),
            showInputBox: () => next('inputBox'),
            withProgress: (options, task) => task()
        },
        commands: {
            registerCommand: (name, handler) => { calls.commands.set(name, handler); return disposable; },
            executeCommand: (...args) => { calls.executed.push(args); return Promise.resolve(); }
        },
        workspace: {
            isTrusted: trusted,
            textDocuments: [],
            getConfiguration: () => ({
                get: (key, fallback) => (key in config ? config[key] : fallback),
                update: (key, value, target) => { calls.updates.push([key, value, target]); config[key] = value; return Promise.resolve(); }
            }),
            getWorkspaceFolder: () => undefined,
            openTextDocument: () => Promise.reject(new Error('non usato')),
            onDidOpenTextDocument: () => disposable,
            onDidChangeTextDocument: () => disposable,
            onDidCloseTextDocument: () => disposable,
            onDidSaveTextDocument: () => disposable,
            onDidChangeConfiguration: () => disposable
        }
    };
    return { vscode, calls };
}

function loadExtension(fake) {
    const original = Module._load;
    Module._load = function (request, ...rest) {
        return request === 'vscode' ? fake.vscode : original.call(this, request, ...rest);
    };
    try {
        const file = require.resolve('../../extension');
        delete require.cache[file];
        const extension = require(file);
        const context = { subscriptions: [] };
        extension.activate(context);
        return { extension, context };
    } finally {
        Module._load = original;
    }
}

function makeDocument(directory, text, name = 'main.asm') {
    const fsPath = path.join(directory, name);
    fs.writeFileSync(fsPath, text);
    const lines = text.split('\n');
    return {
        languageId: 'fasm1',
        isDirty: false,
        isClosed: false,
        version: 1,
        lineCount: lines.length,
        uri: { scheme: 'file', fsPath, toString: () => `file://${fsPath}` },
        getText: () => text,
        lineAt: (index) => ({ text: lines[index], firstNonWhitespaceCharacterIndex: lines[index].length - lines[index].trimStart().length }),
        save: () => Promise.resolve(true)
    };
}

function makeFakeFasm(directory, body) {
    const file = path.join(directory, 'fake fasm');
    fs.writeFileSync(file, `#!/bin/sh\n${body}\n`);
    fs.chmodSync(file, 0o755);
    return file;
}

const tempDir = () => fs.mkdtempSync(path.join(os.tmpdir(), 'extfasm smoke '));

test('activation registers every command and the output channels', () => {
    const fake = makeFakeVscode();
    const { context } = loadExtension(fake);
    assert.deepEqual([...fake.calls.commands.keys()].sort(), [
        'fasm1.build', 'fasm1.buildAndRun', 'fasm1.openDebugger', 'fasm1.openSettings', 'fasm1.selectCompiler', 'fasm1.stopProgram'
    ]);
    assert.ok(context.subscriptions.length >= 4);
});

test('missing compiler: asks the user to set it in VS Code settings and does not run anything', posixOnly, async () => {
    const dir = tempDir();
    const fake = makeFakeVscode({ config: { compilerPath: path.join(dir, 'nope') }, answers: { warning: ['Apri impostazioni'] } });
    loadExtension(fake);
    fake.vscode.window.activeTextEditor = { document: makeDocument(dir, 'nop') };
    await fake.calls.commands.get('fasm1.build')();
    assert.match(fake.calls.warnings[0][0], /non trovato/);
    assert.match(fake.calls.warnings[0][0], /nome del comando/);
    assert.deepEqual(fake.calls.warnings[0].slice(1), ['Inserisci comando…', 'Scegli file…', 'Apri impostazioni']);
    assert.deepEqual(fake.calls.executed.at(-1), ['workbench.action.openSettings', 'fasm1.compilerPath']);
    assert.equal(fake.calls.output.get('FASM 1').length, 0);
});

test('"Scegli file…" saves the path in the user (global) settings and continues the build', posixOnly, async () => {
    const dir = tempDir();
    const compiler = makeFakeFasm(dir, 'touch "$2"; echo "1 passes, 3 bytes."');
    const fake = makeFakeVscode({ config: { compilerPath: '' }, answers: { warning: ['Scegli file…'], openDialog: [[{ fsPath: compiler }]] } });
    // PATH senza fasm: l'impostazione vuota non deve trovare nulla.
    const savedPath = process.env.PATH;
    process.env.PATH = dir.replace(/ /g, '_');
    try {
        loadExtension(fake);
        fake.vscode.window.activeTextEditor = { document: makeDocument(dir, 'nop') };
        await fake.calls.commands.get('fasm1.build')();
    } finally {
        process.env.PATH = savedPath;
    }
    assert.deepEqual(fake.calls.updates, [['compilerPath', compiler, 1]]);
    assert.match(fake.calls.infos.at(-1)[0], /assemblaggio completato/);
});

test('"Inserisci comando…" saves the command NAME typed by the user (not a resolved path) and continues the build', posixOnly, async () => {
    const dir = tempDir();
    const bin = path.join(dir, 'bin');
    fs.mkdirSync(bin);
    makeFakeFasm(bin, 'touch "$2"; echo "1 passes, 3 bytes."');
    fs.renameSync(path.join(bin, fs.readdirSync(bin)[0]), path.join(bin, 'myfasm'));
    const fake = makeFakeVscode({ config: { compilerPath: '' }, answers: { warning: ['Inserisci comando…'], inputBox: ['myfasm'] } });
    const savedPath = process.env.PATH;
    process.env.PATH = bin;
    try {
        loadExtension(fake);
        fake.vscode.window.activeTextEditor = { document: makeDocument(dir, 'nop') };
        await fake.calls.commands.get('fasm1.build')();
    } finally {
        process.env.PATH = savedPath;
    }
    assert.deepEqual(fake.calls.updates, [['compilerPath', 'myfasm', 1]]);
});

test('assembler error: diagnostic on the whole line with the real message, then cleared when valid', posixOnly, async () => {
    const dir = tempDir();
    const failing = makeFakeFasm(dir, 'echo "main.asm [2]:"; echo "  mov eax,"; echo "Processed: mov eax,"; echo "Error: invalid operand."; exit 2');
    const fake = makeFakeVscode({ config: { compilerPath: failing } });
    loadExtension(fake);
    const document = makeDocument(dir, 'start:\n  mov eax,\n');
    fake.vscode.window.activeTextEditor = { document };
    await fake.calls.commands.get('fasm1.build')();

    const [diagnostic] = fake.calls.diagnostics.get(`fasm1-assembler:${document.uri.fsPath}`);
    assert.equal(diagnostic.message, 'invalid operand.');
    assert.equal(diagnostic.source, 'FASM 1 (assemblatore)');
    assert.deepEqual([diagnostic.range.startLine, diagnostic.range.startCharacter, diagnostic.range.endCharacter], [1, 2, 10]);
    assert.match(fake.calls.errors[0][0], /errore/);
    assert.ok(fake.calls.output.get('FASM 1').some((line) => /Codice di uscita dell'assemblatore: 2/.test(line)));

    fs.writeFileSync(failing, '#!/bin/sh\ntouch "$2"\necho ok\n');
    await fake.calls.commands.get('fasm1.build')();
    assert.equal(fake.calls.diagnostics.has(`fasm1-assembler:${document.uri.fsPath}`), false);
});

test('assemble and run: separate program output and exit code (Linux ELF executable)', { skip: process.platform !== 'linux' ? 'solo Linux' : false }, async () => {
    const dir = tempDir();
    const compiler = makeFakeFasm(dir, 'printf "#!/bin/sh\\necho hello-from-program\\nexit 7\\n" > "$2"; chmod 755 "$2"; echo "1 passes."');
    const fake = makeFakeVscode({ config: { compilerPath: compiler, confirmBeforeRun: false } });
    loadExtension(fake);
    fake.vscode.window.activeTextEditor = { document: makeDocument(dir, 'format ELF executable 3\nentry start\nstart:\n') };
    await fake.calls.commands.get('fasm1.buildAndRun')();

    const program = fake.calls.output.get('FASM 1 – Programma').join('');
    assert.match(program, /hello-from-program/);
    assert.match(program, /codice di uscita: 7/);
    assert.ok(!fake.calls.output.get('FASM 1').join('').includes('hello-from-program'));
});

test('run asks for confirmation and does nothing if the user cancels', { skip: process.platform !== 'linux' ? 'solo Linux' : false }, async () => {
    const dir = tempDir();
    const compiler = makeFakeFasm(dir, 'printf "#!/bin/sh\\necho should-not-run\\n" > "$2"; chmod 755 "$2"');
    const fake = makeFakeVscode({ config: { compilerPath: compiler }, answers: { warning: [undefined] } });
    loadExtension(fake);
    fake.vscode.window.activeTextEditor = { document: makeDocument(dir, 'format ELF executable 3\n') };
    await fake.calls.commands.get('fasm1.buildAndRun')();
    assert.match(fake.calls.warnings[0][0], /stai per eseguire/i);
    assert.deepEqual(fake.calls.output.get('FASM 1 – Programma'), []);
});

test('untrusted workspace: the program is not run', { skip: process.platform !== 'linux' ? 'solo Linux' : false }, async () => {
    const dir = tempDir();
    const compiler = makeFakeFasm(dir, 'printf "#!/bin/sh\\necho should-not-run\\n" > "$2"; chmod 755 "$2"');
    const fake = makeFakeVscode({ config: { compilerPath: compiler, confirmBeforeRun: false }, trusted: false });
    loadExtension(fake);
    fake.vscode.window.activeTextEditor = { document: makeDocument(dir, 'format ELF executable 3\n') };
    await fake.calls.commands.get('fasm1.buildAndRun')();
    assert.match(fake.calls.warnings[0][0], /non è attendibile/);
    assert.deepEqual(fake.calls.output.get('FASM 1 – Programma'), []);
});

test('a PE executable is not launched on Linux (assembled only, user is told why)', { skip: process.platform !== 'linux' ? 'solo Linux' : false }, async () => {
    const dir = tempDir();
    const compiler = makeFakeFasm(dir, 'touch "$2"');
    const fake = makeFakeVscode({ config: { compilerPath: compiler, confirmBeforeRun: false } });
    loadExtension(fake);
    fake.vscode.window.activeTextEditor = { document: makeDocument(dir, 'format PE console\n') };
    await fake.calls.commands.get('fasm1.buildAndRun')();
    assert.match(fake.calls.warnings[0][0], /non si può avviare su questo sistema/);
});

// ---------------------------------------------------------------------------------------------------------
// Chiamate di sistema: diagnostica, colori, hover
// ---------------------------------------------------------------------------------------------------------

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const SYSCALL_SOURCE = 'format ELF64 executable 3\nentry start\nstart:\n  mov eax, 1\n  syscall\n  mov eax, 9999\n  syscall\n  mov eax, [x]\n  syscall\n';

test('syscalls: semantic tokens carry one modifier per category and the legend is the one declared in package.json', () => {
    const fake = makeFakeVscode();
    loadExtension(fake);
    const { provider, legend } = fake.calls.providers.tokens;
    const pkg = require('../../package.json').contributes;
    assert.deepEqual(legend.tokenTypes.slice(0, pkg.semanticTokenTypes.length), pkg.semanticTokenTypes.map((type) => type.id));
    assert.deepEqual(legend.tokenTypes.slice(pkg.semanticTokenTypes.length), ['macro', 'label', 'variable', 'enumMember']);
    assert.deepEqual(legend.tokenModifiers, pkg.semanticTokenModifiers.map((modifier) => modifier.id));

    const { tokens } = provider.provideDocumentSemanticTokens(makeDocument(tempDir(), SYSCALL_SOURCE));
    assert.deepEqual(tokens.filter((token) => token.tokenType === 'fasmSyscall').map((token) => [token.line, token.start, token.end, token.tokenModifiers[0]]), [
        [4, 2, 9, 'syscallValid'], [6, 2, 9, 'syscallUnknown'], [8, 2, 9, 'syscallUnverifiable']
    ]);
});

test('syscalls: the hover shows name, number and the table provenance; nothing outside the instruction', () => {
    const fake = makeFakeVscode();
    loadExtension(fake);
    const document = makeDocument(tempDir(), SYSCALL_SOURCE);
    const hover = fake.calls.providers.hover.provideHover(document, { line: 4, character: 4 });
    assert.match(hover.contents.value, /\*\*write\*\*/);
    assert.match(hover.contents.value, /0x1 \(1\)/);
    assert.match(hover.contents.value, /github\.com\/torvalds\/linux @ `[0-9a-f]{12}`/);
    assert.equal(hover.contents.isTrusted, false);
    assert.equal(fake.calls.providers.hover.provideHover(document, { line: 3, character: 4 }), null);
});

test('syscalls: diagnostics only for unknown / unverifiable calls (warning / hint), none for valid ones', async () => {
    const fake = makeFakeVscode();
    const document = makeDocument(tempDir(), SYSCALL_SOURCE);
    fake.vscode.workspace.textDocuments.push(document);
    loadExtension(fake);
    await sleep(400);
    const items = fake.calls.diagnostics.get(`fasm1-syscalls:${document.uri.fsPath}`);
    assert.deepEqual(items.map((item) => [item.range.startLine, item.severity, item.source]), [
        [6, 1, 'FASM 1 (syscall)'], [8, 3, 'FASM 1 (syscall)']
    ]);
    assert.match(items[0].message, /9999/);
});

test('syscalls: disabled in settings -> no diagnostics, no tokens, no hover', async () => {
    const fake = makeFakeVscode({ config: { 'syscalls.enabled': false } });
    const document = makeDocument(tempDir(), SYSCALL_SOURCE);
    fake.vscode.workspace.textDocuments.push(document);
    loadExtension(fake);
    await sleep(400);
    assert.equal(fake.calls.diagnostics.has(`fasm1-syscalls:${document.uri.fsPath}`), false);
    assert.deepEqual(fake.calls.providers.tokens.provider.provideDocumentSemanticTokens(document).tokens.filter((token) => token.tokenType === 'fasmSyscall'), []);
    assert.equal(fake.calls.providers.hover.provideHover(document, { line: 4, character: 4 }), null);
});

test('syscalls: target.os and target.windowsVersion settings change the result', () => {
    const source = 'format binary\nuse32\n  mov eax, 0\n  int 0x40\n';
    const plain = makeFakeVscode();
    loadExtension(plain);
    assert.equal(plain.calls.providers.tokens.provider.provideDocumentSemanticTokens(makeDocument(tempDir(), source)).tokens[0].tokenModifiers[0], 'syscallUnverifiable');

    const kolibri = makeFakeVscode({ config: { 'target.os': 'kolibrios' } });
    loadExtension(kolibri);
    assert.equal(kolibri.calls.providers.tokens.provider.provideDocumentSemanticTokens(makeDocument(tempDir(), source)).tokens[0].tokenModifiers[0], 'syscallValid');

    const windows = 'format PE64 console\n  mov eax, 0x18\n  syscall\n';
    const withVersion = makeFakeVscode({ config: { 'target.windowsVersion': 'Windows 10 22H2' } });
    loadExtension(withVersion);
    const { provider } = withVersion.calls.providers.tokens;
    assert.equal(provider.provideDocumentSemanticTokens(makeDocument(tempDir(), windows)).tokens[0].tokenModifiers[0], 'syscallValid');
});

test('prediction: completion items carry reason and snippet; inline ghost text only for non-uncertain best', () => {
    const fake = makeFakeVscode();
    loadExtension(fake);
    const source = 'format ELF64 executable 3\nentry start\nsegment readable executable\nstart:\n mov rax, 60\n ';
    const document = makeDocument(tempDir(), source);
    const position = { line: 5, character: 1 };
    const items = fake.calls.providers.completion.provideCompletionItems(document, position);
    assert.equal(items[0].label, 'mov rdi, error_code');
    assert.equal(items[0].insertText.value, 'mov rdi, ${1:error_code}');
    assert.match(items[0].documentation.value, /exit\(error_code\)/);
    const inline = fake.calls.providers.inline.provideInlineCompletionItems(document, position);
    assert.equal(inline.length, 1);
    assert.equal(inline[0].insertText.value, 'mov rdi, ${1:error_code}');
});

test('prediction: disabled in settings -> nothing', () => {
    const fake = makeFakeVscode({ config: { 'prediction.enabled': false } });
    loadExtension(fake);
    const document = makeDocument(tempDir(), 'format ELF64 executable 3\n');
    assert.deepEqual(fake.calls.providers.completion.provideCompletionItems(document, { line: 1, character: 0 }), []);
});

test('Apri Debugger: "Run and measure" assembles, asks, runs and reports real measurements', { skip: process.platform !== 'linux' ? 'solo Linux' : false }, async () => {
    const dir = tempDir();
    const compiler = makeFakeFasm(dir, 'printf "#!/bin/sh\\nsleep 0.4\\nexit 3\\n" > "$2"; chmod 755 "$2"; echo "1 passes."');
    const fake = makeFakeVscode({ config: { compilerPath: compiler, confirmBeforeRun: false } });
    loadExtension(fake);
    const document = makeDocument(dir, 'format ELF executable 3\nentry start\nstart:\n');
    fake.vscode.window.activeTextEditor = { document };
    await fake.calls.commands.get('fasm1.openDebugger')();
    assert.match(fake.calls.panel.webview.html, /Content-Security-Policy/);
    await fake.calls.webviewHandler({ command: 'ready' });
    await fake.calls.webviewHandler({ command: 'measure' });
    const resources = fake.calls.webviewMessages.filter((message) => message.type === 'resources').pop().data;
    assert.equal(resources.running, false);
    assert.equal(resources.report.name, 'main');
    assert.ok(resources.report.wallMs >= 300);
    assert.match(resources.report.outcome, /3/);
    assert.ok(['ok', 'not-measurable'].includes(resources.report.cpu.status));
    // il codice di uscita diverso da zero compare tra gli errori, con origine «runtime» e senza posizione
    const errors = fake.calls.webviewMessages.filter((message) => message.type === 'errors').pop().data.items;
    assert.deepEqual(errors.filter((item) => item.origin === 'runtime').map((item) => item.line), [null]);
});

test('folding: macros, sections, syscall setup and comments are foldable; the setting turns it off', () => {
    const fake = makeFakeVscode();
    loadExtension(fake);
    const document = makeDocument(tempDir(), SYSCALL_SOURCE);
    const ranges = fake.calls.providers.folding.provideFoldingRanges(document);
    assert.ok(ranges.length > 0);
    assert.ok(ranges.some((range) => range.end > range.start));
    const off = makeFakeVscode({ config: { folding: false } });
    loadExtension(off);
    assert.deepEqual(off.calls.providers.folding.provideFoldingRanges(document), []);
});
