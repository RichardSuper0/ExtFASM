'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { foldingRanges } = require('../../src/analysis/folding');

const SOURCE = [
    '; header',            // 0
    '; more',              // 1
    'format ELF64 executable 3', // 2
    'macro print msg, len {', // 3
    '  mov rsi, msg',      // 4
    '  mov rdx, len',      // 5
    '}',                   // 6
    'segment readable executable', // 7
    'start:',              // 8
    '  mov rax, 1',        // 9
    '  mov rdi, 1',        // 10
    '  mov rsi, msg',      // 11
    '  mov rdx, 5',        // 12
    '  syscall',           // 13
    '  if rax = 0',        // 14
    '    nop',             // 15
    '  end if',            // 16
    'done:',               // 17
    '  xor rdi, rdi',      // 18
    '  mov rax, 60',       // 19
    '  syscall',           // 20
    'segment readable writeable', // 21
    "msg db 'hi'",         // 22
    ''
].join('\n');

const ranges = foldingRanges(SOURCE, [13, 20]);
const has = (label, start, end) => ranges.some((r) => r.label === label && r.start === start && r.end === end);

test('comments, macro, if, sections, labels and syscall preparation are foldable', () => {
    assert.ok(has('comment', 0, 1));
    assert.ok(has('macro', 3, 6));
    assert.ok(has('if', 14, 16));
    assert.ok(has('section', 7, 20), 'a section stops before the next segment');
    assert.ok(has('section', 21, 22));
    assert.ok(has('label', 8, 16));
    assert.ok(has('label', 17, 20));
    assert.ok(has('syscall', 9, 13), 'argument setup up to the syscall, not the label line');
    assert.ok(has('syscall', 18, 20));
});

test('a single line never folds; unclosed blocks produce no range', () => {
    assert.deepEqual(foldingRanges('  mov eax, 1\n'), []);
    assert.ok(!foldingRanges('macro broken {\n  nop\n').some((r) => r.label === 'macro'));
    assert.ok(!foldingRanges('  if x\n  nop\n').some((r) => r.label === 'if'));
});

test('proc/endp, repeat/end repeat, virtual/end virtual and brace blocks', () => {
    const text = 'proc f\n  nop\n  nop\nendp\nrepeat 4\n  nop\nend repeat\nvirtual at 0\n  db 1\nend virtual\nirp x, a b {\n  db x\n}\n';
    const found = foldingRanges(text).map((r) => `${r.label}:${r.start}-${r.end}`);
    for (const expected of ['proc:0-3', 'repeat:4-6', 'virtual:7-9', 'irp:10-12']) {
        assert.ok(found.includes(expected), expected + ' in ' + found.join(' '));
    }
});

test('comments and strings that look like block words do not open blocks', () => {
    assert.deepEqual(foldingRanges("; macro x {\n; }\nmsg db 'if x'\n").filter((r) => r.label !== 'comment'), []);
});
