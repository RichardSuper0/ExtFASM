'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { evaluateExpression } = require('../../src/analysis/expression');

const constants = new Map([['SYS_write', 1n], ['BASE', 0x40000000n]]);
const value = (text) => evaluateExpression(text, constants);

test('numbers in every FASM notation', () => {
    assert.equal(value('60'), 60n);
    assert.equal(value('0x3C'), 60n);
    assert.equal(value('3Ch'), 60n);
    assert.equal(value('$3C'), 60n);
    assert.equal(value('111100b'), 60n);
    assert.equal(value('74o'), 60n);
    assert.equal(value("'A'"), 65n);
    assert.equal(value("'abc'"), 0x636261n);
});

test('arithmetic uses the usual precedence and parentheses', () => {
    assert.equal(value('2 + 3 * 4'), 14n);
    assert.equal(value('(2 + 3) * 4'), 20n);
    assert.equal(value('10 - 2 - 3'), 5n);
    assert.equal(value('17 mod 5'), 2n);
    assert.equal(value('-1'), 0xffffffffffffffffn);
    assert.equal(value('SYS_write + 1'), 2n);
});

test('bitwise operators work when only one kind is used per level', () => {
    assert.equal(value('1 shl 3'), 8n);
    assert.equal(value('BASE or 5'), 0x40000005n);
    assert.equal(value('0xF0 and 0x3C'), 0x30n);
    assert.equal(value('1 | 2 | 4'), 7n);
    assert.equal(value('(1 shl 3) + 1'), 9n);
    assert.equal(value('not 0'), 0xffffffffffffffffn);
});

test('ambiguous precedence is refused instead of guessed', () => {
    assert.equal(value('1 + 2 shl 3'), null);
    assert.equal(value('1 or 2 and 3'), null);
    assert.equal(value('1 shl 2 or 3'), null);
});

test('unknown symbols, memory, $ and garbage give null', () => {
    assert.equal(value('UNDEFINED_SYMBOL'), null);
    assert.equal(value('[rbx]'), null);
    assert.equal(value('$ + 1'), null);
    assert.equal(value(''), null);
    assert.equal(value('1 +'), null);
    assert.equal(value('(1 + 2'), null);
    assert.equal(value('5 / 0'), null);
});
