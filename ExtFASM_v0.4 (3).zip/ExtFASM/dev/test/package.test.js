'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const pkg = require('../../package.json');
const { sync } = require('../scripts/sync-package');
const { MODIFIER_NAMES, MODIFIER_BY_CATEGORY } = require('../../src/syscalls/presentation');
const { OPERATING_SYSTEMS } = require('../../src/syscalls/os');

test('the Windows versions offered in the settings are exactly the ones present in the data', () => {
    assert.equal(sync(true), true, 'esegui `node dev/scripts/sync-package.js`');
});

test('semantic token modifiers declared in package.json match the ones the code emits', () => {
    assert.deepEqual(pkg.contributes.semanticTokenModifiers.map((modifier) => modifier.id).sort(), [...MODIFIER_NAMES].sort());
    const scopes = pkg.contributes.semanticTokenScopes[0].scopes;
    for (const modifier of MODIFIER_NAMES) {
        assert.ok(scopes[`fasmSyscall.${modifier}`], `manca la mappatura colore per ${modifier}`);
    }
    assert.equal(Object.keys(MODIFIER_BY_CATEGORY).length, 4);
});

test('target.os setting lists every known operating system plus auto', () => {
    const offered = pkg.contributes.configuration.properties['fasm1.target.os'].enum;
    assert.deepEqual(offered.slice().sort(), ['auto', ...Object.keys(OPERATING_SYSTEMS)].sort());
});

test('machine-scoped settings that control what is executed cannot be set from a repository', () => {
    const properties = pkg.contributes.configuration.properties;
    assert.equal(properties['fasm1.compilerPath'].scope, 'machine');
    assert.equal(properties['fasm1.confirmBeforeRun'].scope, 'machine');
});
