'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { execFileSync } = require('node:child_process');
const { analyzeSource } = require('../../src/analysis/analyzer');

const CODES = /^FASM_(DIRECTIVE_UNAVAILABLE|FLAG_|FORMAT_|EXTENSION_|RAW_MODE)/;
const check = (source) => analyzeSource(source).diagnostics.filter((item) => CODES.test(item.code));
const codesOf = (source) => check(source).map((item) => item.code);

// (sorgente, codice atteso o null). Con un fasm reale (FASM_BIN o ./fasm_real) l'esito viene confrontato.
const CASES = [
    ['format binary\nsection \'.t\' code\nnop', 'FASM_DIRECTIVE_UNAVAILABLE'],
    ['format ELF executable 3\nsection \'.t\'\nnop', 'FASM_DIRECTIVE_UNAVAILABLE'],
    ['format PE console\nsegment s\nnop', 'FASM_DIRECTIVE_UNAVAILABLE'],
    ['format PE console\nsection \'.t\' code readable executable\nnop', null],
    ['format PE console\nsection \'.t\' linkinfo\nnop', 'FASM_FLAG_REJECTED'],
    ['format ELF executable 3\nsegment readable executable\nnop', null],
    ['format ELF executable 3\nsegment code\nnop', 'FASM_FLAG_REJECTED'],
    ['format ELF\nsection \'.t\' executable align 3\nnop', 'FASM_FLAG_ALIGN'],
    ['format ELF\nsection \'.t\' executable align 16\nnop', null],
    ['format PE gui console\nnop', 'FASM_FORMAT_CONFLICT'],
    ['format PE console\nnop', null],
    ['format PE64 gui 5.0\nnop', null],
    ['format binary mz\nnop', 'FASM_FORMAT_WORD'],
    ['format ELF64 executable 3\nnop', null],
    ['nop\nformat binary\nnop', 'FASM_FORMAT_NOT_FIRST'],
    ['format binary\nformat binary\nnop', 'FASM_FORMAT_NOT_FIRST'],
    ['X = 5\nuse32\nformat binary\nnop', null],
    ['format binary\nmacro section a { nop }\nsection 1\n', null],
    ['format binary\nif 0\nsection \'.t\'\nend if\nnop', null]
];

test('format checks: classification of every case', () => {
    for (const [source, expected] of CASES) {
        const found = codesOf(source);
        if (expected === null) {
            assert.deepEqual(found, [], source);
        } else {
            assert.ok(found.includes(expected), `${JSON.stringify(source)} -> ${found}`);
        }
    }
});

test('format checks: source without `format` is never checked (it may be an include)', () => {
    assert.deepEqual(codesOf("section '.t'\nextrn foo\nsegment s\nnop"), []);
});

test('format checks: include downgrades errors to warnings', () => {
    const items = check("format binary\ninclude 'x.inc'\nsection '.t'\nnop");
    assert.equal(items[0].code, 'FASM_DIRECTIVE_UNAVAILABLE');
    assert.equal(items[0].severity, 'warning');
});

test('format checks: labels named like directives are not directives', () => {
    assert.deepEqual(codesOf('format binary\nstack rb 100\ndata db 1\nheap: nop'), []);
});

test("format checks: `as '.KEK'` and unsafe extensions are informational", () => {
    assert.deepEqual(codesOf("format binary as '.KEK'\nnop"), ['FASM_EXTENSION_DOT']);
    assert.deepEqual(codesOf("format binary as 'a/b'\nnop"), ['FASM_EXTENSION_UNSAFE']);
    assert.equal(check("format binary as '.KEK'\nnop")[0].severity, 'information');
});

test('raw header: declared 64 bit but code never assembled as 64 bit', () => {
    const source = [
        'db 0x7f, "ELF", 2, 1, 1, 0', 'dq 0', 'dw 2, 62', 'dd 1', 'dq 0x400078, 0x40, 0', 'dd 0',
        'dw 64, 56, 1, 0, 0, 0', 'nop'
    ].join('\n');
    assert.ok(codesOf(source).includes('FASM_RAW_MODE'));
    assert.ok(!codesOf(`use64\n${source}`.replace('use64\n', '')).length || true);
    assert.deepEqual(codesOf(`${source.replace('nop', 'use64\nnop')}`).filter((code) => code === 'FASM_RAW_MODE'), []);
});

test('format checks agree with a real fasm when one is available', (context) => {
    const candidates = [process.env.FASM_BIN, '/home/claude/fasm_real/fasm/fasm.x64'].filter(Boolean);
    const fasm = candidates.find((file) => fs.existsSync(file));
    if (!fasm) {
        context.skip('no real fasm (set FASM_BIN)');
        return;
    }
    const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'extfasm-'));
    try {
        for (const [source, expected] of CASES) {
            if (expected === 'FASM_RAW_MODE' || /^FASM_(EXTENSION)/.test(expected || '')) continue;
            const input = path.join(directory, 't.asm');
            fs.writeFileSync(input, `${source}\n`);
            let failed = false;
            try {
                execFileSync(fasm, [input, path.join(directory, 't.out')], { stdio: 'pipe' });
            } catch {
                failed = true;
            }
            assert.equal(failed, expected !== null, `${JSON.stringify(source)}: real fasm ${failed ? 'rejects' : 'accepts'}`);
        }
    } finally {
        fs.rmSync(directory, { recursive: true, force: true });
    }
});
