'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const i18n = require('../../src/i18n/i18n');
const { debuggerHtml } = require('../../src/ui/debuggerView');

let chromium = null;
try {
    ({ chromium } = require('playwright'));
} catch {
    chromium = null;
}

const commit = (n, size, delta) => ({ hash: `${n}`.repeat(40).slice(0, 40), shortHash: `${n}`.repeat(8), time: 1700000000 + n * 86400, author: 'A', subject: `s${n}`, status: n === 1 ? 'A' : 'M', path: 'a.asm', oldPath: null, size, delta });

test('webview renders every section from real-shaped data, safely, in each language', async (context) => {
    if (!chromium) {
        context.skip('playwright non disponibile');
        return;
    }
    let browser;
    try {
        browser = await chromium.launch();
    } catch {
        context.skip('Chromium non disponibile');
        return;
    }
    const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'extfasm-ui-'));
    try {
        for (const language of i18n.SUPPORTED) {
            i18n.setLanguage(language);
            const file = path.join(directory, `page-${language}.html`);
            fs.writeFileSync(file, debuggerHtml({ nonce: 'abc123', language }));
            const page = await browser.newPage();
            const problems = [];
            page.on('pageerror', (error) => problems.push(String(error)));
            await page.addInitScript(() => { window.__sent = []; window.acquireVsCodeApi = () => ({ postMessage: (message) => window.__sent.push(message) }); });
            await page.goto(`file://${file}`);
            const post = (message) => page.evaluate((payload) => window.postMessage(payload, '*'), message);
            const evil = '<img src=x onerror="window.__pwned=1">';
            await post({ type: 'init', labels: i18n.messagesWithPrefix('dbg.'), locale: language, tab: 'commits' });
            await post({ type: 'file', name: 'a.asm' });
            await post({ type: 'commits', data: { available: true, commits: [commit(3, 300, 100), commit(2, 200, 100), commit(1, 100, null)], worktree: { exists: true, size: 320, dirty: true, binarySize: 50 }, truncated: false } });
            await post({ type: 'errors', data: { items: [{ origin: 'assembler', severity: 'error', line: 5, column: null, message: evil, category: null, reason: 'r' }, { origin: 'runtime', severity: 'error', line: null, column: null, message: 'SIGSEGV', category: 'SIGSEGV', reason: 'r' }] } });
            await post({ type: 'registers', data: { busy: false, error: null, gdb: { available: true, version: 'gdb' }, unsupported: null, snapshot: { status: 'live', arch: 'x86-64', steps: 2, exit: null, stop: null, pc: { name: 'rip', hex: '0x10' }, sp: { name: 'rsp', hex: '0x20' }, instruction: { address: '0x10', text: 'nop' }, flags: [{ name: 'ZF', set: true, changed: true }], registers: [{ name: 'rax', hex: '0x1', decimal: '1', changed: true }, { name: 'rbx', hex: '0x0', decimal: '0', changed: false }] } } });

            assert.equal(await page.locator('rect.bar').count(), 4, language); // 3 commit + copia di lavoro
            await page.locator('rect.bar').nth(0).click();
            await page.locator('rect.bar').nth(2).click({ modifiers: ['Shift'] });
            assert.match(await page.locator('.compare').innerText(), /\+?200|\+? ?200/, language);

            await page.click('#tab-errors');
            assert.equal(await page.locator('li.error').count(), 2);
            assert.equal(await page.evaluate(() => window.__pwned), undefined, 'il messaggio non deve essere interpretato come HTML');
            assert.match(await page.locator('li.error').first().innerText(), /<img src=x/);
            await page.locator('li.error button').first().click();
            assert.deepEqual((await page.evaluate(() => window.__sent)).filter((message) => message.command === 'goto'), [{ command: 'goto', line: 4, column: 0 }]);

            await page.click('#tab-registers');
            assert.equal(await page.locator('tbody tr').count(), 2);
            assert.equal(await page.locator('tr.changed').count(), 1);
            assert.match(await page.locator('.chip').innerText(), /LIVE/);
            await page.focus('#tab-registers');
            await page.keyboard.press('ArrowLeft');
            assert.equal(await page.getAttribute('#tab-resources', 'aria-selected'), 'true');
            assert.deepEqual(problems, [], `${language}: ${problems}`);
            await page.close();
        }
    } finally {
        await browser.close();
        i18n.setLanguage('it');
        fs.rmSync(directory, { recursive: true, force: true });
    }
});
