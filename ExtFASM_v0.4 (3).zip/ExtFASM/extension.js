'use strict';

const { analyzeSymbols } = require('./src/analysis/symbols');
const { foldingRanges } = require('./src/analysis/folding');

const vscode = require('vscode');
const fs = require('fs');
const path = require('path');
const { parseCompilerOutput, findErrorMessage } = require('./src/build/diagnostics');
const { analyzeSource } = require('./src/analysis/analyzer');
const { detectFormat, nativePlatform } = require('./src/analysis/formats');
const {
    resolveCompiler,
    describeCompilerProblem,
    parseIncludePath,
    buildAssemblerEnv,
    computeOutputPath
} = require('./src/build/config');
const { runAssembler } = require('./src/build/assembler');
const { startProgram } = require('./src/build/runProgram');
const { DebuggerPanel } = require('./src/deepdebug/panel');
const { ProcessSampler, snapshotDirectory, diffSnapshots } = require('./src/deepdebug/resources');
const { t, setLanguage } = require('./src/i18n/i18n');
const { analyzeSyscalls } = require('./src/syscalls/engine');
const { predict } = require('./src/analysis/prediction');
const { MODIFIER_BY_CATEGORY, MODIFIER_NAMES, toDiagnostics, hoverMarkdown, findAt } = require('./src/syscalls/presentation');

const LANGUAGE_ID = 'fasm1';
const STATIC_DELAY_MS = 300;
const SYSCALL_TOKEN_TYPE = 'fasmSyscall';

/** Stato condiviso dell'estensione (un solo programma in esecuzione alla volta). */
const state = {
    assemblerDiagnostics: null,
    staticDiagnostics: null,
    syscallDiagnostics: null,
    syscallCache: new Map(),
    syscallTokensChanged: null,
    assemblerOutput: null,
    programOutput: null,
    running: null,
    lastRun: new Map(),
    debuggerPanel: null,
    staticTimers: new Map()
};

function settings(resource) {
    return vscode.workspace.getConfiguration('fasm1', resource);
}

function activate(context) {
    if (vscode.env && vscode.env.language) {
        setLanguage(vscode.env.language);
    }
    state.assemblerDiagnostics = vscode.languages.createDiagnosticCollection('fasm1-assembler');
    state.staticDiagnostics = vscode.languages.createDiagnosticCollection('fasm1-static');
    state.syscallDiagnostics = vscode.languages.createDiagnosticCollection('fasm1-syscalls');
    state.syscallTokensChanged = new vscode.EventEmitter();
    state.assemblerOutput = vscode.window.createOutputChannel('FASM 1');
    state.programOutput = vscode.window.createOutputChannel('FASM 1 – Programma');
    context.subscriptions.push(
        state.assemblerDiagnostics,
        state.staticDiagnostics,
        state.syscallDiagnostics,
        state.syscallTokensChanged,
        state.assemblerOutput,
        state.programOutput
    );

    setRunningContext(false);

    const legend = new vscode.SemanticTokensLegend([SYSCALL_TOKEN_TYPE, ...SYMBOL_TOKEN_TYPES], MODIFIER_NAMES);
    context.subscriptions.push(
        vscode.languages.registerDocumentSemanticTokensProvider({ language: LANGUAGE_ID }, {
            onDidChangeSemanticTokens: state.syscallTokensChanged.event,
            provideDocumentSemanticTokens: (document) => provideSyscallTokens(document, legend)
        }, legend),
        vscode.languages.registerFoldingRangeProvider({ language: LANGUAGE_ID }, {
            provideFoldingRanges: provideFolding
        }),
        vscode.languages.registerHoverProvider({ language: LANGUAGE_ID }, {
            provideHover: provideSyscallHover
        }),
        vscode.languages.registerCompletionItemProvider({ language: LANGUAGE_ID }, {
            provideCompletionItems: provideCompletions
        }),
        vscode.languages.registerInlineCompletionItemProvider({ language: LANGUAGE_ID }, {
            provideInlineCompletionItems: provideInlineCompletions
        })
    );

    context.subscriptions.push(
        vscode.commands.registerCommand('fasm1.build', (uri) => assembleCommand(uri, false)),
        vscode.commands.registerCommand('fasm1.buildAndRun', (uri) => assembleCommand(uri, true)),
        vscode.commands.registerCommand('fasm1.stopProgram', stopProgram),
        vscode.commands.registerCommand('fasm1.openDebugger', openDebugger),
        vscode.commands.registerCommand('fasm1.selectCompiler', () => chooseCompilerFile()),
        vscode.commands.registerCommand('fasm1.openSettings', () => openCompilerSettings()),

        vscode.workspace.onDidOpenTextDocument(scheduleStaticAnalysis),
        vscode.workspace.onDidChangeTextDocument((event) => {
            // Le diagnostiche dell'assemblatore descrivono il testo assemblato: dopo una modifica sono obsolete.
            if (event.document.languageId === LANGUAGE_ID && event.contentChanges.length) {
                state.assemblerDiagnostics.delete(event.document.uri);
            }
            scheduleStaticAnalysis(event.document);
        }),
        vscode.workspace.onDidCloseTextDocument((document) => {
            state.assemblerDiagnostics.delete(document.uri);
            state.staticDiagnostics.delete(document.uri);
            state.syscallDiagnostics.delete(document.uri);
            state.syscallCache.delete(document.uri.toString());
            clearTimeout(state.staticTimers.get(document.uri.toString()));
            state.staticTimers.delete(document.uri.toString());
        }),
        vscode.workspace.onDidSaveTextDocument((document) => {
            if (document.languageId === LANGUAGE_ID && settings(document.uri).get('buildOnSave')) {
                assembleDocument(document, { showResult: false, run: false });
            }
        }),
        vscode.languages.onDidChangeDiagnostics ? vscode.languages.onDidChangeDiagnostics(refreshDebuggerErrors) : { dispose() { } },
        vscode.window.onDidChangeActiveTextEditor ? vscode.window.onDidChangeActiveTextEditor((editor) => {
            if (state.debuggerPanel && editor && editor.document.languageId === LANGUAGE_ID && editor.document.uri.scheme === 'file') {
                state.debuggerPanel.setDocument(editor.document);
            }
        }) : { dispose() { } },
        vscode.workspace.onDidChangeConfiguration((event) => {
            if (event.affectsConfiguration('fasm1.staticAnalysis') || event.affectsConfiguration('fasm1.target') || event.affectsConfiguration('fasm1.syscalls')) {
                state.syscallCache.clear();
                vscode.workspace.textDocuments.forEach(scheduleStaticAnalysis);
                state.syscallTokensChanged.fire();
            }
        })
    );

    vscode.workspace.textDocuments.forEach(scheduleStaticAnalysis);
}

function deactivate() {
    if (state.running) {
        state.running.stop();
    }
    if (state.debuggerPanel) {
        state.debuggerPanel.stopSession();
    }
    state.staticTimers.forEach((timer) => clearTimeout(timer));
    state.staticTimers.clear();
}

// ---------------------------------------------------------------------------
// Analisi statica (live)
// ---------------------------------------------------------------------------

function scheduleStaticAnalysis(document) {
    if (document.languageId !== LANGUAGE_ID) {
        return;
    }
    const key = document.uri.toString();
    clearTimeout(state.staticTimers.get(key));
    state.staticTimers.set(key, setTimeout(() => {
        state.staticTimers.delete(key);
        publishStaticDiagnostics(document);
    }, STATIC_DELAY_MS));
}

function publishStaticDiagnostics(document) {
    if (document.isClosed) {
        return;
    }
    if (!settings(document.uri).get('staticAnalysis', true)) {
        state.staticDiagnostics.delete(document.uri);
    } else {
        publishAnalyzerDiagnostics(document);
    }
    publishSyscallDiagnostics(document);
}

const SEVERITIES = () => ({
    error: vscode.DiagnosticSeverity.Error,
    warning: vscode.DiagnosticSeverity.Warning,
    information: vscode.DiagnosticSeverity.Information,
    hint: vscode.DiagnosticSeverity.Hint
});

function publishAnalyzerDiagnostics(document) {
    const { diagnostics } = analyzeSource(document.getText());
    const severities = SEVERITIES();
    const items = diagnostics.map((item) => {
        const range = item.start === undefined
            ? new vscode.Range(item.line, 0, item.endLine ?? item.line, document.lineAt(item.endLine ?? item.line).text.length)
            : new vscode.Range(item.line, item.start, item.line, Math.max(item.end, item.start + 1));
        const diagnostic = new vscode.Diagnostic(range, item.message, severities[item.severity] ?? vscode.DiagnosticSeverity.Warning);
        diagnostic.source = t('diag.src.static');
        diagnostic.code = item.code;
        return diagnostic;
    });
    state.staticDiagnostics.set(document.uri, items);
}

// ---------------------------------------------------------------------------
// Instruction Prediction (deterministica, senza AI)
// ---------------------------------------------------------------------------

function predictionsAt(document, position) {
    const config = settings(document.uri);
    if (!config.get('prediction.enabled', true)) {
        return [];
    }
    try {
        return predict(document.getText(), { line: position.line, character: position.character }, {
            level: config.get('prediction.level', 'likely'),
            os: config.get('target.os', 'auto'),
            windowsVersion: config.get('target.windowsVersion', '')
        }).suggestions;
    } catch {
        return []; // una prediction non deve mai disturbare la scrittura
    }
}

function provideCompletions(document, position) {
    return predictionsAt(document, position).map((suggestion, index) => {
        const item = new vscode.CompletionItem(suggestion.label, vscode.CompletionItemKind.Snippet);
        item.insertText = new vscode.SnippetString(suggestion.insertText);
        item.detail = suggestion.detail;
        item.documentation = new vscode.MarkdownString(`${suggestion.reason}\n\n_${t('pred.footer')}_`);
        item.sortText = `0${String(index).padStart(3, '0')}`;
        item.filterText = suggestion.label;
        return item;
    });
}

/** Testo "fantasma" solo per il suggerimento di confidenza più alta; si ignora con Esc o continuando a scrivere. */
function provideInlineCompletions(document, position) {
    const best = predictionsAt(document, position)[0];
    if (!best || best.confidence === 'uncertain') {
        return [];
    }
    return [new vscode.InlineCompletionItem(new vscode.SnippetString(best.insertText), new vscode.Range(position, position))];
}

// ---------------------------------------------------------------------------
// Chiamate di sistema (syscall): diagnostica, colori e hover
// ---------------------------------------------------------------------------

/** Risultato dell'analisi per un documento, riusato da diagnostica, colori e hover finché testo e impostazioni non cambiano. */
function syscallResult(document) {
    const config = settings(document.uri);
    if (!config.get('syscalls.enabled', true)) {
        return null;
    }
    const options = { os: config.get('target.os', 'auto'), windowsVersion: config.get('target.windowsVersion', '') };
    const key = document.uri.toString();
    const stamp = `${document.version ?? ''}|${options.os}|${options.windowsVersion}`;
    const cached = state.syscallCache.get(key);
    if (cached && cached.stamp === stamp && document.version !== undefined) {
        return cached.result;
    }
    const result = analyzeSyscalls(document.getText(), options);
    state.syscallCache.set(key, { stamp, result });
    return result;
}

function publishSyscallDiagnostics(document) {
    const result = syscallResult(document);
    if (!result) {
        state.syscallDiagnostics.delete(document.uri);
        return;
    }
    const severities = SEVERITIES();
    const items = toDiagnostics(result.findings).map((item) => {
        const diagnostic = new vscode.Diagnostic(
            new vscode.Range(item.line, item.start, item.line, Math.max(item.end, item.start + 1)),
            item.message,
            severities[item.severity]
        );
        diagnostic.source = t('diag.src.syscall');
        diagnostic.code = item.code;
        return diagnostic;
    });
    state.syscallDiagnostics.set(document.uri, items);
}

const SYMBOL_TOKEN_TYPES = ['macro', 'label', 'variable', 'enumMember'];
const SYMBOL_TOKEN_BY_KIND = { macro: 'macro', label: 'label', variable: 'variable', constant: 'enumMember' };

function provideSyscallTokens(document, legend) {
    const result = syscallResult(document);
    const builder = new vscode.SemanticTokensBuilder(legend);
    for (const finding of result ? result.findings : []) {
        const modifier = MODIFIER_BY_CATEGORY[finding.category];
        builder.push(new vscode.Range(finding.line, finding.start, finding.line, finding.end), SYSCALL_TOKEN_TYPE, modifier ? [modifier] : []);
    }
    // Macro, etichette, dati e costanti definiti nel file (e dove sono usati).
    if (settings(document.uri).get('semanticSymbols', true)) {
        for (const token of analyzeSymbols(document.getText()).tokens) {
            builder.push(new vscode.Range(token.line, token.start, token.line, token.end), SYMBOL_TOKEN_BY_KIND[token.type], []);
        }
    }
    return builder.build();
}

function provideFolding(document) {
    if (!settings(document.uri).get('folding', true)) {
        return [];
    }
    const result = syscallResult(document);
    const syscallLines = result ? result.findings.map((finding) => finding.line) : [];
    return foldingRanges(document.getText(), syscallLines).map((range) =>
        new vscode.FoldingRange(range.start, range.end, range.kind === 'comment' ? vscode.FoldingRangeKind.Comment : vscode.FoldingRangeKind.Region));
}

function provideSyscallHover(document, position) {
    const result = syscallResult(document);
    const finding = result ? findAt(result.findings, position.line, position.character) : null;
    if (!finding) {
        return null;
    }
    const markdown = new vscode.MarkdownString(hoverMarkdown(finding));
    markdown.isTrusted = false;
    return new vscode.Hover(markdown, new vscode.Range(finding.line, finding.start, finding.line, finding.end));
}

// ---------------------------------------------------------------------------
// Percorsi degli strumenti (impostazioni di VS Code)
// ---------------------------------------------------------------------------

/**
 * Restituisce l'eseguibile di FASM oppure null dopo aver guidato l'utente a impostarlo.
 * Il percorso vive in `fasm1.compilerPath` nelle impostazioni utente di VS Code: resta salvato
 * tra aggiornamenti, riavvii e reinstallazioni dell'estensione e non viene mai sovrascritto da qui
 * senza una scelta esplicita dell'utente.
 */
async function ensureCompiler(resource) {
    const configured = settings(resource).get('compilerPath', '');
    const resolved = resolveCompiler(configured);
    if (resolved.ok) {
        return resolved.path;
    }

    const message = `${describeCompilerProblem(resolved)} ${t('compiler.setHint')}`;
    const choice = await vscode.window.showWarningMessage(message, t('btn.enterCommand'), t('btn.chooseFile'), t('btn.openSettings'));
    if (choice === t('btn.enterCommand')) {
        return enterCompilerCommand();
    }
    if (choice === t('btn.openSettings')) {
        await openCompilerSettings();
        return null;
    }
    if (choice === t('btn.chooseFile')) {
        return chooseCompilerFile();
    }
    return null;
}

function openCompilerSettings() {
    return vscode.commands.executeCommand('workbench.action.openSettings', 'fasm1.compilerPath');
}

async function enterCompilerCommand() {
    const value = await vscode.window.showInputBox({
        prompt: t('dlg.commandPrompt'),
        value: 'fasm',
        ignoreFocusOut: true,
        validateInput: (text) => {
            const check = resolveCompiler(text);
            return check.ok ? null : describeCompilerProblem(check);
        }
    });
    if (!value || !value.trim()) {
        return null;
    }
    const check = resolveCompiler(value.trim());
    if (!check.ok) {
        vscode.window.showErrorMessage(describeCompilerProblem(check));
        return null;
    }
    // Si salva ciò che ha scritto l'utente (il nome del comando), non il percorso risolto.
    await settings().update('compilerPath', value.trim(), vscode.ConfigurationTarget.Global);
    vscode.window.showInformationMessage(t('msg.compilerSet', { path: value.trim() }));
    return check.path;
}

async function chooseCompilerFile() {
    const picked = await vscode.window.showOpenDialog({
        canSelectMany: false,
        canSelectFiles: true,
        canSelectFolders: false,
        openLabel: t('btn.useThisFasm'),
        title: t('dlg.selectFasm')
    });
    if (!picked || !picked.length) {
        return null;
    }
    const candidate = picked[0].fsPath;
    const check = resolveCompiler(candidate);
    if (!check.ok) {
        vscode.window.showErrorMessage(describeCompilerProblem(check));
        return null;
    }
    // Impostazione utente (globale): non dipende dalla cartella aperta e non viene persa.
    await settings().update('compilerPath', check.path, vscode.ConfigurationTarget.Global);
    vscode.window.showInformationMessage(t('msg.compilerSet', { path: check.path }));
    return check.path;
}

// ---------------------------------------------------------------------------
// Assemblaggio ed esecuzione
// ---------------------------------------------------------------------------

async function assembleCommand(uri, run) {
    let document;
    try {
        document = uri instanceof vscode.Uri
            ? await vscode.workspace.openTextDocument(uri)
            : vscode.window.activeTextEditor?.document;
    } catch {
        vscode.window.showErrorMessage(t('msg.cannotOpen'));
        return;
    }
    await assembleDocument(document, { showResult: true, run });
}

function expandVariables(value, document) {
    const folder = vscode.workspace.getWorkspaceFolder(document.uri)?.uri.fsPath ?? path.dirname(document.uri.fsPath);
    return String(value || '')
        .replace(/\$\{workspaceFolder\}/g, folder)
        .replace(/\$\{fileDirname\}/g, path.dirname(document.uri.fsPath));
}

async function assembleDocument(document, { showResult, run }) {
    if (!document || document.languageId !== LANGUAGE_ID || document.uri.scheme !== 'file') {
        vscode.window.showWarningMessage(t('msg.openSavedFile'));
        return null;
    }
    if (document.isDirty && !(await document.save())) {
        return null;
    }

    const compiler = await ensureCompiler(document.uri);
    if (!compiler) {
        return null;
    }

    const config = settings(document.uri);
    const sourcePath = document.uri.fsPath;
    const sourceName = path.basename(sourcePath);
    const format = detectFormat(document.getText());

    const outputDirectory = expandVariables(config.get('outputDirectory', ''), document);
    const output = computeOutputPath(sourcePath, format, outputDirectory);
    if (!output.ok) {
        vscode.window.showErrorMessage(t('msg.wouldOverwrite', { name: path.basename(output.path) }));
        return null;
    }
    try {
        fs.mkdirSync(output.directory, { recursive: true });
    } catch (error) {
        vscode.window.showErrorMessage(t('msg.cannotCreateDir', { error: error.message }));
        return null;
    }

    const includes = parseIncludePath([].concat(config.get('includePath', [])).map((entry) => expandVariables(entry, document)));
    const log = state.assemblerOutput;
    includes.missing.forEach((entry) => log.appendLine(t('log.includeMissing', { path: entry })));

    log.appendLine(`\n> ${compiler} "${sourcePath}" "${output.path}"`);
    if (includes.valid.length) {
        log.appendLine(t('log.includeEnv', { paths: includes.valid.join(path.delimiter) }));
    }

    const result = await vscode.window.withProgress(
        { location: vscode.ProgressLocation.Window, title: t('progress.assembling', { name: sourceName }) },
        () => runAssembler({
            compiler,
            sourcePath,
            outputPath: output.path,
            env: buildAssemblerEnv(process.env, includes.valid)
        })
    );

    const text = [result.stdout, result.stderr].filter(Boolean).join('\n').trim();
    if (text) {
        log.appendLine(text);
    }
    log.appendLine(result.spawnError
        ? t('log.cannotStart', { error: result.spawnError })
        : t('log.exitCode', { code: result.exitCode, timeout: result.timedOut ? t('log.timeout') : '' }));

    if (result.spawnError) {
        if (showResult) {
            vscode.window.showErrorMessage(t('msg.cannotStartFasm', { error: result.spawnError }), t('btn.openSettings'))
                .then((choice) => choice && openCompilerSettings());
        }
        return null;
    }

    const parsed = parseCompilerOutput(text, sourcePath);
    const failed = result.exitCode !== 0;
    publishAssemblerDiagnostics(document, parsed, failed);

    if (failed) {
        if (showResult) {
            const detail = parsed.length
                ? t('msg.errorsIn', { count: parsed.length, name: sourceName })
                : `${findErrorMessage(text) ?? t('msg.assemblyFailed')} (${sourceName}).`;
            vscode.window.showErrorMessage(`FASM: ${detail}`, t('btn.openOutput')).then((choice) => choice && log.show(true));
        }
        return null;
    }

    if (showResult && !run) {
        vscode.window.showInformationMessage(t('msg.buildDone', { name: path.basename(output.path) }));
    }
    if (run) {
        await runOutput(document, format, output.path);
    }
    return { outputPath: output.path, format };
}

function publishAssemblerDiagnostics(document, parsed, failed) {
    const items = parsed.map((item) => {
        const line = Math.min(item.line, document.lineCount - 1);
        const textLine = document.lineAt(line);
        const start = textLine.firstNonWhitespaceCharacterIndex;
        const range = new vscode.Range(line, start, line, Math.max(textLine.text.length, start + 1));
        const message = item.via ? `${item.message} (in ${item.via})` : item.message;
        const diagnostic = new vscode.Diagnostic(range, message, vscode.DiagnosticSeverity.Error);
        diagnostic.source = t('diag.src.assembler');
        // FASM indica solo la riga, non la colonna: si segna la riga intera.
        return diagnostic;
    });
    if (failed || items.length) {
        state.assemblerDiagnostics.set(document.uri, items);
    } else {
        state.assemblerDiagnostics.delete(document.uri);
    }
}

/** Controlli prima di eseguire qualcosa: formato avviabile qui, cartella fidata, nessun altro programma, conferma. */
async function checkRunnable(document, format, outputPath) {
    const expected = nativePlatform(format);
    if (!expected) {
        vscode.window.showInformationMessage(t('msg.builtNotRunnable', { name: path.basename(outputPath), format: format.kind }));
        return false;
    }
    if (expected !== process.platform) {
        vscode.window.showWarningMessage(t('msg.builtWrongPlatform', { name: path.basename(outputPath), format: format.kind.toUpperCase(), platform: process.platform }));
        return false;
    }
    if (!vscode.workspace.isTrusted) {
        vscode.window.showWarningMessage(t('msg.untrusted'));
        return false;
    }
    if (state.running) {
        const choice = await vscode.window.showWarningMessage(t('msg.alreadyRunning'), t('btn.stop'));
        if (choice === t('btn.stop')) {
            stopProgram();
        }
        return false;
    }
    return confirmExecution(document, outputPath);
}

async function confirmExecution(document, outputPath) {
    if (settings(document.uri).get('confirmBeforeRun', true)) {
        const choice = await vscode.window.showWarningMessage(
            t('msg.confirmRun', { path: outputPath }),
            { modal: true },
            t('btn.run'),
            t('btn.runNoAsk')
        );
        if (!choice) {
            return false;
        }
        if (choice === t('btn.runNoAsk')) {
            await settings().update('confirmBeforeRun', false, vscode.ConfigurationTarget.Global);
        }
    }
    return true;
}

async function runOutput(document, format, outputPath, { measure = null } = {}) {
    if (!(await checkRunnable(document, format, outputPath))) {
        return null;
    }
    return executeProgram(document, outputPath, measure);
}

/** Avvia il programma (già confermato), mostra l'output e, se richiesto, lo campiona. */
async function executeProgram(document, outputPath, measure) {
    const channel = state.programOutput;
    channel.show(true);
    channel.appendLine(`\n> ${outputPath}`);
    const outputDirectory = path.dirname(outputPath);
    const before = measure ? snapshotDirectory(outputDirectory) : null;
    const started = Date.now();
    const program = startProgram({
        command: outputPath,
        cwd: outputDirectory,
        onStdout: (chunk) => channel.append(chunk),
        onStderr: (chunk) => channel.append(chunk)
    });
    state.running = program;
    setRunningContext(true);
    const sampler = measure && program.pid ? new ProcessSampler({ pid: program.pid, executable: outputPath, intervalMs: measure.intervalMs }) : null;
    if (sampler) sampler.start();

    const result = await program.done;
    const wallMs = Date.now() - started;
    state.running = null;
    setRunningContext(false);
    state.lastRun.set(document.uri.toString(), result);

    if (result.error) {
        channel.appendLine(`\n${t('log.cannotRun', { error: result.error })}`);
    } else if (result.signal) {
        channel.appendLine(`\n${t('log.signal', { signal: result.signal })}`);
    } else {
        channel.appendLine(`\n${t('log.exited', { code: result.exitCode })}`);
    }
    refreshDebuggerErrors();
    if (!measure) {
        return result;
    }
    const profile = sampler ? sampler.finish({ wallMs }) : { supported: false, samples: 0, intervalMs: measure.intervalMs, overheadMs: 0, cpu: { status: 'not-supported' }, memory: { status: 'not-supported' }, io: { status: 'not-supported' }, series: [] };
    const outcome = result.error ? t('dbg.res.outcome.error', { error: result.error })
        : result.signal ? t('dbg.res.outcome.signal', { signal: result.signal })
            : t('dbg.res.outcome.exit', { code: result.exitCode });
    return { ...profile, name: path.basename(outputPath), wallMs, outcome, files: diffSnapshots(before, snapshotDirectory(outputDirectory)) };
}

function stopProgram() {
    if (!state.running) {
        vscode.window.showInformationMessage(t('msg.noProgram'));
        return;
    }
    state.running.stop();
}

function setRunningContext(value) {
    vscode.commands.executeCommand('setContext', 'fasm1.running', value);
}

// ---------------------------------------------------------------------------
// Apri Debugger (Deep Debug): File Commits, File Errors, Resources & Performance, CPU Registers
// ---------------------------------------------------------------------------

function fasmDocument() {
    const active = vscode.window.activeTextEditor && vscode.window.activeTextEditor.document;
    return active && active.languageId === LANGUAGE_ID && active.uri.scheme === 'file' ? active : null;
}

function debuggerHost() {
    return {
        settings,
        isTrusted: () => vscode.workspace.isTrusted,
        activeDocument: fasmDocument,
        diagnostics: (document) => ({
            assembler: state.assemblerDiagnostics.get ? state.assemblerDiagnostics.get(document.uri) || [] : [],
            static: state.staticDiagnostics.get ? state.staticDiagnostics.get(document.uri) || [] : [],
            syscall: state.syscallDiagnostics.get ? state.syscallDiagnostics.get(document.uri) || [] : []
        }),
        lastRun: (document) => state.lastRun.get(document.uri.toString()) || null,
        outputPathFor: (document) => {
            const output = computeOutputPath(document.uri.fsPath, detectFormat(document.getText()), expandVariables(settings(document.uri).get('outputDirectory', ''), document));
            return output.ok ? output.path : null;
        },
        assemble: (document) => assembleDocument(document, { showResult: false, run: false }),
        confirmRun: async (document, outputPath) => {
            if (!vscode.workspace.isTrusted) {
                vscode.window.showWarningMessage(t('msg.untrusted'));
                return false;
            }
            return confirmExecution(document, outputPath);
        },
        runMeasured: (document, format, outputPath, measure) => runOutput(document, format, outputPath, { measure }),
        reveal: async (uri, line, column) => {
            const document = await vscode.workspace.openTextDocument(uri);
            const editor = await vscode.window.showTextDocument(document, { preview: false, viewColumn: vscode.ViewColumn.One });
            const position = new vscode.Position(line, column);
            editor.selection = new vscode.Selection(position, position);
            editor.revealRange(new vscode.Range(position, position));
        }
    };
}

function openDebugger() {
    if (!state.debuggerPanel) {
        state.debuggerPanel = new DebuggerPanel({ vscode, host: debuggerHost() });
    }
    state.debuggerPanel.open(fasmDocument());
}

function refreshDebuggerErrors() {
    if (state.debuggerPanel) {
        state.debuggerPanel.refreshErrors();
    }
}

module.exports = { activate, deactivate };
