'use strict';

/**
 * Valutatore prudente di espressioni costanti FASM (interi a 64 bit, BigInt).
 * Restituisce `null` quando il valore non è determinabile con certezza: simbolo sconosciuto,
 * etichetta o `$` non forniti dal chiamante, memoria, oppure operatori il cui ordine di precedenza è ambiguo.
 *
 * Regola di prudenza: tra parentesi si accettano solo (a) operatori aritmetici (+ - * / mod, con
 * la precedenza usuale) oppure (b) un solo tipo di operatore bit a bit/di scorrimento
 * (and or xor shl shr | & ^ << >>). Mescolare le due famiglie senza parentesi, o più operatori
 * bit a bit diversi, dà `null`: la precedenza di FASM non coincide con quella del C e non si indovina.
 */

const WORD_OPERATORS = new Set(['and', 'or', 'xor', 'shl', 'shr', 'mod', 'not']);
const BITWISE = new Set(['and', 'or', 'xor', 'shl', 'shr']);
const ARITHMETIC = new Set(['+', '-', '*', '/', 'mod']);
const SYMBOL_TO_WORD = { '|': 'or', '&': 'and', '^': 'xor', '<<': 'shl', '>>': 'shr' };
const MASK = (1n << 64n) - 1n;

function tokenize(text) {
    const tokens = [];
    let index = 0;
    const source = String(text).trim();
    while (index < source.length) {
        const rest = source.slice(index);
        let match;
        if ((match = /^\s+/.exec(rest))) {
            index += match[0].length;
            continue;
        }
        if ((match = /^(['"])((?:(?!\1).){1,8})\1(?!\1)/.exec(rest))) {
            // costante carattere: little endian, come FASM ('abc' = 0x636261)
            let value = 0n;
            [...match[2]].reverse().forEach((character) => {
                value = (value << 8n) | BigInt(character.charCodeAt(0) & 0xff);
            });
            tokens.push({ type: 'num', value });
            index += match[0].length;
            continue;
        }
        if ((match = /^(?:0x([0-9a-f]+)|\$([0-9][0-9a-f]*)|([0-9][0-9a-f]*)h|([01]+)b|([0-7]+)[oq]|([0-9]+))(?![\w.$@?])/i.exec(rest))) {
            let value;
            if (match[1] !== undefined) value = BigInt(`0x${match[1]}`);
            else if (match[2] !== undefined) value = BigInt(`0x${match[2]}`);
            else if (match[3] !== undefined) value = BigInt(`0x${match[3]}`);
            else if (match[4] !== undefined) value = BigInt(`0b${match[4]}`);
            else if (match[5] !== undefined) value = BigInt(`0o${match[5]}`);
            else value = BigInt(match[6]);
            tokens.push({ type: 'num', value });
            index += match[0].length;
            continue;
        }
        if ((match = /^(<<|>>|[-+*/|&^~()])/.exec(rest))) {
            tokens.push({ type: 'op', value: SYMBOL_TO_WORD[match[1]] || match[1] });
            index += match[0].length;
            continue;
        }
        if ((match = /^[A-Za-z_.@?][\w.@?$]*/.exec(rest))) {
            const word = match[0].toLowerCase();
            tokens.push(WORD_OPERATORS.has(word) ? { type: 'op', value: word } : { type: 'id', value: match[0] });
            index += match[0].length;
            continue;
        }
        if ((match = /^\$\$|^\$(?![\w$%])/.exec(rest))) {
            // `$` (indirizzo corrente) e `$$` (inizio del blocco): hanno un valore solo se il chiamante lo fornisce.
            tokens.push({ type: 'id', value: match[0] });
            index += match[0].length;
            continue;
        }
        return null; // carattere non gestito ([ ], `$%`, ecc.)
    }
    return tokens;
}

/**
 * @param {string} text espressione
 * @param {Map<string,bigint>|{get(name:string):bigint|undefined}} constants costanti note
 * @returns {bigint|null} valore a 64 bit senza segno, oppure null
 */
function evaluateExpression(text, constants) {
    const tokens = tokenize(text);
    if (!tokens || !tokens.length) {
        return null;
    }
    let position = 0;
    let failed = false;

    const peek = () => tokens[position];
    const take = () => tokens[position++];
    const fail = () => {
        failed = true;
        return null;
    };

    function parseUnary() {
        const token = take();
        if (!token) return fail();
        if (token.type === 'num') return token.value;
        if (token.type === 'id') {
            const value = constants && constants.get ? constants.get(token.value) : undefined;
            return value === undefined || value === null ? fail() : value;
        }
        if (token.value === '(') {
            const inner = parseLevel();
            const close = take();
            if (!close || close.value !== ')') return fail();
            return inner;
        }
        if (token.value === '-') {
            const operand = parseUnary();
            return operand === null ? null : -operand;
        }
        if (token.value === '+') return parseUnary();
        if (token.value === '~' || token.value === 'not') {
            const operand = parseUnary();
            return operand === null ? null : ~operand;
        }
        return fail();
    }

    // Un "livello" è il contenuto di una coppia di parentesi (o l'intera espressione).
    function parseLevel() {
        const terms = [parseUnary()];
        const operators = [];
        while (!failed && peek() && peek().type === 'op' && peek().value !== ')' && peek().value !== '(') {
            const operator = take().value;
            if (operator === '~' || operator === 'not') return fail();
            operators.push(operator);
            terms.push(parseUnary());
        }
        if (failed || terms.includes(null)) return fail();
        if (!operators.length) return terms[0];

        const arithmetic = operators.every((operator) => ARITHMETIC.has(operator));
        const bitwise = operators.every((operator) => BITWISE.has(operator));
        if (arithmetic) {
            return evaluateArithmetic(terms, operators);
        }
        if (bitwise && new Set(operators).size === 1) {
            return terms.slice(1).reduce((accumulator, term) => applyBitwise(operators[0], accumulator, term), terms[0]);
        }
        return fail(); // famiglie mescolate o più operatori bit a bit diversi: precedenza non garantita
    }

    function evaluateArithmetic(terms, operators) {
        // `* / mod` hanno precedenza su `+ -`.
        const values = [terms[0]];
        const additive = [];
        for (let index = 0; index < operators.length; index += 1) {
            const operator = operators[index];
            const term = terms[index + 1];
            if (operator === '+' || operator === '-') {
                additive.push(operator);
                values.push(term);
            } else {
                if ((operator === '/' || operator === 'mod') && term === 0n) return fail();
                const last = values.pop();
                values.push(operator === '*' ? last * term : operator === '/' ? last / term : last % term);
            }
        }
        return values.slice(1).reduce((accumulator, value, index) => (additive[index] === '+' ? accumulator + value : accumulator - value), values[0]);
    }

    function applyBitwise(operator, left, right) {
        const a = BigInt.asUintN(64, left);
        const b = BigInt.asUintN(64, right);
        switch (operator) {
            case 'and': return a & b;
            case 'or': return a | b;
            case 'xor': return a ^ b;
            case 'shl': return b > 63n ? 0n : (a << b) & MASK;
            default: return b > 63n ? 0n : a >> b;
        }
    }

    const result = parseLevel();
    if (failed || result === null || position !== tokens.length) {
        return null;
    }
    return BigInt.asUintN(64, result);
}

module.exports = { evaluateExpression, tokenize };
