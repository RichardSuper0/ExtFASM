'use strict';

/**
 * Simboli definiti nel sorgente (macro, struc, etichette, dati, costanti) e dove vengono usati.
 * Serve ai token semantici: un nome è colorato solo se nel file è DEFINITO, così non si colora a caso
 * ciò che potrebbe essere altro. Definizioni in file inclusi (`include`) non sono visibili: quei nomi
 * restano non colorati.
 */

const IDENT = /[A-Za-z_.$?@][\w.$?@]*/g;
const DATA_WORDS = new Set(['db', 'dw', 'dd', 'dp', 'df', 'dq', 'dt', 'du', 'rb', 'rw', 'rd', 'rp', 'rf', 'rq', 'rt', 'file']);

/** Toglie commenti e contenuto delle stringhe (FASM: ' e " senza escape, delimitatore raddoppiato) sostituendoli con spazi. */
function maskLine(line) {
    let out = '';
    let quote = null;
    for (let i = 0; i < line.length; i += 1) {
        const ch = line[i];
        if (quote) {
            out += ' ';
            if (ch === quote) {
                quote = null;
            }
            continue;
        }
        if (ch === ';') {
            out += ' '.repeat(line.length - i);
            break;
        }
        if (ch === '"' || ch === "'") {
            quote = ch;
            out += ' ';
            continue;
        }
        out += ch;
    }
    return out;
}

/**
 * @returns {{tokens: {line:number,start:number,end:number,type:'macro'|'label'|'variable'|'constant'}[],
 *            macros: Set<string>, labels: Set<string>}}
 */
function analyzeSymbols(text) {
    const lines = String(text).split(/\r?\n/).map(maskLine);
    const macros = new Map(); // nome minuscolo -> tipo
    const names = new Map(); // nome qualificato -> tipo
    const qualify = (name, owner) => (name.startsWith('.') && owner ? owner + name : name);

    // Passata 1: definizioni.
    let owner = '';
    let macroDepth = 0;
    const parsed = lines.map((line, index) => {
        const info = { index, line, defined: null, first: null };
        const trimmed = line.trim();
        if (!trimmed) {
            return info;
        }
        let rest = line;
        let offset = 0;
        const lead = /^\s*/.exec(line)[0].length;
        rest = line.slice(lead);
        offset = lead;

        const macroDef = /^(macro|struc|struct)\s+([A-Za-z_.$?@][\w.$?@]*)/i.exec(rest);
        if (macroDef) {
            const name = macroDef[2];
            macros.set(name.toLowerCase(), 'macro');
            info.defined = { name, start: offset + macroDef[0].length - name.length, kind: 'macro' };
            if (/\{\s*$/.test(rest) || /\bmacro\b/i.test(macroDef[1])) {
                macroDepth += (rest.match(/\{/g) || []).length - (rest.match(/\}/g) || []).length;
            }
            return info;
        }
        if (macroDepth > 0) {
            macroDepth += (rest.match(/\{/g) || []).length - (rest.match(/\}/g) || []).length;
            return info;
        }

        // etichetta di codice: nome:
        const label = /^((?:[A-Za-z_.$?@][\w.$?@]*)|@@)\s*:(?!:)/.exec(rest);
        if (label && label[1] !== '@@') {
            const name = label[1];
            if (!name.startsWith('.')) {
                owner = name;
            }
            names.set(qualify(name, owner), 'label');
            info.defined = { name, start: offset, kind: 'label', owner };
            rest = rest.slice(label[0].length);
            offset += label[0].length;
        }
        // nome seguito da dati o costante: nome db ... / nome = ... / nome equ ...
        const second = /^\s*([A-Za-z_.$?@][\w.$?@]*)\s*(db|dw|dd|dp|df|dq|dt|du|rb|rw|rd|rp|rf|rq|rt|=|equ|fix|struc)?(?![\w.$?@])/i.exec(rest);
        if (!info.defined && second && second[2]) {
            const kind = DATA_WORDS.has(second[2].toLowerCase()) ? 'variable' : second[2].toLowerCase() === 'struc' ? null : 'constant';
            if (kind) {
                const name = second[1];
                names.set(qualify(name, owner), kind);
                info.defined = { name, start: offset + second[0].indexOf(name), kind, owner };
            }
        }
        info.rest = rest;
        info.offset = offset;
        info.owner = owner;
        return info;
    });

    // Passata 2: usi (e definizioni) come token.
    const tokens = [];
    owner = '';
    for (const info of parsed) {
        if (info.defined) {
            const { name, start, kind } = info.defined;
            const type = kind;
            tokens.push({ line: info.index, start, end: start + name.length, type });
            if (kind === 'label' && !name.startsWith('.')) {
                owner = name;
            }
        }
        if (info.rest === undefined) {
            continue;
        }
        let first = true;
        const body = info.defined && info.defined.kind !== 'label' ? '' : info.rest;
        IDENT.lastIndex = 0;
        let match;
        while ((match = IDENT.exec(body)) !== null) {
            const word = match[0];
            const start = info.offset + match.index;
            if (first) {
                first = false;
                // primo termine dell'istruzione: può essere l'invocazione di una macro
                if (macros.has(word.toLowerCase())) {
                    tokens.push({ line: info.index, start, end: start + word.length, type: 'macro' });
                    continue;
                }
            }
            const type = names.get(qualify(word, owner));
            if (type) {
                tokens.push({ line: info.index, start, end: start + word.length, type });
            }
        }
    }
    return { tokens, macros: new Set(macros.keys()), labels: new Set(names.keys()) };
}

module.exports = { analyzeSymbols, maskLine };
