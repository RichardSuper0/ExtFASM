'use strict';

const { t } = require('../i18n/i18n');

/**
 * Header "raw": programmi `format binary` che costruiscono a mano l'intestazione ELF, PE/MZ o MENUET
 * con `db`, `dw`, `dd`, `dq`… invece di usare le direttive integrate (`format ELF executable 3`,
 * `format PE console`, …).
 *
 * 1) `buildImage` ricostruisce i primi byte emessi dal sorgente (dati, `times`, `dup`, etichette,
 *    `$`, `$$`, `org`, costanti). Un byte il cui valore non si può determinare vale `null`
 *    (mai indovinato) e ogni byte ricorda da quale elemento del sorgente proviene.
 * 2) `detectRawHeader` legge quei byte come FASM/il sistema operativo li leggerebbe e ne ricava formato,
 *    classe (32/64 bit), ABI, macchina, sottosistema… più le posizioni nel sorgente (`evidence`),
 *    usate per hover e colori.
 *
 * Si ferma alla prima istruzione o costrutto di cui non può calcolare la dimensione (macro, `file`,
 * `if`…): l'header si trova all'inizio, il codice viene dopo.
 */

const { evaluateExpression } = require('./expression');
const { DATA_DIRECTIVES, RESERVE_DIRECTIVES, INSTRUCTIONS, PREFIXES } = require('./instructions');

const MAX_BYTES = 4096;
const MAX_REPEAT = 1 << 20;
const MASK64 = (1n << 64n) - 1n;

const ELF_ABI_NAMES = {
    0: 'UNIX System V', 1: 'HP-UX', 2: 'NetBSD', 3: 'Linux', 4: 'GNU Hurd',
    5: '86Open (riservato)', 6: 'Solaris', 7: 'AIX', 8: 'IRIX', 9: 'FreeBSD'
};
const PE_SUBSYSTEMS = {
    1: 'native', 2: 'gui', 3: 'console', 10: 'efi', 11: 'efiboot', 12: 'efiruntime'
};

// ---------------------------------------------------------------------------------------------------------
// Lessico
// ---------------------------------------------------------------------------------------------------------

/** Toglie il commento (`;` fuori dalle stringhe). Restituisce null se resta una stringa non chiusa. */
function codeOf(line) {
    let quote = null;
    for (let index = 0; index < line.length; index += 1) {
        const character = line[index];
        if (quote) {
            if (character === quote) {
                quote = null;
            }
        } else if (character === '"' || character === "'") {
            quote = character;
        } else if (character === ';') {
            return line.slice(0, index);
        }
    }
    return quote ? null : line;
}

/** Divide `text` alle virgole di primo livello (fuori da stringhe e parentesi); ogni pezzo porta la sua posizione. */
function splitItems(text, offset) {
    const items = [];
    let depth = 0;
    let quote = null;
    let start = 0;
    const push = (end) => {
        const raw = text.slice(start, end);
        const leading = raw.length - raw.trimStart().length;
        const trimmed = raw.trim();
        items.push({ text: trimmed, start: offset + start + leading, end: offset + start + leading + trimmed.length });
    };
    for (let index = 0; index < text.length; index += 1) {
        const character = text[index];
        if (quote) {
            if (character === quote) {
                quote = null;
            }
        } else if (character === '"' || character === "'") {
            quote = character;
        } else if ('([{'.includes(character)) {
            depth += 1;
        } else if (')]}'.includes(character)) {
            depth -= 1;
        } else if (character === ',' && depth === 0) {
            push(index);
            start = index + 1;
        }
    }
    push(text.length);
    return items;
}

function isQuotedString(text) {
    return /^(['"])(?:(?!\1).)*\1$/.test(text);
}

function utf8Bytes(text) {
    return [...Buffer.from(text, 'utf8')];
}

// ---------------------------------------------------------------------------------------------------------
// Ricostruzione dei byte
// ---------------------------------------------------------------------------------------------------------

class Image {
    constructor(previous) {
        this.bytes = [];
        this.sources = [];
        this.labels = new Map();
        this.constants = new Map();
        this.previous = previous || null; // etichette/costanti della prima passata (riferimenti in avanti)
        this.origin = { offset: 0, address: 0n };
        this.stop = null;
        this.truncated = false;
        this.virtualDepth = 0;
        this.macroDepth = 0;
        this.macroPending = false;
    }

    get address() {
        return this.origin.address + BigInt(this.bytes.length - this.origin.offset);
    }

    symbols() {
        const table = new Map();
        if (this.previous) {
            for (const [name, value] of this.previous.constants) table.set(name, value);
            for (const [name, value] of this.previous.labels) table.set(name, value);
        }
        for (const [name, value] of this.constants) table.set(name, value);
        for (const [name, value] of this.labels) table.set(name, value);
        table.set('$', this.address);
        table.set('$$', this.origin.address);
        return table;
    }

    value(text) {
        return evaluateExpression(text, this.symbols());
    }

    emit(values, source) {
        for (const value of values) {
            if (this.bytes.length >= MAX_BYTES) {
                this.truncated = true;
                return false;
            }
            this.bytes.push(value);
            this.sources.push(source);
        }
        return true;
    }
}

function littleEndian(value, size) {
    const out = [];
    let rest = BigInt.asUintN(64, value);
    for (let index = 0; index < size; index += 1) {
        out.push(Number(rest & 0xffn));
        rest >>= 8n;
    }
    return out;
}

/** Elementi di un'istruzione dati (`db 1, 'ab', 4 dup (0)`) -> byte. Restituisce false se non si può continuare. */
function emitDataItems(image, size, items, lineNumber) {
    for (const item of items) {
        const source = { line: lineNumber, start: item.start, end: item.end };
        const text = item.text;
        if (!text) {
            return false;
        }
        if (text === '?') {
            if (!image.emit(new Array(size).fill(null), source)) return false;
            continue;
        }
        const dup = /^(.+?)\s+dup\s*(.*)$/i.exec(text);
        if (dup) {
            const count = image.value(dup[1]);
            let inner = dup[2].trim();
            if (count === null || count > BigInt(MAX_REPEAT) || !inner) {
                return false;
            }
            if (inner.startsWith('(') && inner.endsWith(')')) {
                inner = inner.slice(1, -1);
            }
            const innerStart = item.start + text.indexOf(inner, dup[1].length);
            const innerItems = splitItems(inner, innerStart);
            for (let repeat = 0n; repeat < count; repeat += 1n) {
                if (!emitDataItems(image, size, innerItems, lineNumber)) return false;
                if (image.truncated) return true;
            }
            continue;
        }
        if (isQuotedString(text) && size === 1) {
            if (!image.emit(utf8Bytes(text.slice(1, -1)), source)) return false;
            continue;
        }
        if (isQuotedString(text) && size === 2 && image.unicode) {
            const units = [];
            for (const character of text.slice(1, -1)) {
                units.push(...littleEndian(BigInt(character.codePointAt(0)), 2));
            }
            if (!image.emit(units, source)) return false;
            continue;
        }
        const value = size <= 8 ? image.value(text) : null;
        const bytes = value === null ? new Array(size).fill(null) : littleEndian(value, Math.min(size, 8));
        while (bytes.length < size) {
            bytes.push(value === null ? null : 0);
        }
        if (!image.emit(bytes, source)) return false;
    }
    return true;
}

/** Primo mnemonic/direttiva di una riga di codice e il resto. */
function firstWord(text) {
    const match = /^([A-Za-z_.$?@][\w.$?@]*)\s*(.*)$/.exec(text);
    return match ? { word: match[1], lower: match[1].toLowerCase(), rest: match[2], restOffset: text.length - match[2].length } : null;
}

const LABEL_COLON = /^([A-Za-z_.$?@][\w.$?@]*)\s*:(?!:)\s*/;

function stopWith(image, line, reason) {
    image.stop = { line, reason };
    return false;
}

function processLine(image, line, lineNumber) {
    const code = codeOf(line);
    if (code === null) {
        return stopWith(image, lineNumber, 'unclosed-string');
    }
    let text = code.trim();
    if (!text) {
        return true;
    }
    let column = code.length - code.trimStart().length;

    // Blocchi che non emettono byte nell'immagine (corpi di macro/struc, virtual).
    if (image.macroDepth > 0 || image.macroPending) {
        const opens = (text.match(/\{/g) || []).length;
        const closes = (text.match(/\}/g) || []).length;
        image.macroDepth += opens - closes;
        if (opens > 0) image.macroPending = false;
        if (image.macroDepth <= 0 && opens + closes > 0) {
            image.macroDepth = 0;
        }
        return true;
    }
    if (/^(?:macro|struc)\b/i.test(text)) {
        image.macroPending = true;
        const opens = (text.match(/\{/g) || []).length;
        const closes = (text.match(/\}/g) || []).length;
        image.macroDepth = opens - closes;
        if (opens > 0) image.macroPending = false;
        if (image.macroDepth <= 0 && opens > 0) image.macroDepth = 0;
        return true;
    }
    if (/^virtual\b/i.test(text)) {
        image.virtualDepth += 1;
        return true;
    }
    if (/^end\s+virtual\b/i.test(text)) {
        image.virtualDepth = Math.max(0, image.virtualDepth - 1);
        return true;
    }
    if (image.virtualDepth > 0) {
        return true;
    }

    // Etichette `nome:` (anche più d'una).
    for (let match = LABEL_COLON.exec(text); match; match = LABEL_COLON.exec(text)) {
        image.labels.set(match[1], image.address);
        text = text.slice(match[0].length);
        column += match[0].length;
    }
    if (!text) {
        return true;
    }

    // Costanti `nome = valore`, `nome equ valore`.
    const definition = /^([A-Za-z_.$?@][\w.$?@]*)\s*(?:=|\bequ\b)\s*(.+)$/i.exec(text);
    if (definition && !DATA_DIRECTIVES.has(definition[1].toLowerCase())) {
        const value = image.value(definition[2]);
        if (value !== null) image.constants.set(definition[1], value);
        return true;
    }

    let head = firstWord(text);
    if (!head) {
        return stopWith(image, lineNumber, 'unknown');
    }

    // `nome db ...`: etichetta di dati.
    if (!DATA_DIRECTIVES.has(head.lower) && head.rest) {
        const next = firstWord(head.rest);
        if (next && DATA_DIRECTIVES.has(next.lower) && !INSTRUCTIONS.has(head.lower) && !PREFIXES.has(head.lower)) {
            image.labels.set(head.word, image.address);
            column += head.restOffset;
            text = head.rest;
            head = next;
        }
    }

    // `times N db ...`
    if (head.lower === 'times') {
        const match = /^(.*?)\s+(db|dw|dd|dp|df|dq|dt|du|rb|rw|rd|rp|rf|rq|rt)\b\s*(.*)$/i.exec(head.rest);
        if (!match) {
            return stopWith(image, lineNumber, 'times');
        }
        const count = image.value(match[1]);
        if (count === null || count < 0n || count > BigInt(MAX_REPEAT)) {
            return stopWith(image, lineNumber, 'times-count');
        }
        const directive = match[2].toLowerCase();
        const bodyOffset = column + text.length - match[3].length;
        const items = splitItems(match[3], bodyOffset);
        for (let repeat = 0n; repeat < count; repeat += 1n) {
            const ok = RESERVE_DIRECTIVES.has(directive)
                ? emitReserve(image, directive, match[3], lineNumber, bodyOffset)
                : emitDataItems(image, DATA_DIRECTIVES.get(directive), items, lineNumber);
            if (!ok) return stopWith(image, lineNumber, 'times-body');
            if (image.truncated) return false;
        }
        return true;
    }

    if (DATA_DIRECTIVES.has(head.lower)) {
        if (head.lower === 'file') {
            return stopWith(image, lineNumber, 'file');
        }
        const bodyOffset = column + head.restOffset;
        if (RESERVE_DIRECTIVES.has(head.lower)) {
            return emitReserve(image, head.lower, head.rest, lineNumber, bodyOffset) || stopWith(image, lineNumber, 'reserve');
        }
        image.unicode = head.lower === 'du';
        const ok = emitDataItems(image, DATA_DIRECTIVES.get(head.lower), splitItems(head.rest, bodyOffset), lineNumber);
        image.unicode = false;
        return ok || (image.truncated ? false : stopWith(image, lineNumber, 'data'));
    }

    if (head.lower === 'org') {
        const value = image.value(head.rest);
        if (value === null) {
            return stopWith(image, lineNumber, 'org');
        }
        image.origin = { offset: image.bytes.length, address: value };
        return true;
    }
    if (head.lower === 'format' || head.lower === 'entry' || head.lower === 'use16' || head.lower === 'use32' || head.lower === 'use64' || head.lower === 'display' || head.lower === 'public') {
        return true;
    }
    if (head.lower === 'align') {
        const value = image.value(head.rest);
        if (value === null || value <= 0n || value > 65536n) {
            return stopWith(image, lineNumber, 'align');
        }
        const padding = Number((value - (BigInt(image.bytes.length - image.origin.offset) % value)) % value);
        image.emit(new Array(padding).fill(null), { line: lineNumber, start: column, end: column + text.length });
        return true;
    }

    // Da qui: istruzioni, macro, if/repeat…: la dimensione non è calcolabile.
    return stopWith(image, lineNumber, INSTRUCTIONS.has(head.lower) ? 'code' : 'unknown');
}

function emitReserve(image, directive, argument, lineNumber, bodyOffset) {
    const size = DATA_DIRECTIVES.get(directive);
    const count = image.value(argument);
    if (count === null || count < 0n || count > BigInt(MAX_REPEAT)) {
        return false;
    }
    return image.emit(new Array(Number(count) * size).fill(null), { line: lineNumber, start: bodyOffset, end: bodyOffset + argument.length });
}

function runPass(lines, previous) {
    const image = new Image(previous);
    for (let lineNumber = 0; lineNumber < lines.length; lineNumber += 1) {
        if (!processLine(image, lines[lineNumber], lineNumber)) {
            break;
        }
    }
    return image;
}

/**
 * @param {string} sourceText
 * @returns {{bytes:(number|null)[], sources:object[], labels:Map, stop:object|null, truncated:boolean}}
 */
function buildImage(sourceText) {
    const lines = String(sourceText).split(/\r?\n/);
    const first = runPass(lines, null);
    return runPass(lines, first);
}

// ---------------------------------------------------------------------------------------------------------
// Lettura dell'header
// ---------------------------------------------------------------------------------------------------------

function reader(image) {
    const known = (offset, length) => {
        if (offset < 0 || offset + length > image.bytes.length) return false;
        for (let index = 0; index < length; index += 1) {
            if (image.bytes[offset + index] === null) return false;
        }
        return true;
    };
    const unsigned = (offset, length) => {
        if (!known(offset, length)) return null;
        let value = 0n;
        for (let index = length - 1; index >= 0; index -= 1) {
            value = (value << 8n) | BigInt(image.bytes[offset + index]);
        }
        return value;
    };
    const small = (offset, length) => {
        const value = unsigned(offset, length);
        return value === null ? null : Number(value);
    };
    const ascii = (offset, text) => {
        if (!known(offset, text.length)) return false;
        for (let index = 0; index < text.length; index += 1) {
            if (image.bytes[offset + index] !== text.charCodeAt(index)) return false;
        }
        return true;
    };
    /** Posizione nel sorgente dei byte [offset, offset+length): unione sulla stessa riga, altrimenti il primo elemento. */
    const evidence = (field, offset, length, extra = {}) => {
        const sources = [];
        for (let index = offset; index < offset + length && index < image.sources.length; index += 1) {
            if (image.sources[index]) sources.push(image.sources[index]);
        }
        if (!sources.length) return null;
        const first = sources[0];
        const sameLine = sources.filter((source) => source.line === first.line);
        return {
            field, offset, length, line: first.line,
            start: Math.min(...sameLine.map((source) => source.start)),
            end: Math.max(...sameLine.map((source) => source.end)),
            ...extra
        };
    };
    return { known, unsigned, small, ascii, evidence };
}

function detectElf(read, image) {
    if (!read.known(0, 4) || !read.ascii(0, '\x7fELF')) {
        return null;
    }
    const classByte = read.small(4, 1);
    const osabi = read.small(7, 1);
    const type = read.small(16, 2);
    const machine = read.small(18, 2);
    const bits = classByte === 1 ? 32 : classByte === 2 ? 64 : null;
    const evidence = [read.evidence('magic', 0, 4, { meaning: t('raw.field.magicElf') })];
    if (bits) {
        evidence.push(read.evidence('EI_CLASS', 4, 1, { value: classByte, meaning: `ELF${bits}` }));
    }
    if (osabi !== null) {
        evidence.push(read.evidence('EI_OSABI', 7, 1, { value: osabi, meaning: ELF_ABI_NAMES[osabi] || t('raw.field.abiUnknown', { value: osabi }) }));
    }
    const typeNames = { 1: `ET_REL (${t('raw.field.object')})`, 2: `ET_EXEC (${t('raw.field.exec')})`, 3: `ET_DYN (${t('raw.field.sharedOrExec')})`, 4: 'ET_CORE' };
    if (type !== null) {
        evidence.push(read.evidence('e_type', 16, 2, { value: type, meaning: typeNames[type] || t('raw.field.type', { value: type }) }));
    }
    const machineNames = { 3: 'x86 (i386)', 62: 'x86-64' };
    if (machine !== null) {
        evidence.push(read.evidence('e_machine', 18, 2, { value: machine, meaning: machineNames[machine] || t('raw.field.machine', { value: machine }) }));
    }

    // Segmenti speciali dichiarati nella tabella dei program header (PT_INTERP, PT_DYNAMIC).
    const phoff = bits === 64 ? read.small(32, 8) : bits === 32 ? read.small(28, 4) : null;
    const phentsize = bits === 64 ? read.small(54, 2) : bits === 32 ? read.small(42, 2) : null;
    const phnum = bits === 64 ? read.small(56, 2) : bits === 32 ? read.small(44, 2) : null;
    const segments = [];
    if (phoff !== null && phentsize && phnum !== null && phnum < 64) {
        for (let index = 0; index < phnum; index += 1) {
            const pType = read.small(phoff + index * phentsize, 4);
            if (pType !== null) segments.push(pType);
        }
    }
    const dynamic = segments.includes(3) || segments.includes(2) || (type === 3 && segments.length === 0 ? null : false);
    return {
        kind: bits === 64 ? 'elf64' : 'elf',
        bits,
        abi: osabi,
        abiName: osabi === null ? null : ELF_ABI_NAMES[osabi] || null,
        executable: type === 2 || type === 3,
        elfType: type,
        machine,
        dynamic: segments.length ? dynamic === true : null,
        evidence: evidence.filter(Boolean)
    };
}

function detectPe(read) {
    if (!read.ascii(0, 'MZ')) {
        return null;
    }
    const evidence = [read.evidence('MZ', 0, 2, { meaning: t('raw.field.magicMz') })];
    let pe = null;
    const lfanew = read.small(0x3c, 4);
    if (lfanew !== null && read.ascii(lfanew, 'PE\0\0')) {
        pe = lfanew;
        evidence.push(read.evidence('e_lfanew', 0x3c, 4, { value: lfanew, meaning: t('raw.field.lfanew', { value: `0x${lfanew.toString(16)}` }) }));
    } else if (lfanew === null || lfanew === 0) {
        for (let offset = 0x40; offset < 0x400 && pe === null; offset += 8) {
            if (read.ascii(offset, 'PE\0\0')) pe = offset;
        }
    }
    if (pe === null) {
        return {
            kind: 'mz', bits: 16, abi: null, abiName: null, executable: true, machine: null,
            evidence, peFound: false
        };
    }
    evidence.push(read.evidence('PE', pe, 4, { meaning: t('raw.field.magicPe') }));
    const machine = read.small(pe + 4, 2);
    const machineNames = { 0x14c: 'x86 (i386)', 0x8664: 'x86-64' };
    if (machine !== null) {
        evidence.push(read.evidence('Machine', pe + 4, 2, { value: machine, meaning: machineNames[machine] || t('raw.field.machine', { value: `0x${machine.toString(16)}` }) }));
    }
    const characteristics = read.small(pe + 22, 2);
    const optional = pe + 24;
    const magic = read.small(optional, 2);
    const bits = magic === 0x20b ? 64 : magic === 0x10b ? 32 : machine === 0x8664 ? 64 : machine === 0x14c ? 32 : null;
    if (magic !== null) {
        evidence.push(read.evidence('OptionalHeader.Magic', optional, 2, { value: magic, meaning: magic === 0x20b ? 'PE32+ (64 bit)' : magic === 0x10b ? 'PE32 (32 bit)' : `magic 0x${magic.toString(16)}` }));
    }
    const subsystemCode = read.small(optional + 68, 2);
    if (subsystemCode !== null) {
        evidence.push(read.evidence('Subsystem', optional + 68, 2, { value: subsystemCode, meaning: PE_SUBSYSTEMS[subsystemCode] || t('raw.field.subsystem', { value: subsystemCode }) }));
    }
    return {
        kind: bits === 64 ? 'pe64' : 'pe',
        bits,
        abi: null,
        abiName: null,
        machine,
        subsystem: subsystemCode === null ? null : PE_SUBSYSTEMS[subsystemCode] || null,
        dll: characteristics === null ? null : (characteristics & 0x2000) !== 0,
        executable: characteristics === null ? true : (characteristics & 0x2) !== 0,
        evidence: evidence.filter(Boolean),
        peFound: true
    };
}

function detectMenuet(read) {
    for (const [signature, kind] of [['MENUET01', 'menuet01'], ['MENUET02', 'menuet02'], ['MENUET64', 'menuet64']]) {
        if (read.ascii(0, signature)) {
            return {
                kind, signature, bits: kind === 'menuet64' ? 64 : 32, abi: null, abiName: null, executable: true,
                evidence: [read.evidence('signature', 0, 8, { meaning: t('raw.field.signature', { value: signature }) })].filter(Boolean)
            };
        }
    }
    return null;
}

/**
 * @returns {null|{kind:string, bits:number|null, abi:number|null, abiName:string|null, executable:boolean,
 *                 evidence:object[], image:object}}
 */
function detectRawHeader(sourceText) {
    const text = String(sourceText);
    // Corsia veloce: un header raw ha dati subito all'inizio; evita di costruire l'immagine per i sorgenti normali.
    if (!/\b(?:db|dw|dd|dq)\b/i.test(text)) {
        return null;
    }
    const image = buildImage(text);
    if (!image.bytes.length) {
        return null;
    }
    const read = reader(image);
    const found = detectElf(read, image) || detectPe(read) || detectMenuet(read);
    return found ? { ...found, image: { length: image.bytes.length, stop: image.stop, truncated: image.truncated } } : null;
}

module.exports = { buildImage, detectRawHeader, splitItems, ELF_ABI_NAMES };
