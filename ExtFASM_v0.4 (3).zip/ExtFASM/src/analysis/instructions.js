'use strict';

/**
 * Parole riconosciute da FASM 1, lette dalle tabelle del compilatore (src/data/fasm-tables.json,
 * importate da source/tables.inc con scripts/import-fasm-tables.js). Niente elenchi scritti a mano:
 * ciò che qui è "istruzione" o "direttiva" lo è anche per fasm.
 */

const tables = require('../data/fasm-tables.json');

const DIRECTIVE_HANDLER = /_directive$|^set_evex_mode$/;
const PREFIX_HANDLER = /^(?:bnd_)?prefix_instruction$/;

const mnemonics = new Set();
const prefixes = new Set();
const controlDirectives = new Set();
for (const [name, handler] of Object.entries(tables.instructions)) {
    if (PREFIX_HANDLER.test(handler)) {
        prefixes.add(name);
    } else if (DIRECTIVE_HANDLER.test(handler)) {
        controlDirectives.add(name);
    } else {
        mnemonics.add(name);
    }
}

/** Mnemonic delle istruzioni (x86, x87, MMX, SSE…, AVX, AVX-512, x86-64 e altre estensioni di FASM 1). */
const INSTRUCTIONS = mnemonics;

/** Prefissi di istruzione (rep, lock, bnd, xacquire…): precedono il vero mnemonic sulla stessa riga. */
const PREFIXES = prefixes;

/** Direttive di controllo e di formato presenti nella tabella delle istruzioni (if, repeat, format, section, org…). */
const CONTROL_DIRECTIVES = controlDirectives;

/** Direttive di definizione dati: nome -> dimensione dell'unità in byte (`db` 1, `dw` 2, `dd` 4, `dq` 8…; `rb`… riservano spazio). */
const DATA_DIRECTIVES = new Map(Object.entries(tables.dataDirectives));

/** Direttive che riservano spazio senza emettere valori (`rb`, `rw`, `rd`…). */
const RESERVE_DIRECTIVES = new Set(Object.keys(tables.dataDirectives).filter((name) => name.startsWith('r')));

/** Direttive del preprocessore e delle macro (macro, struc, match, local, forward…). */
const PREPROCESSOR_DIRECTIVES = new Set([...tables.preprocessorDirectives, ...tables.macroDirectives]);

/** Operatori testuali nelle espressioni e parole di direttiva (`dup`, `at`, `from`, `ptr`, `rva`, `shl`…). */
const WORD_OPERATORS = new Set([
    ...tables.operators, ...tables.singleOperandOperators, ...tables.directiveOperators
].filter((operator) => /^[a-z]/.test(operator)));

/** Parole fornite dalla tabella dei simboli, per tipo (register, format, sectionFlag, sizeOperator…). */
const SYMBOLS = Object.fromEntries(Object.entries(tables.symbols).map(([type, names]) => [type, new Set(names)]));

const REGISTERS = new Set([...tables.symbols.register, ...tables.symbols.specialRegister]);

/** Direttive e parole chiave che compaiono anche senza essere in una tabella (definizione di simboli). */
const SYMBOL_DEFINITION_WORDS = new Set(['equ', 'fix']);

const CONDITION_CODES = 'o no b c nae ae nb nc be na a nbe s ns e z ne nz p pe np po l nge ge nl le ng g nle'.split(' ');

module.exports = {
    INSTRUCTIONS,
    PREFIXES,
    CONTROL_DIRECTIVES,
    DATA_DIRECTIVES,
    RESERVE_DIRECTIVES,
    PREPROCESSOR_DIRECTIVES,
    WORD_OPERATORS,
    SYMBOLS,
    REGISTERS,
    SYMBOL_DEFINITION_WORDS,
    CONDITION_CODES,
    TABLES_SOURCE: tables.source
};
