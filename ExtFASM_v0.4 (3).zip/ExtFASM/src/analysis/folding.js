'use strict';

/**
 * Regioni comprimibili (code folding) di un sorgente FASM 1. Funzione pura: restituisce
 * `{start, end, kind, label}` con righe 0-based; l'estensione le trasforma in `vscode.FoldingRange`.
 *
 * Regioni riconosciute:
 *  - macro / struc / struct (blocco tra graffe), irp / irps / rept / match / postpone / rawmatch (idem);
 *  - if … end if, repeat … end repeat, while … end while, virtual … end virtual, proc … endp;
 *  - segment / section: fino alla riga prima del prossimo segment/section (o fine file);
 *  - etichette globali: fino alla riga prima della prossima etichetta globale o segment/section;
 *  - blocco di preparazione di una syscall: le istruzioni consecutive che precedono la riga `syscall`/`int`;
 *  - commenti: due o più righe intere di commento consecutive.
 * Non si interpretano macro definite dall'utente: un `end` di una macro propria non è riconosciuto.
 */

const { maskLine } = require('./symbols');

const BRACE_OPENERS = /^(macro|struc|struct|irp|irps|rept|match|rawmatch|postpone|calminstruction)\b/i;
const BLOCK_OPEN = /^(if|repeat|while|virtual|proc)\b/i;
const BLOCK_CLOSE = /^(?:end\s+(if|repeat|while|virtual)|(endp))\b/i;
const SECTION = /^(section|segment)\b/i;
const GLOBAL_LABEL = /^([A-Za-z_$?@][\w$?@]*)\s*:(?!:)/;

function foldingRanges(text, syscallLines = []) {
    const raw = String(text).split(/\r?\n/);
    const masked = raw.map(maskLine);
    const statements = masked.map((line) => {
        const trimmed = line.trim();
        // toglie un'eventuale etichetta iniziale: "start: mov eax, 1" -> "mov eax, 1"
        return trimmed.replace(/^(?:[A-Za-z_.$?@][\w.$?@]*\s*:(?!:)\s*)/, '');
    });
    const ranges = [];
    const add = (start, end, kind, label) => {
        if (end > start) {
            ranges.push({ start, end, kind: kind || 'region', label });
        }
    };

    // --- macro e blocchi a graffe -------------------------------------------------------------
    for (let i = 0; i < masked.length; i += 1) {
        if (!BRACE_OPENERS.test(statements[i])) {
            continue;
        }
        let depth = 0;
        let opened = false;
        for (let j = i; j < masked.length; j += 1) {
            for (const ch of masked[j]) {
                if (ch === '{') {
                    depth += 1;
                    opened = true;
                } else if (ch === '}') {
                    depth -= 1;
                }
            }
            if (opened && depth <= 0) {
                add(i, j, 'region', statements[i].split(/\s+/)[0].toLowerCase());
                i = j;
                break;
            }
            // un blocco che non apre mai una graffa entro 2 righe non è un blocco a graffe
            if (!opened && j - i >= 2) {
                break;
            }
        }
    }

    // --- if / repeat / while / virtual / proc -------------------------------------------------
    const stack = [];
    for (let i = 0; i < masked.length; i += 1) {
        const statement = statements[i];
        const close = BLOCK_CLOSE.exec(statement);
        if (close) {
            const name = (close[1] || 'proc').toLowerCase();
            for (let k = stack.length - 1; k >= 0; k -= 1) {
                if (stack[k].name === name) {
                    add(stack[k].line, i - 1 >= stack[k].line ? i : i, 'region', name);
                    stack.length = k;
                    break;
                }
            }
            continue;
        }
        const open = BLOCK_OPEN.exec(statement);
        if (open && !/^if\b.*\bthen\b/i.test(statement)) {
            stack.push({ name: open[1].toLowerCase(), line: i });
        }
    }

    // --- segment / section e etichette globali ---------------------------------------------
    // ultima riga non vuota fino a `upTo` (compresa)
    const lastNonBlank = (upTo) => {
        let end = Math.min(upTo, raw.length - 1);
        while (end > 0 && !masked[end].trim() && !/^\s*;/.test(raw[end])) {
            end -= 1;
        }
        return end;
    };
    const sectionLines = [];
    const labelLines = [];
    for (let i = 0; i < masked.length; i += 1) {
        if (SECTION.test(statements[i])) {
            sectionLines.push(i);
        }
        const label = GLOBAL_LABEL.exec(masked[i].trim());
        if (label && !SECTION.test(statements[i]) && masked[i].trim() === masked[i].trimStart().trim()) {
            labelLines.push(i);
        }
    }
    sectionLines.forEach((line, index) => {
        const next = sectionLines[index + 1];
        add(line, lastNonBlank(next === undefined ? raw.length - 1 : next - 1), 'region', 'section');
    });
    labelLines.forEach((line, index) => {
        const next = labelLines[index + 1] ?? Infinity;
        const nextSection = sectionLines.find((s) => s > line) ?? Infinity;
        const limit = Math.min(next, nextSection);
        const end = lastNonBlank(limit === Infinity ? raw.length - 1 : limit - 1);
        add(line, end, 'region', 'label');
    });

    // --- preparazione di una syscall ----------------------------------------------------------
    for (const line of [...new Set(syscallLines)]) {
        let start = line;
        while (start - 1 >= 0) {
            const previous = statements[start - 1];
            if (!previous || /^(section|segment|format|include|macro|struc|entry)\b/i.test(previous) || GLOBAL_LABEL.test(masked[start - 1].trim()) && !masked[start - 1].trim().replace(GLOBAL_LABEL, '').trim()) {
                break;
            }
            if (/^(syscall|sysenter|int\b)/i.test(previous)) {
                break;
            }
            start -= 1;
        }
        add(start, line, 'region', 'syscall');
    }

    // --- commenti -----------------------------------------------------------------------------
    for (let i = 0; i < raw.length; i += 1) {
        if (/^\s*;/.test(raw[i])) {
            let j = i;
            while (j + 1 < raw.length && /^\s*;/.test(raw[j + 1])) {
                j += 1;
            }
            add(i, j, 'comment', 'comment');
            i = j;
        }
    }

    // elimina i duplicati sulla stessa riga iniziale tenendo la regione più ampia
    const byStart = new Map();
    for (const range of ranges) {
        const current = byStart.get(range.start);
        if (!current || range.end > current.end) {
            byStart.set(range.start, range);
        }
    }
    return [...byStart.values()].sort((a, b) => a.start - b.start || b.end - a.end);
}

module.exports = { foldingRanges };
