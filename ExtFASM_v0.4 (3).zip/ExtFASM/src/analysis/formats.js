'use strict';

/**
 * Riconosce la direttiva `format` di FASM 1 (binary, MZ, PE, PE64, COFF, MS COFF, MS64 COFF, ELF, ELF64)
 * e ne ricava modalità di default, estensione di output, ABI ELF, sottosistema PE ed eseguibilità.
 *
 * Le estensioni di output sono quelle di default di FASM 1 e il comportamento di `as 'ext'` (qualunque
 * formato; FASM aggiunge lui il punto: `as '.KEK'` produce `nome..KEK`, `as ''` produce `nome.`) è stato
 * verificato con fasm 1.73.35 reale.
 *
 * Per `format binary` (o nessun `format`) si cerca anche un header scritto a mano con db/dw/dd/dq
 * (ELF, PE, MZ, MENUET): vedi rawheader.js. Il risultato è in `format.raw`.
 */

const { detectRawHeader } = require('./rawheader');

// Campo EI_OSABI dell'intestazione ELF. In FASM 1 è il numero dopo `executable`.
const ELF_ABI_NAMES = {
    0: 'UNIX System V',
    1: 'HP-UX',
    2: 'NetBSD',
    3: 'Linux',
    4: 'GNU Hurd',
    5: '86Open (riservato)',
    6: 'Solaris',
    7: 'AIX',
    8: 'IRIX',
    9: 'FreeBSD'
};

const PE_SUBSYSTEMS = new Set(['console', 'gui', 'native', 'efi', 'efiboot', 'efiruntime', 'wdm']);
const NON_RUNNABLE_SUBSYSTEMS = new Set(['native', 'efi', 'efiboot', 'efiruntime', 'wdm']);

function detectFormat(sourceText) {
    const text = String(sourceText);
    for (const rawLine of text.split(/\r?\n/)) {
        const code = stripComment(rawLine).trim();
        const match = /^format\s+(.*)$/i.exec(code);
        if (match) {
            return withRawHeader(withLinking(parseFormat(match[1]), text), text);
        }
    }
    return withRawHeader({
        kind: 'binary', bits: 16, executable: false, extension: '.bin', explicit: false,
        abi: null, abiName: null, subsystem: null, dll: false, linking: null,
        customExtension: null, customExtensionRaw: null, raw: null
    }, text);
}

function parseFormat(rest) {
    const custom = readQuoted(rest, 'as');
    const withoutStrings = rest.replace(/(['"]).*?\1/g, ' ');
    const words = withoutStrings.toLowerCase().split(/[\s,]+/).filter(Boolean);
    const has = (word) => words.includes(word);
    const head = words[0] || '';
    const customExtension = sanitizeExtension(custom);
    const pick = (defaultExtension) => customExtension !== null ? `.${customExtension}` : defaultExtension;

    const base = {
        explicit: true, abi: null, abiName: null, subsystem: null, dll: false, linking: null,
        customExtension, customExtensionRaw: custom, raw: null
    };

    if (head === 'elf' || head === 'elf64') {
        const executable = has('executable');
        const abi = executable ? readAbi(words) : null;
        return {
            ...base,
            kind: head,
            bits: head === 'elf64' ? 64 : 32,
            executable,
            extension: pick(executable ? '' : '.o'),
            abi,
            abiName: abi === null ? null : (ELF_ABI_NAMES[abi] || `ABI ${abi}`),
            linking: executable ? 'static' : null
        };
    }
    if (head === 'pe' || head === 'pe64') {
        const dll = has('dll');
        const subsystem = words.find((word) => PE_SUBSYSTEMS.has(word)) || 'gui';
        return {
            ...base,
            kind: head,
            bits: head === 'pe64' ? 64 : 32,
            executable: !dll && !NON_RUNNABLE_SUBSYSTEMS.has(subsystem),
            extension: pick(dll ? '.dll' : (subsystem === 'efi' || subsystem.startsWith('efi') ? '.efi' : '.exe')),
            subsystem,
            dll
        };
    }
    if (head === 'mz') {
        return { ...base, kind: 'mz', bits: 16, executable: true, extension: pick('.exe') };
    }
    if (head === 'ms' && words[1] === 'coff') {
        return { ...base, kind: 'coff', variant: 'ms', bits: 32, executable: false, extension: pick('.obj') };
    }
    if (head === 'ms64' && words[1] === 'coff') {
        return { ...base, kind: 'coff64', variant: 'ms', bits: 64, executable: false, extension: pick('.obj') };
    }
    if (head === 'coff') {
        return { ...base, kind: 'coff', variant: 'classic', bits: 32, executable: false, extension: pick('.obj') };
    }
    if (head === 'binary') {
        return { ...base, kind: 'binary', bits: 16, executable: false, extension: pick('.bin') };
    }
    return { ...base, kind: 'unknown', bits: 16, executable: false, extension: '.bin' };
}

/** Numero dopo `executable` (ABI ELF): 0–255 in FASM; se assente vale 0. */
function readAbi(words) {
    const index = words.indexOf('executable');
    const next = words[index + 1];
    if (next !== undefined && /^\d+$/.test(next)) {
        const value = Number(next);
        return value >= 0 && value <= 255 ? value : null;
    }
    return 0;
}

/** Valore tra apici dopo una parola chiave (es. `as 'KEK'`). */
function readQuoted(rest, keyword) {
    const match = new RegExp(`\\b${keyword}\\s+(['"])(.*?)\\1`, 'i').exec(rest);
    return match ? match[2] : null;
}

/**
 * Estensione personalizzata di `as '…'`, riportata come FASM la userebbe: il nome del file è
 * `<sorgente>.<testo>` (quindi `'.KEK'` dà `nome..KEK` e `''` dà `nome.`). Sono ammessi solo caratteri
 * sicuri per un nome di file; qualunque altra cosa (separatori di percorso, spazi, caratteri di
 * controllo) viene rifiutata così non può spostare il file prodotto fuori dalla cartella.
 * @returns {string|null} il testo (anche vuoto) oppure null se assente o non ammesso
 */
function sanitizeExtension(value) {
    if (value === null || value === undefined) {
        return null;
    }
    const text = String(value);
    return /^[A-Za-z0-9_.+~@#$%-]{0,32}$/.test(text) ? text : null;
}

/**
 * ELF eseguibile "dynamic": il sorgente dichiara un interprete o un segmento `dynamic`
 * (stile degli esempi Linux di FASM). È un'euristica sul testo, non un controllo del binario.
 */
function withLinking(format, sourceText) {
    if ((format.kind === 'elf' || format.kind === 'elf64') && format.executable) {
        const dynamic = /^\s*(?:segment\s+)?(?:interpreter|dynamic)\b|^\s*needed\s+['"]/im.test(
            String(sourceText).split(/\r?\n/).map(stripComment).join('\n')
        );
        return { ...format, linking: dynamic ? 'dynamic' : 'static' };
    }
    return format;
}

/**
 * Per `format binary` cerca un header ELF/PE/MZ/MENUET scritto a mano (db/dw/dd/dq).
 * Gli altri formati hanno già l'header generato da FASM.
 */
function withRawHeader(format, sourceText) {
    if (format.kind !== 'binary') {
        return format;
    }
    return { ...format, raw: detectRawHeader(sourceText) };
}

/**
 * Sistema operativo (valore di process.platform) su cui si può avviare il file prodotto, o null.
 * Un ELF si avvia da qui solo con ABI 0 (System V) o 3 (Linux): gli altri ABI usano syscall di
 * altri sistemi (es. 9 = FreeBSD) e su Linux non funzionerebbero. MZ è DOS: non si avvia nativamente.
 */
function nativePlatform(format) {
    if (!format.executable) {
        return null;
    }
    if (format.kind === 'elf' || format.kind === 'elf64') {
        return format.abi === 0 || format.abi === 3 ? 'linux' : null;
    }
    if (format.kind === 'pe' || format.kind === 'pe64') {
        return 'win32';
    }
    return null;
}

function stripComment(line) {
    let quote = null;
    for (let index = 0; index < line.length; index += 1) {
        const character = line[index];
        if (quote) {
            if (character === quote) {
                quote = null;
            }
        } else if (character === '"' || character === "'") {
            quote = character;
        } else if (character === ';') {
            return line.slice(0, index);
        }
    }
    return line;
}

module.exports = { detectFormat, nativePlatform, stripComment, ELF_ABI_NAMES };
