'use strict';

/**
 * Modello dei registri generali x86 per l'analisi del flusso lineare.
 * I valori sono BigInt a 64 bit oppure `null` (sconosciuto).
 */

const FAMILIES = {
    a: { 64: 'rax', 32: 'eax', 16: 'ax', 8: 'al', high: 'ah' },
    b: { 64: 'rbx', 32: 'ebx', 16: 'bx', 8: 'bl', high: 'bh' },
    c: { 64: 'rcx', 32: 'ecx', 16: 'cx', 8: 'cl', high: 'ch' },
    d: { 64: 'rdx', 32: 'edx', 16: 'dx', 8: 'dl', high: 'dh' },
    si: { 64: 'rsi', 32: 'esi', 16: 'si', 8: 'sil' },
    di: { 64: 'rdi', 32: 'edi', 16: 'di', 8: 'dil' },
    bp: { 64: 'rbp', 32: 'ebp', 16: 'bp', 8: 'bpl' },
    sp: { 64: 'rsp', 32: 'esp', 16: 'sp', 8: 'spl' }
};
for (let number = 8; number <= 15; number += 1) {
    FAMILIES[`r${number}`] = { 64: `r${number}`, 32: `r${number}d`, 16: `r${number}w`, 8: `r${number}b` };
}

const REGISTERS = new Map();
for (const [family, names] of Object.entries(FAMILIES)) {
    for (const width of [64, 32, 16, 8]) {
        REGISTERS.set(names[width], { family, width, shift: 0 });
    }
    if (names.high) {
        REGISTERS.set(names.high, { family, width: 8, shift: 8 });
    }
}

const ALL_FAMILIES = Object.keys(FAMILIES);
const MASKS = { 8: 0xffn, 16: 0xffffn, 32: 0xffffffffn, 64: 0xffffffffffffffffn };

function parseRegister(name) {
    return REGISTERS.get(String(name).trim().toLowerCase()) || null;
}

class RegisterState {
    constructor() {
        this.values = new Map();
        this.stack = [];
        this.reset();
    }

    reset() {
        ALL_FAMILIES.forEach((family) => this.values.set(family, null));
        this.stack = [];
    }

    clone() {
        const copy = new RegisterState();
        this.values.forEach((value, family) => copy.values.set(family, value));
        copy.stack = [...this.stack];
        return copy;
    }

    /** Valore del registro (rispettando larghezza e byte alto), o null. */
    read(register) {
        const value = this.values.get(register.family);
        if (value === null || value === undefined) {
            return null;
        }
        return (value >> BigInt(register.shift)) & MASKS[register.width];
    }

    /** Scrive il registro: le scritture a 32 bit azzerano la parte alta (in 16 bit la conservano). */
    write(register, value, mode) {
        if (value === null) {
            return this.writeUnknown(register);
        }
        const old = this.values.get(register.family);
        const masked = BigInt.asUintN(register.width, value);
        if (register.width === 64) {
            this.values.set(register.family, masked);
        } else if (register.width === 32 && mode !== 16) {
            this.values.set(register.family, masked);
        } else if (old === null || old === undefined) {
            // scrittura parziale su un valore sconosciuto: il risultato completo resta sconosciuto
            this.values.set(register.family, null);
        } else {
            const shift = BigInt(register.shift);
            const cleared = old & ~(MASKS[register.width] << shift);
            this.values.set(register.family, BigInt.asUintN(64, cleared | (masked << shift)));
        }
    }

    writeUnknown(register) {
        this.values.set(register.family, null);
    }

    clearFamilies(families) {
        families.forEach((family) => this.values.set(family, null));
    }
}

module.exports = { FAMILIES, ALL_FAMILIES, RegisterState, parseRegister, MASKS };
