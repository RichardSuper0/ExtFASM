'use strict';

/**
 * Instruction Prediction: suggerisce la riga successiva in modo deterministico (niente AI, niente statistica).
 * Ogni suggerimento ha una ragione leggibile e una confidenza qualitativa:
 *   certain    ricavato da dati di riferimento verificati (tabelle syscall, matrice dei formati misurata con fasm,
 *              specifiche dei formati) e dal codice che precede;
 *   likely     idioma convenzionale o stato dedotto solo dal blocco di codice corrente (l'analisi segue il flusso
 *              lineare: un registro preparato prima di un'etichetta non viene visto);
 *   uncertain  più scelte ugualmente sensate: le proponiamo tutte, marcate come incerte.
 * Nessuna percentuale. Se il contesto non basta, il risultato è la lista vuota.
 */

const { t } = require('../i18n/i18n');
const { analyzeSource } = require('./analyzer');
const { analyzeSyscalls } = require('../syscalls/engine');
const { OPERATING_SYSTEMS } = require('../syscalls/os');
const tables = require('../syscalls/tables');
const { parseRegister } = require('./registers');
const { buildImage } = require('./rawheader');
const { matrixKeys } = require('./formatcheck');
const matrix = require('../data/fasm-format-matrix.json');
const prototypes = require('../data/linux-prototypes.json').prototypes;

const LEVELS = { certain: 1, likely: 2, uncertain: 3 };
const LEVEL_LIMIT = { certain: 1, likely: 2, all: 3 };
const LABEL_PREFIX = /^(?:(?:[\w.$?@]+|@@)\s*:\s*)+/;
const SITE_MNEMONICS = new Set(['syscall', 'sysenter', 'int']);
const WRITES_FIRST_OPERAND = new Set(['mov', 'lea', 'xor', 'add', 'sub', 'and', 'or', 'adc', 'sbb', 'movzx', 'movsx', 'movsxd',
    'pop', 'inc', 'dec', 'neg', 'not', 'shl', 'shr', 'sar', 'rol', 'ror', 'bswap', 'xchg', 'imul', 'bsf', 'bsr', 'popcnt', 'lzcnt', 'tzcnt']);
const CONDITIONAL_SET = /^(?:cmov|set)[a-z]+$/;
const ARCH_ORDER_DIFFERS = new Set(['clone']); // l'ordine degli argomenti cambia tra architetture: i nomi del prototipo generico non valgono per i386

const conf = (name) => t(`pred.conf.${name}`);

function make(kind, label, insertText, confidence, reason, extra = {}) {
    return {
        kind, label, insertText, confidence,
        reason: `${reason}`,
        detail: t('pred.detail', { confidence: conf(confidence), kind: t(`pred.kind.${kind}`) }),
        word: label.split(/\s+/)[0].toLowerCase(),
        ...extra
    };
}

// ---------------------------------------------------------------------------------------------------------
// Contesto del blocco di codice che precede il cursore
// ---------------------------------------------------------------------------------------------------------

/** Istruzioni del blocco corrente (dal più recente indietro fino a un'etichetta/barriera o a una chiamata di sistema). */
function currentBlock(instructions, line) {
    const before = instructions.filter((item) => item.line < line);
    const block = [];
    for (let index = before.length - 1; index >= 0; index -= 1) {
        const item = before[index];
        if (SITE_MNEMONICS.has(item.mnemonic) && block.length === 0 && item.mnemonic !== 'int') {
            return { block: [item], last: item, afterSite: true };
        }
        block.unshift(item);
        if (item.barrierBefore) break;
        if (SITE_MNEMONICS.has(item.mnemonic)) {
            block.shift();
            break;
        }
    }
    return { block, last: block[block.length - 1] || null, afterSite: false };
}

const splitOperands = (text) => String(text || '').split(',').map((part) => part.trim()).filter(Boolean);

function touchedFamilies(block) {
    const families = new Set();
    for (const item of block) {
        const operands = splitOperands(item.operands);
        if (WRITES_FIRST_OPERAND.has(item.mnemonic) || CONDITIONAL_SET.test(item.mnemonic)) {
            const first = parseRegister(operands[0]);
            if (first) families.add(first.family);
            if (item.mnemonic === 'xchg') {
                const second = parseRegister(operands[1]);
                if (second) families.add(second.family);
            }
        }
        if (['mul', 'imul', 'div', 'idiv', 'cdq', 'cqo', 'cwd'].includes(item.mnemonic) && operands.length <= 1) {
            families.add('a');
            families.add('d');
        }
    }
    return families;
}

function labelsOf(lines) {
    const names = new Set();
    for (const raw of lines) {
        const match = /^\s*((?:[\w.$?@]+|@@))\s*:/.exec(raw.replace(/;.*$/, ''));
        if (match) names.add(match[1]);
    }
    return names;
}

// ---------------------------------------------------------------------------------------------------------
// Regola 1: chiamate di sistema
// ---------------------------------------------------------------------------------------------------------

function pickMechanism(target, mode) {
    const system = OPERATING_SYSTEMS[target.os];
    if (!system) return null;
    return system.mechanisms.find((item) => item.modes.includes(mode) && item.instruction === 'syscall')
        || system.mechanisms.find((item) => item.modes.includes(mode) && item.instruction === 'int') || null;
}

function normalizeEntry(entry) {
    return entry ? entry.replace(/^__(?:x64|ia32|x32)_/, '') : null;
}

function syscallRule(context, out) {
    const { sysResult, blockInfo } = context;
    if (!sysResult || blockInfo.afterSite || !blockInfo.last) return;
    const { target, state, mode } = sysResult;
    if (!['linux', 'freebsd', 'kolibrios'].includes(target.os)) return;
    const mechanism = pickMechanism(target, mode);
    if (!mechanism) return;
    const touched = touchedFamilies(blockInfo.block);
    const numberRegister = parseRegister(mechanism.number);
    if (!numberRegister || !touched.has(numberRegister.family)) return;
    const number = state.read(numberRegister);
    if (number === null) return; // numero scritto ma non calcolabile: nessuna ipotesi
    const instruction = mechanism.instruction === 'int' ? `int 0x${mechanism.vector.toString(16)}` : mechanism.instruction;
    const assumed = target.assumed ? t('pred.sys.assumed') : '';
    const os = OPERATING_SYSTEMS[target.os].label;
    const arch = mode === 64 && mechanism.instruction === 'syscall' ? t('pred.sys.arch64') : t('pred.sys.arch32');
    const downgrade = (level) => (target.assumed && level === 'certain' ? 'likely' : level);

    let found = { status: 'unknown' };
    if (target.os === 'linux') found = tables.lookupLinux(mechanism.table, Number(number));
    if (target.os === 'freebsd') found = tables.lookupFreeBsd(Number(number));
    if (target.os === 'kolibrios') found = { status: tables.lookupKolibri(Number(number)).status === 'found' ? 'found' : 'unknown', name: `function ${number}` };
    if (found.status !== 'found') return;
    const name = found.name || String(number);

    const proto = target.os === 'linux' ? prototypes[normalizeEntry(found.entry)] : null;
    if (!proto) {
        out.push(make('syscall', instruction, instruction, 'uncertain', t('pred.sys.callUnknownArity', { number: String(number), name }) + assumed));
        return;
    }
    if (!mechanism.args.every((register) => parseRegister(register))) {
        out.push(make('syscall', instruction, instruction, 'uncertain', t('pred.sys.stackArgs', { os })));
        return;
    }
    const names = proto.args.map((arg, index) => (ARCH_ORDER_DIFFERS.has(name) && mechanism.table === 'linux-i386' ? `arg${index + 1}` : (arg.name || `arg${index + 1}`)));
    const argList = names.join(', ');
    const missing = [];
    proto.args.forEach((arg, index) => {
        const register = mechanism.args[index];
        const family = parseRegister(register).family;
        if (!touched.has(family)) missing.push({ index, register, arg });
    });
    if (missing.length) {
        for (const item of missing) {
            const placeholder = names[item.index];
            out.push(make('syscall', `mov ${item.register}, ${placeholder}`, `mov ${item.register}, \${1:${placeholder}}`, downgrade('likely'), t('pred.sys.arg', {
                name, args: argList, n: item.index + 1, desc: `${item.arg.type}${item.arg.type.endsWith('*') ? '' : ' '}${placeholder}`.replace(/\* /, '*'),
                register: item.register, os, arch
            }) + assumed, { rank: item.index }));
        }
        return;
    }
    const reason = proto.args.length
        ? t('pred.sys.call', { name, count: proto.args.length, instruction, os, arch })
        : t('pred.sys.callNoArgs', { name, instruction, os, arch });
    out.push(make('syscall', instruction, instruction, downgrade('certain'), reason + assumed));
}

// ---------------------------------------------------------------------------------------------------------
// Regola 2: stack
// ---------------------------------------------------------------------------------------------------------

const STACK_POINTER = { rbp: 'rsp', ebp: 'esp', bp: 'sp' };

function stackRule(context, out) {
    const { blockInfo } = context;
    const { block, last } = blockInfo;
    if (!last || blockInfo.afterSite) return;
    const stack = [];
    let pushed = 0;
    for (const item of block) {
        const register = parseRegister(splitOperands(item.operands)[0]);
        if (item.mnemonic === 'push' && register && register.width >= 16) {
            stack.push(splitOperands(item.operands)[0].toLowerCase());
            pushed += 1;
        } else if (item.mnemonic === 'pop') {
            if (!register) return;
            const index = stack.lastIndexOf(splitOperands(item.operands)[0].toLowerCase());
            if (index !== stack.length - 1) return; // ordine diverso o pop non abbinato: nessuna ipotesi
            stack.pop();
        } else if (['pusha', 'popa', 'pushad', 'popad', 'pushf', 'popf', 'pushfd', 'popfd', 'pushfq', 'popfq', 'enter'].includes(item.mnemonic)) {
            return;
        }
    }
    const lastOperand = splitOperands(last.operands)[0] ? splitOperands(last.operands)[0].toLowerCase() : '';
    if (last.mnemonic === 'push' && STACK_POINTER[lastOperand]) {
        out.push(make('stack', `mov ${lastOperand}, ${STACK_POINTER[lastOperand]}`, `mov ${lastOperand}, ${STACK_POINTER[lastOperand]}`, 'likely',
            t('pred.stack.frame', { reg: lastOperand, sp: STACK_POINTER[lastOperand] })));
    } else if (last.mnemonic === 'pop' && stack.length) {
        const top = stack[stack.length - 1];
        out.push(make('stack', `pop ${top}`, `pop ${top}`, 'likely', t('pred.stack.pop', { reg: top })));
    } else if (last.mnemonic === 'pop' && !stack.length && pushed) {
        out.push(make('stack', 'ret', 'ret', 'likely', t('pred.stack.ret')));
    } else if (last.mnemonic === 'leave') {
        out.push(make('stack', 'ret', 'ret', 'likely', t('pred.stack.leave')));
    }
}

// ---------------------------------------------------------------------------------------------------------
// Regola 3: flag
// ---------------------------------------------------------------------------------------------------------

function flagsRule(context, out) {
    const { last } = context.blockInfo;
    if (!last) return;
    const operands = splitOperands(last.operands);
    if (last.mnemonic === 'test') {
        const same = operands.length === 2 && operands[0].toLowerCase() === operands[1].toLowerCase() && parseRegister(operands[0]);
        const jumps = same ? ['jz', 'jnz'] : ['jz', 'jnz', 'js', 'jns'];
        jumps.forEach((jump, index) => out.push(make('flags', `${jump} label`, `${jump} \${1:label}`, same ? 'likely' : 'uncertain',
            t(same ? 'pred.flags.test' : 'pred.flags.cmp', { prev: last.text }), { rank: index })));
    } else if (last.mnemonic === 'cmp') {
        ['je', 'jne', 'jl', 'jg', 'jle', 'jge', 'jb', 'ja', 'jbe', 'jae'].forEach((jump, index) => out.push(
            make('flags', `${jump} label`, `${jump} \${1:label}`, 'uncertain', t('pred.flags.cmp', { prev: last.text }), { rank: index })));
    }
}

// ---------------------------------------------------------------------------------------------------------
// Regola 4: scheletro del formato (direttive integrate)
// ---------------------------------------------------------------------------------------------------------

const FORMAT_CHOICES = ['format ELF64 executable 3', 'format ELF executable 3', 'format PE console', 'format PE64 console', 'format MZ', 'format binary', 'format ELF64', 'format ELF', 'format MS COFF', 'format MS64 COFF'];

const directiveExists = (key, directive) => {
    const probes = matrix.directives[key] && matrix.directives[key][directive];
    return Boolean(probes) && [].concat(probes).some((message) => message !== 'illegal instruction.');
};
const okFlags = (key, introducer, words) => words.filter((word) => matrix.flags[key] && matrix.flags[key][introducer] && matrix.flags[key][introducer][word] === 'ok');

function formatRule(context, out) {
    const { analysis, lines, line } = context;
    if (context.blockInfo.last || analysis.instructions.some((item) => item.line < line)) return; // il codice è già cominciato
    const before = lines.slice(0, line);
    const meaningful = before.filter((raw) => raw.replace(/;.*$/, '').trim());
    const format = analysis.format;
    const joined = before.join('\n');

    if (!format.explicit) {
        if (!meaningful.length) {
            FORMAT_CHOICES.forEach((choice, index) => out.push(make('format', choice, choice, 'uncertain', t('pred.fmt.choose'), { rank: index })));
        }
        return;
    }
    const formatLine = before.findIndex((raw) => /^\s*format\b/i.test(raw));
    const words = before[formatLine].replace(/;.*$/, '').replace(/(['"]).*?\1/g, ' ').trim().toLowerCase().split(/\s+/).slice(1);
    const keys = matrixKeys(words);
    if (!keys) return;
    const after = before.slice(formatLine + 1).map((raw) => raw.replace(/;.*$/, '').trim()).filter(Boolean);
    const has = (pattern) => after.some((raw) => pattern.test(raw));
    const entryMatch = after.map((raw) => /^entry\s+([\w.$?@:]+)/i.exec(raw)).find(Boolean);
    const defined = labelsOf(before);
    const lastLine = after[after.length - 1] || '';
    const k = keys.directives;
    const push = (label, insert, level, reasonKey, params, rank) => out.push(make('format', label, insert, level, t(reasonKey, { format: k, ...params }), { rank }));

    const isElfExe = /^ELF(?:64)? executable$/.test(k);
    const isPe = k === 'PE' || k === 'PE64';
    if (isElfExe || isPe) {
        if (!has(/^entry\b/i) && directiveExists(k, 'entry')) {
            push('entry start', 'entry ${1:start}', 'likely', 'pred.fmt.entry', {}, 0);
        }
        if (isElfExe && !has(/^segment\b/i) && directiveExists(k, 'segment')) {
            push('segment readable executable', 'segment readable executable', 'certain', 'pred.fmt.segmentElf', {}, 1);
        }
        if (isPe && !has(/^section\b/i)) {
            const flags = okFlags(k, 'section', ['code', 'readable', 'executable']);
            push(`section '.text' ${flags.join(' ')}`, `section '.text' ${flags.join(' ')}`, 'certain', 'pred.fmt.section', {}, 1);
        }
        if (entryMatch && !defined.has(entryMatch[1]) && /^(?:segment|section)\b/i.test(lastLine)) {
            out.push(make('format', `${entryMatch[1]}:`, `${entryMatch[1]}:`, 'certain', t('pred.fmt.label', { name: entryMatch[1] }), { rank: 0 }));
        }
    } else if (k === 'MZ') {
        const segment = after.map((raw) => /^segment\s+([\w.$?@]+)/i.exec(raw)).find(Boolean);
        if (!segment) {
            out.push(make('format', 'segment main', 'segment ${1:main}', 'likely', t('pred.fmt.segmentMz'), { rank: 0 }));
        } else if (!has(/^entry\b/i)) {
            out.push(make('format', `entry ${segment[1]}:start`, `entry ${segment[1]}:\${1:start}`, 'likely', t('pred.fmt.segmentMz'), { rank: 0 }));
        } else if (entryMatch && /:/.test(entryMatch[1]) && !defined.has(entryMatch[1].split(':')[1]) && /^segment\b/i.test(lastLine)) {
            const name = entryMatch[1].split(':')[1];
            out.push(make('format', `${name}:`, `${name}:`, 'certain', t('pred.fmt.label', { name: entryMatch[1] }), { rank: 0 }));
        }
    } else if (['ELF', 'ELF64', 'COFF', 'MS COFF', 'MS64 COFF'].includes(k) && !has(/^section\b/i)) {
        const flags = okFlags(k, 'section', k.includes('COFF') ? ['code'] : ['executable']);
        if (flags.length) push(`section '.text' ${flags.join(' ')}`, `section '.text' ${flags.join(' ')}`, 'likely', 'pred.fmt.section', {}, 0);
    }
    void joined;
}

// ---------------------------------------------------------------------------------------------------------
// Regola 5: header scritti a mano (db/dw/dd/dq)
// ---------------------------------------------------------------------------------------------------------

const hexValue = (value) => `0x${value.toString(16)}`;

function elfFields(bits) {
    const wide = bits === 64;
    const word = wide ? 'dq' : 'dd';
    const size = wide ? 8 : 4;
    const fields = [
        { off: 0, size: 4, name: 'EI_MAG', code: "db 0x7f, 'ELF'", level: 'certain', note: 'fixed' },
        { off: 4, size: 1, name: 'EI_CLASS', code: ['db 2', 'db 1'], level: 'uncertain', note: 'pick' },
        { off: 5, size: 1, name: 'EI_DATA', code: 'db 1', level: 'certain', note: 'fixed' },
        { off: 6, size: 1, name: 'EI_VERSION', code: 'db 1', level: 'certain', note: 'fixed' },
        { off: 7, size: 1, name: 'EI_OSABI', code: ['db 3', 'db 0'], level: 'uncertain', note: 'pick' },
        { off: 8, size: 1, name: 'EI_ABIVERSION', code: 'db 0', level: 'likely', note: 'convention' },
        { off: 9, size: 7, name: 'EI_PAD', code: 'db 7 dup 0', level: 'certain', note: 'fixed' },
        { off: 16, size: 2, name: 'e_type', code: ['dw 2', 'dw 3'], level: 'uncertain', note: 'pick' },
        { off: 18, size: 2, name: 'e_machine', code: wide ? 'dw 62' : 'dw 3', level: 'certain', note: 'class' },
        { off: 20, size: 4, name: 'e_version', code: 'dd 1', level: 'certain', note: 'fixed' }
    ];
    let off = 24;
    const add = (name, fieldSize, code, level, note) => {
        fields.push({ off, size: fieldSize, name, code, level, note });
        off += fieldSize;
    };
    add('e_entry', size, `${word} \${1:start}`, 'likely', 'yours');
    add('e_phoff', size, `${word} ${wide ? 64 : 52}`, 'likely', 'convention');
    add('e_shoff', size, `${word} 0`, 'likely', 'convention');
    add('e_flags', 4, 'dd 0', 'certain', 'fixed');
    add('e_ehsize', 2, `dw ${wide ? 64 : 52}`, 'certain', 'fixed');
    add('e_phentsize', 2, `dw ${wide ? 56 : 32}`, 'certain', 'fixed');
    add('e_phnum', 2, 'dw 1', 'likely', 'convention');
    add('e_shentsize', 2, `dw ${wide ? 64 : 40}`, 'likely', 'convention');
    add('e_shnum', 2, 'dw 0', 'likely', 'convention');
    add('e_shstrndx', 2, 'dw 0', 'likely', 'convention');
    if (wide) {
        add('p_type', 4, 'dd 1', 'likely', 'convention');
        add('p_flags', 4, ['dd 5', 'dd 7'], 'uncertain', 'pick');
        add('p_offset', 8, 'dq 0', 'likely', 'convention');
        add('p_vaddr', 8, 'dq ${1:load_address}', 'likely', 'yours');
        add('p_paddr', 8, 'dq ${1:load_address}', 'likely', 'yours');
        add('p_filesz', 8, 'dq ${1:file_size}', 'likely', 'yours');
        add('p_memsz', 8, 'dq ${1:memory_size}', 'likely', 'yours');
        add('p_align', 8, 'dq 0x1000', 'likely', 'convention');
    } else {
        add('p_type', 4, 'dd 1', 'likely', 'convention');
        add('p_offset', 4, 'dd 0', 'likely', 'convention');
        add('p_vaddr', 4, 'dd ${1:load_address}', 'likely', 'yours');
        add('p_paddr', 4, 'dd ${1:load_address}', 'likely', 'yours');
        add('p_filesz', 4, 'dd ${1:file_size}', 'likely', 'yours');
        add('p_memsz', 4, 'dd ${1:memory_size}', 'likely', 'yours');
        add('p_flags', 4, ['dd 5', 'dd 7'], 'uncertain', 'pick');
        add('p_align', 4, 'dd 0x1000', 'likely', 'convention');
    }
    return fields;
}

const DOS_FIELDS = [
    [0x00, 2, 'e_magic'], [0x02, 2, 'e_cblp'], [0x04, 2, 'e_cp'], [0x06, 2, 'e_crlc'], [0x08, 2, 'e_cparhdr'], [0x0a, 2, 'e_minalloc'],
    [0x0c, 2, 'e_maxalloc'], [0x0e, 2, 'e_ss'], [0x10, 2, 'e_sp'], [0x12, 2, 'e_csum'], [0x14, 2, 'e_ip'], [0x16, 2, 'e_cs'],
    [0x18, 2, 'e_lfarlc'], [0x1a, 2, 'e_ovno'], [0x1c, 8, 'e_res'], [0x24, 2, 'e_oemid'], [0x26, 2, 'e_oeminfo'], [0x28, 20, 'e_res2'],
    [0x3c, 4, 'e_lfanew']
];

function mzFields() {
    return DOS_FIELDS.map(([off, size, name]) => {
        if (name === 'e_magic') return { off, size, name, code: "db 'MZ'", level: 'certain', note: 'fixed' };
        if (name === 'e_res') return { off, size, name, code: 'dw 4 dup 0', level: 'certain', note: 'fixed' };
        if (name === 'e_res2') return { off, size, name, code: 'dw 10 dup 0', level: 'certain', note: 'fixed' };
        if (name === 'e_lfanew') return { off, size, name, code: 'dd ${1:pe_header}', level: 'likely', note: 'yours' };
        if (name === 'e_oemid' || name === 'e_oeminfo' || name === 'e_ovno' || name === 'e_csum') return { off, size, name, code: 'dw 0', level: 'likely', note: 'convention' };
        return { off, size, name, code: 'dw ${1:value}', level: 'uncertain', note: 'yours' };
    });
}

function peFields(base, machine) {
    const is64 = machine === 0x8664;
    const fields = [
        { off: base, size: 4, name: 'Signature', code: "db 'PE', 0, 0", level: 'certain', note: 'fixed' },
        { off: base + 4, size: 2, name: 'Machine', code: machine === null ? ['dw 0x14c', 'dw 0x8664'] : `dw ${hexValue(machine)}`, level: machine === null ? 'uncertain' : 'certain', note: machine === null ? 'pick' : 'fixed' },
        { off: base + 6, size: 2, name: 'NumberOfSections', code: 'dw ${1:count}', level: 'likely', note: 'yours' },
        { off: base + 8, size: 4, name: 'TimeDateStamp', code: 'dd 0', level: 'likely', note: 'convention' },
        { off: base + 12, size: 4, name: 'PointerToSymbolTable', code: 'dd 0', level: 'likely', note: 'convention' },
        { off: base + 16, size: 4, name: 'NumberOfSymbols', code: 'dd 0', level: 'likely', note: 'convention' }
    ];
    if (machine !== null) {
        fields.push({ off: base + 20, size: 2, name: 'SizeOfOptionalHeader', code: `dw ${is64 ? 0xf0 : 0xe0}`, level: 'certain', note: 'class' });
    } else {
        fields.push({ off: base + 20, size: 2, name: 'SizeOfOptionalHeader', code: ['dw 0xe0', 'dw 0xf0'], level: 'uncertain', note: 'pick' });
    }
    fields.push({ off: base + 22, size: 2, name: 'Characteristics', code: 'dw ${1:flags}', level: 'uncertain', note: 'yours' });
    fields.push({ off: base + 24, size: 2, name: 'OptionalHeader.Magic', code: machine === null ? ['dw 0x10b', 'dw 0x20b'] : `dw ${is64 ? '0x20b' : '0x10b'}`, level: machine === null ? 'uncertain' : 'certain', note: machine === null ? 'pick' : 'class' });
    return fields;
}

const MENUET01_FIELDS = [
    { off: 0, size: 8, name: 'id', code: "db 'MENUET01'", level: 'certain', note: 'fixed' },
    { off: 8, size: 4, name: 'header version', code: 'dd 1', level: 'likely', note: 'convention' },
    { off: 12, size: 4, name: 'start', code: 'dd ${1:start}', level: 'likely', note: 'yours' },
    { off: 16, size: 4, name: 'i_end', code: 'dd ${1:i_end}', level: 'likely', note: 'yours' },
    { off: 20, size: 4, name: 'memory', code: 'dd ${1:memory}', level: 'likely', note: 'yours' },
    { off: 24, size: 4, name: 'stack top', code: 'dd ${1:stack_top}', level: 'likely', note: 'yours' },
    { off: 28, size: 4, name: 'parameters', code: 'dd 0', level: 'likely', note: 'convention' },
    { off: 32, size: 4, name: 'icon', code: 'dd 0', level: 'likely', note: 'convention' }
];

function rawRule(context, out) {
    const { analysis, lines, line } = context;
    const before = lines.slice(0, line).join('\n');
    const image = buildImage(before);
    const count = image.bytes.length;
    if (analysis.format.explicit && analysis.format.kind !== 'binary') return;
    if (image.stop || count === 0) {
        if (count === 0 && !analysis.format.explicit && !lines.slice(0, line).some((raw) => raw.replace(/;.*$/, '').trim())) {
            const starters = [
                ["db 0x7f, 'ELF'", 'ELF'], ["db 'MZ'", 'PE/MZ'], ["db 'MENUET01'", 'MENUET01']
            ];
            starters.forEach(([code, kind], index) => out.push(make('raw', code, code, 'uncertain', t('pred.raw.start', { kind }), { rank: 20 + index })));
        }
        return;
    }
    const byteAt = (offset, size) => {
        let value = 0;
        for (let index = size - 1; index >= 0; index -= 1) {
            const byte = image.bytes[offset + index];
            if (byte === null || byte === undefined) return null;
            value = value * 256 + byte;
        }
        return value;
    };
    const ascii = (text) => [...text].every((character, index) => image.bytes[index] === character.charCodeAt(0));

    let kind = null;
    let fields = null;
    if (ascii('\x7fELF') && image.bytes.length >= 4) {
        const classByte = count > 4 ? byteAt(4, 1) : null;
        const bits = classByte === 2 ? 64 : classByte === 1 ? 32 : null;
        kind = bits ? `ELF${bits}` : 'ELF';
        fields = elfFields(bits || 64);
        if (!bits) fields = fields.filter((field) => field.off <= 4);
        if (bits === 32 || bits === 64) context.rawClass = classByte;
    } else if (ascii('MZ') && count >= 2) {
        kind = 'MZ/PE';
        const lfanew = count >= 0x40 ? byteAt(0x3c, 4) : null;
        fields = mzFields();
        if (lfanew !== null && lfanew >= 0x40) {
            fields = fields.concat(peFields(lfanew, count > lfanew + 4 ? byteAt(lfanew + 4, 2) : null));
        }
    } else if (ascii('MENUET01')) {
        kind = 'MENUET01';
        fields = MENUET01_FIELDS;
    }
    if (!fields) return;
    const field = fields.find((item) => item.off === count);
    if (!field) return;
    const codes = [].concat(field.code);
    const classNote = context.rawClass ? t('pred.raw.note.class', { value: context.rawClass }) : '';
    const note = field.note === 'class' ? classNote : t(`pred.raw.note.${field.note === 'class' ? 'fixed' : field.note}`);
    const reason = t('pred.raw.field', { kind, field: field.name, offset: field.off, size: field.size }) + (field.note === 'class' ? classNote || t('pred.raw.note.fixed') : note);
    codes.forEach((code, index) => out.push(make('raw', `${code.replace(/\$\{\d:([^}]*)\}/g, '$1')} ; ${field.name}`, `${code} ; ${field.name}`, codes.length > 1 ? 'uncertain' : field.level, reason, { rank: index })));
}

// ---------------------------------------------------------------------------------------------------------
// Ingresso
// ---------------------------------------------------------------------------------------------------------

/**
 * @param {string} sourceText
 * @param {{line:number, character:number}} position cursore (riga 0-based)
 * @param {{os?: string, windowsVersion?: string, level?: 'certain'|'likely'|'all'}} [options]
 * @returns {{suggestions: object[]}} ordinati per confidenza e poi per regola; mai percentuali.
 */
function predict(sourceText, position, options = {}) {
    const lines = String(sourceText).split(/\r?\n/);
    const line = Math.min(Math.max(position.line, 0), lines.length);
    const current = (lines[line] || '').slice(0, position.character);
    const typed = current.replace(/;.*$/, '').replace(LABEL_PREFIX, '').trim().toLowerCase();
    if (/\s/.test(typed)) return { suggestions: [] }; // si stanno scrivendo gli operandi, non la riga
    if (/;/.test(current)) return { suggestions: [] };

    const before = lines.slice(0, line).join('\n');
    // Dentro il corpo di una macro le istruzioni sono modelli: nessuna ipotesi.
    const masked = before.split(/\r?\n/).map((raw) => raw.replace(/;.*$/, '').replace(/'[^']*'|"[^"]*"/g, '')).join('\n');
    if ((masked.match(/\{/g) || []).length > (masked.match(/\}/g) || []).length) return { suggestions: [] };

    const analysis = analyzeSource(before);
    const blockInfo = currentBlock(analysis.instructions, line);
    let sysResult = null;
    try {
        sysResult = analyzeSyscalls(before, { os: options.os || 'auto', windowsVersion: options.windowsVersion || '', format: analysis.format });
    } catch {
        sysResult = null;
    }
    const context = { analysis, lines, line, blockInfo, sysResult };
    const found = [];
    for (const rule of [syscallRule, stackRule, flagsRule, formatRule, rawRule]) {
        rule(context, found);
    }

    const limit = LEVEL_LIMIT[options.level || 'likely'] || 2;
    const seen = new Set();
    const suggestions = found
        .filter((item) => LEVELS[item.confidence] <= limit)
        .filter((item) => !typed || item.label.toLowerCase().startsWith(typed))
        .filter((item) => {
            if (seen.has(item.label)) return false;
            seen.add(item.label);
            return true;
        })
        .sort((a, b) => LEVELS[a.confidence] - LEVELS[b.confidence] || (a.rank || 0) - (b.rank || 0));
    return { suggestions };
}

module.exports = { predict };
