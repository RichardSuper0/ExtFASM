'use strict';

/**
 * Controlli sulle direttive di formato di FASM 1 (section, segment, entry, stack, heap, data, extrn,
 * public, `format …` e le sue opzioni) e sulla coerenza tra header scritto a mano e codice.
 *
 * Regola: si segnala solo ciò che un fasm 1.73.35 reale ha rifiutato nella misurazione
 * (scripts/probe-fasm-formats.js -> src/data/fasm-format-matrix.json). Niente regole dedotte dal manuale.
 * Per non dare falsi errori:
 *  - si guardano solo le istruzioni al livello più esterno (non dentro macro, if/match/while/repeat/virtual);
 *  - una parola ridefinita dall'utente con `macro`/`struc`/`equ`/`fix` non viene controllata;
 *  - se il sorgente ha `include` (che può definire macro o il formato) l'errore diventa avviso, e senza
 *    `format` esplicito la disponibilità delle direttive non viene controllata affatto.
 */

const { t } = require('../i18n/i18n');
const { INSTRUCTIONS, PREFIXES, DATA_DIRECTIVES } = require('./instructions');
const matrix = require('../data/fasm-format-matrix.json');

const CHECKED_DIRECTIVES = new Set(['section', 'segment', 'entry', 'stack', 'heap', 'data', 'extrn', 'public']);
const LABEL_PREFIX = /^(?:(?:[\w.$?@]+|@@)\s*:\s*)+/;
const WORD = /^[A-Za-z_.$?@][\w.$?@]*/;
const BLOCK_START = /^(?:if|match|while|repeat|virtual)\b/i;
const BLOCK_END = /^end\s+(?:if|match|while|repeat|virtual)\b/i;
const BRACE_START = /^(?:macro|struc|postpone|rept|irp|irps|calminstruction)\b/i;
const DIRECTIVE_ABSENT = 'illegal instruction.';

// Misurato con fasm 1.73.35: un secondo `format` o un `format` dopo istruzioni/dati dà questo errore.
const NOT_FIRST_MESSAGE = (matrix.beforeFormat && matrix.beforeFormat.nop) || 'unexpected instruction.';

const RAW_NAMES = { elf: 'ELF32', elf64: 'ELF64', pe: 'PE32', pe64: 'PE32+', menuet01: 'MENUET01', menuet02: 'MENUET02', menuet64: 'MENUET64' };

const maskStrings = (code) => code.replace(/'[^']*'|"[^"]*"/g, (match) => ' '.repeat(match.length));
const plain = (message) => String(message).replace(/\.$/, '');

function diagnostic(line, start, end, severity, code, message) {
    return { line, start, end, severity, code, message };
}

/** Chiave della matrice per le direttive e i flag, dalle parole di `format`. */
function matrixKeys(words) {
    const [head, second] = words;
    switch (head) {
        case 'binary': return { directives: 'binary', words: 'binary', head: 'binary' };
        case 'mz': return { directives: 'MZ', words: 'MZ', head: 'MZ' };
        case 'pe': return { directives: 'PE', words: 'PE', head: 'PE' };
        case 'pe64': return { directives: 'PE64', words: 'PE64', head: 'PE64' };
        case 'coff': return { directives: 'COFF', words: 'COFF', head: 'COFF' };
        case 'ms': return second === 'coff' ? { directives: 'MS COFF', words: 'MS COFF', head: 'MS COFF' } : null;
        case 'ms64': return second === 'coff' ? { directives: 'MS64 COFF', words: 'MS64 COFF', head: 'MS64 COFF' } : null;
        case 'elf':
        case 'elf64': {
            const name = head === 'elf' ? 'ELF' : 'ELF64';
            const executable = words.includes('executable');
            const dynamic = words.includes('dynamic');
            if (executable || dynamic) {
                return { directives: `${name} executable`, words: dynamic ? `${name} dynamic` : `${name} executable`, head: `${name} ${dynamic ? 'dynamic' : 'executable'}` };
            }
            return { directives: name, words: name, head: name };
        }
        default: return null;
    }
}

const results = (value) => (Array.isArray(value) ? value : [value]);

/** Una direttiva è assente se tutte le prove misurate sono «illegal instruction». */
function directiveAbsent(key, directive) {
    const probes = matrix.directives[key] && matrix.directives[key][directive];
    return Boolean(probes) && results(probes).every((message) => message === DIRECTIVE_ABSENT);
}

function formatsWhereDirectiveExists(directive) {
    return Object.keys(matrix.directives).filter((key) => {
        const probes = matrix.directives[key][directive];
        return probes && results(probes).some((message) => message !== DIRECTIVE_ABSENT);
    });
}

function parseNumber(text) {
    if (/^\d+$/.test(text)) return Number(text);
    if (/^0x[0-9a-f]+$/i.test(text)) return parseInt(text.slice(2), 16);
    if (/^\$[0-9a-f]+$/i.test(text)) return parseInt(text.slice(1), 16);
    if (/^[0-9][0-9a-f]*h$/i.test(text)) return parseInt(text.slice(0, -1), 16);
    return null;
}

/**
 * @param {string[]} codes righe di codice senza commenti (stesso indice delle righe del sorgente)
 * @param {object} format risultato di detectFormat
 * @param {object[]} instructions istruzioni riconosciute dall'analizzatore (con `mode` e `line`)
 * @returns {object[]} diagnostiche { line, start, end, severity, code, message }
 */
function checkFormat(codes, format, instructions = []) {
    const diagnostics = [];
    const userWords = new Set();
    let hasInclude = false;
    for (const code of codes) {
        const trimmed = (code || '').trim();
        const definition = /^(?:macro|struc)\s+([A-Za-z_.$?@][\w.$?@]*)/i.exec(trimmed) || /^([A-Za-z_.$?@][\w.$?@]*)\s+(?:equ|fix)\b/i.exec(trimmed);
        if (definition) userWords.add(definition[1].toLowerCase());
        if (/^include\b/i.test(trimmed.replace(LABEL_PREFIX, ''))) hasInclude = true;
    }

    let brace = 0;
    let block = 0;
    let pending = false;
    let firstFormat = null;
    let emittedBeforeFormat = false;
    let activeKeys = matrixKeys(['binary']);
    let formatSeen = false;
    const severity = hasInclude ? 'warning' : 'error';

    for (let index = 0; index < codes.length; index += 1) {
        const code = codes[index] || '';
        const trimmed = code.trim();
        if (!trimmed) continue;
        const leading = code.length - code.trimStart().length;
        const body = trimmed.replace(LABEL_PREFIX, '');
        const bodyColumn = leading + (trimmed.length - body.length);
        const masked = maskStrings(body);
        const top = brace === 0 && block === 0 && !pending;

        if (top && body) {
            const first = WORD.exec(body);
            const word = first ? first[0].toLowerCase() : '';
            const afterWord = body.slice(word.length).trim();
            const second = (WORD.exec(afterWord) || [''])[0].toLowerCase();
            const isLabelLike = DATA_DIRECTIVES.has(second) || /^(?:equ|fix|=|:)/i.test(afterWord) || second === 'equ' || second === 'fix' || second === 'struc';
            const shadowed = userWords.has(word);

            if (word === 'format' && !shadowed) {
                const rest = masked.slice(word.length);
                const words = rest.toLowerCase().split(/[\s,]+/).filter(Boolean);
                if (formatSeen || emittedBeforeFormat) {
                    diagnostics.push(diagnostic(index, bodyColumn, bodyColumn + body.length, severity, 'FASM_FORMAT_NOT_FIRST',
                        t('fmt.formatNotFirst', { fasm: plain(NOT_FIRST_MESSAGE) })));
                } else {
                    firstFormat = index;
                    const keys = matrixKeys(words);
                    if (keys) {
                        activeKeys = keys;
                        checkFormatWords(words, keys, index, bodyColumn, body, diagnostics);
                    } else {
                        activeKeys = null;
                    }
                    checkExtension(format, body, index, bodyColumn, diagnostics);
                }
                formatSeen = true;
            } else if (!shadowed && !formatSeen && word) {
                if (INSTRUCTIONS.has(word) || PREFIXES.has(word) || DATA_DIRECTIVES.has(word) || word === 'times' || word === 'file' || (DATA_DIRECTIVES.has(second) && !shadowed)) {
                    emittedBeforeFormat = true;
                }
            }

            // Senza `format` in questo file potrebbe essere un frammento incluso da altrove: non si controlla nulla.
            if (!shadowed && CHECKED_DIRECTIVES.has(word) && !isLabelLike && formatSeen && activeKeys && word !== 'format') {
                checkDirective(word, afterWord, body, activeKeys, index, bodyColumn, severity, hasInclude, diagnostics);
            }
        }

        // Stato dei blocchi: macro/struc a graffe e blocchi if/repeat/…
        const opens = (masked.match(/\{/g) || []).length;
        const closes = (masked.match(/\}/g) || []).length;
        if (brace === 0 && !pending) {
            if (BRACE_START.test(body) && opens === 0) {
                pending = true;
            } else if (opens === 0 && BLOCK_START.test(body)) {
                block += 1;
            } else if (BLOCK_END.test(body)) {
                block = Math.max(0, block - 1);
            }
        }
        if (opens > 0) pending = false;
        brace = Math.max(0, brace + opens - closes);
    }

    void firstFormat;
    checkRawMode(format, instructions, diagnostics);
    return diagnostics;
}

function checkDirective(word, afterWord, body, keys, line, column, severity, hasInclude, diagnostics) {
    if (directiveAbsent(keys.directives, word)) {
        const formats = formatsWhereDirectiveExists(word);
        diagnostics.push(diagnostic(line, column, column + word.length, severity, 'FASM_DIRECTIVE_UNAVAILABLE', t('fmt.directiveAbsent', {
            directive: word,
            format: keys.directives,
            fasm: plain(DIRECTIVE_ABSENT),
            where: formats.length ? t('fmt.availableIn', { formats: formats.join(', ') }) : '',
            note: hasInclude ? t('fmt.includeNote') : ''
        })));
        return;
    }
    // Flag dopo `section` (tutti i formati con section) e dopo `segment` degli ELF eseguibili.
    // Per MZ `segment` ha un nome di etichetta al primo posto: i flag misurati lì non si applicano.
    const flagTable = matrix.flags[keys.directives] && matrix.flags[keys.directives][word];
    const flagsApply = word === 'section' || (word === 'segment' && /^ELF(?:64)? executable$/.test(keys.directives));
    if (!flagTable || !flagsApply) return;

    const after = maskStrings(afterWord);
    const offset = column + word.length + (body.slice(word.length).length - body.slice(word.length).trimStart().length);
    const tokenPattern = /[^\s,]+/g;
    let token;
    let previous = null;
    while ((token = tokenPattern.exec(after)) !== null) {
        const text = token[0].toLowerCase();
        const start = offset + token.index;
        const end = start + text.length;
        if (text === 'align') {
            const value = /[^\s,]+/.exec(after.slice(token.index + token[0].length));
            const number = value ? parseNumber(value[0]) : null;
            const accepted = flagTable['align 16'];
            if (accepted && accepted !== 'ok') {
                diagnostics.push(diagnostic(line, start, end, severity, 'FASM_FLAG_REJECTED', t('fmt.flagRejected', {
                    word: 'align', directive: word, format: keys.directives, fasm: plain(accepted)
                })));
            } else if (number !== null && (number <= 0 || (number & (number - 1)) !== 0) && flagTable['align 3'] === 'invalid value.') {
                diagnostics.push(diagnostic(line, start, end + 1 + (value ? value[0].length : 0), severity, 'FASM_FLAG_ALIGN', t('fmt.alignValue', { value: value[0] })));
            }
            tokenPattern.lastIndex += value ? value[0].length + 1 : 0;
            previous = text;
            continue;
        }
        if (/^[a-z]/.test(text) && Object.prototype.hasOwnProperty.call(flagTable, text) && flagTable[text] !== 'ok' && previous !== 'from' && previous !== 'at') {
            diagnostics.push(diagnostic(line, start, end, severity, 'FASM_FLAG_REJECTED', t('fmt.flagRejected', {
                word: text, directive: word, format: keys.directives, fasm: plain(flagTable[text])
            })));
        }
        previous = text;
    }
}

function checkFormatWords(words, keys, line, column, body, diagnostics) {
    const table = matrix.formatWords[keys.head];
    if (!table) return;
    const headLength = words[0] === 'ms' || words[0] === 'ms64' ? 2 : 1;
    const headWords = new Set(['executable', 'dynamic']);
    const rest = words.slice(headLength);
    const tokenPattern = /[A-Za-z][\w.]*/g;
    const masked = maskStrings(body);
    let token;
    let index = 0;
    let seen = 0;
    const options = [];
    while ((token = tokenPattern.exec(masked)) !== null) {
        index += 1;
        const text = token[0].toLowerCase();
        if (index <= 1 + headLength || headWords.has(text)) continue; // `format`, la testa e le parole che la definiscono
        seen += 1;
        if (!Object.prototype.hasOwnProperty.call(table, text)) {
            options.push({ text, start: column + token.index, end: column + token.index + text.length, known: false });
            continue;
        }
        options.push({ text, start: column + token.index, end: column + token.index + text.length, known: true });
        if (table[text] !== 'ok') {
            diagnostics.push(diagnostic(line, column + token.index, column + token.index + text.length, 'error', 'FASM_FORMAT_WORD', t('fmt.formatWord', {
                word: text, head: keys.head, fasm: plain(table[text])
            })));
        }
    }
    void rest; void seen;

    // Coppie misurate di opzioni PE incompatibili (es. `console gui`), solo se adiacenti.
    const pairs = matrix.formatPairs[keys.head];
    if (!pairs) return;
    for (let i = 1; i < options.length; i += 1) {
        const first = options[i - 1];
        const second = options[i];
        const verdict = pairs[`${first.text} ${second.text}`];
        if (first.known && second.known && verdict) {
            diagnostics.push(diagnostic(line, second.start, second.end, 'error', 'FASM_FORMAT_CONFLICT', t('fmt.formatConflict', {
                first: first.text, second: second.text, head: keys.head, fasm: plain(verdict)
            })));
        }
    }
}

function checkExtension(format, body, line, column, diagnostics) {
    const raw = format.customExtensionRaw;
    if (raw === null || raw === undefined) return;
    const match = /\bas\s+(['"])(.*?)\1/i.exec(body);
    const start = match ? column + match.index + match[0].indexOf(match[1]) : column;
    const end = match ? start + match[2].length + 2 : column + body.length;
    if (format.customExtension === null) {
        diagnostics.push(diagnostic(line, start, end, 'information', 'FASM_EXTENSION_UNSAFE', t('fmt.extensionUnsafe', {
            ext: raw, fallback: `<name>${format.extension || ''}`
        })));
    } else if (raw.startsWith('.')) {
        diagnostics.push(diagnostic(line, start, end, 'information', 'FASM_EXTENSION_DOT', t('fmt.extensionDot', {
            ext: raw, clean: raw.replace(/^\.+/, '')
        })));
    }
}

/** Header scritto a mano che dichiara una larghezza che il codice non usa mai. */
function checkRawMode(format, instructions, diagnostics) {
    const raw = format.raw;
    if (!raw || !raw.bits || !instructions.length) return;
    if (instructions.some((instruction) => instruction.mode === raw.bits)) return;
    const first = instructions[0];
    diagnostics.push(diagnostic(first.line, first.column, first.endColumn, 'warning', 'FASM_RAW_MODE', t('raw.modeMismatch', {
        what: RAW_NAMES[raw.kind] || raw.kind, mode: first.mode, bits: raw.bits
    })));
}

module.exports = { checkFormat, matrixKeys };
