'use strict';

const { t } = require('../i18n/i18n');
const { INSTRUCTIONS, PREFIXES } = require('./instructions');
const { detectFormat } = require('./formats');
const { evaluate } = require('../syscalls/expr');
const { checkFormat } = require('./formatcheck');

const REGISTER_WIDTH = new Map([
    ...'al ah bl bh cl ch dl dh'.split(' ').map((name) => [name, 8]),
    ...'ax bx cx dx si di bp sp'.split(' ').map((name) => [name, 16]),
    ...'eax ebx ecx edx esi edi ebp esp'.split(' ').map((name) => [name, 32]),
    ...'rax rbx rcx rdx rsi rdi rbp rsp'.split(' ').map((name) => [name, 64]),
    ...Array.from({ length: 8 }, (_, index) => [`r${index + 8}`, 64]),
    ...Array.from({ length: 8 }, (_, index) => [`r${index + 8}d`, 32]),
    ...Array.from({ length: 8 }, (_, index) => [`r${index + 8}w`, 16]),
    ...Array.from({ length: 8 }, (_, index) => [`r${index + 8}b`, 8])
]);

// Istruzioni di lunghezza fissa indipendente dagli operandi e dalla modalità.
const FIXED_SIZE = new Map([
    ...'clc cld cli cmc hlt lahf leave nop sahf stc std sti ret'.split(' ').map((name) => [name, 1]),
    ...'syscall cpuid rdtsc ud2 sysenter sysexit sysret'.split(' ').map((name) => [name, 2])
]);

// pusha/popa/pushf/popf: 1 byte; la variante con dimensione opposta alla modalità aggiunge il prefisso 0x66.
const STACK_FLAGS = new Map([
    ['pusha', 16], ['popa', 16], ['pushad', 32], ['popad', 32],
    ['pushf', null], ['popf', null], ['pushfw', 16], ['popfw', 16], ['pushfd', 32], ['popfd', 32],
    ['pushfq', 64], ['popfq', 64]
]);

const ARITHMETIC = new Set(['mov', 'add', 'sub', 'xor', 'and', 'or', 'cmp', 'test']);
const SHORT_JUMPS = new Set(['jmp', 'jz', 'je', 'jnz', 'jne', 'ja', 'jae', 'jb', 'jbe', 'jg', 'jge', 'jl', 'jle', 'jo', 'jno', 'js', 'jns', 'jp', 'jnp']);

// Righe che non spostano il flusso di esecuzione e non toccano i registri: non interrompono la ricerca all'indietro.
const NEUTRAL_DIRECTIVE = /^(?:format|entry|segment|section|org|include|public|extrn|align|use16|use32|use64|display|assert|file|label|times|dup|[a-z_.$?@][\w.$?@]*\s+(?:db|dw|dd|dp|df|dq|dt|du|rb|rw|rd|rp|rf|rq|rt|file)|(?:db|dw|dd|dp|df|dq|dt|du|rb|rw|rd|rp|rf|rq|rt))\b/i;
const FLOW_ENDING = new Set(['jmp', 'ret', 'retn', 'retf', 'iret', 'iretd', 'iretq', 'iretw', 'call', 'int', 'int1', 'int3', 'into', 'syscall', 'sysenter', 'sysexit', 'sysret', 'hlt', 'ud2']);
const LABEL_PREFIX = /^(?:(?:[\w.$?@]+|@@)\s*:\s*)+/;
const DEFINITION = /^([A-Za-z_.$?@][\w.$?@]*)\s*(?:=|\bequ\b|\bfix\b)\s*(.+)$/i;

/**
 * Analisi statica leggera di un sorgente FASM 1 (x86, 16/32/64 bit).
 * Non esegue e non assembla nulla: elenca le istruzioni riconosciute con una stima della lunghezza
 * (`sizeKind`: 'exact' | 'estimated' | 'unknown') e produce diagnostiche prudenti.
 * Un mnemonic non riconosciuto NON è un errore: potrebbe essere una macro o un'estensione.
 *
 * Per ogni istruzione registra anche la colonna e `barrierBefore`: vero se prima di lei c'è un'etichetta,
 * una macro/direttiva che può cambiare il flusso o un'istruzione che chiude il blocco (jmp, call, int…),
 * quindi i valori dei registri non si possono dedurre dal codice precedente.
 */
function analyzeSource(sourceText) {
    const lines = String(sourceText).split(/\r?\n/);
    const instructions = [];
    const diagnostics = [];
    const codes = [];
    const constants = new Map();
    const format = detectFormat(sourceText);
    let mode = format.bits;
    let barrier = true;
    let macroDepth = 0;
    let macroPending = false;

    for (let lineNumber = 0; lineNumber < lines.length; lineNumber += 1) {
        const line = lines[lineNumber];
        const { code, unclosedQuote } = scanLine(line);
        codes[lineNumber] = code;
        if (unclosedQuote !== null) {
            diagnostics.push({
                line: lineNumber,
                start: unclosedQuote,
                end: code.length,
                severity: 'warning',
                code: 'FASM_UNCLOSED_STRING',
                message: t('static.unclosedString')
            });
        }

        const trimmed = code.trim();
        const leading = code.length - code.trimStart().length;
        if (!trimmed) {
            continue;
        }

        // Corpo di macro/struc: non è codice eseguito qui, le istruzioni vengono espanse altrove.
        const masked = maskStrings(trimmed);
        if (macroDepth > 0 || macroPending || /^(?:macro|struc)\b/i.test(trimmed)) {
            if (macroDepth === 0 && !macroPending) {
                macroPending = true;
            }
            const opens = (masked.match(/\{/g) || []).length;
            const closes = (masked.match(/\}/g) || []).length;
            macroDepth += opens - closes;
            if (opens > 0) {
                macroPending = false;
            }
            if (macroDepth <= 0 && opens + closes > 0) {
                macroDepth = 0;
                macroPending = false;
                barrier = true;
            }
            checkBrackets(code, lineNumber, diagnostics);
            continue;
        }

        const modeDirective = /^use(16|32|64)\b/i.exec(trimmed);
        if (modeDirective) {
            mode = Number(modeDirective[1]);
            continue;
        }
        if (/^format\b/i.test(trimmed)) {
            mode = detectFormat(trimmed).bits;
            continue;
        }

        checkBrackets(code, lineNumber, diagnostics);

        // Costanti: "nome = espressione", "nome equ espressione".
        const definition = DEFINITION.exec(trimmed);
        if (definition && !LABEL_PREFIX.test(trimmed)) {
            constants.set(definition[1], evaluate(definition[2], constants).value);
            continue;
        }

        if (LABEL_PREFIX.test(trimmed)) {
            barrier = true;
        }

        const parsed = parseInstruction(trimmed);
        if (!parsed) {
            // Riga che non è un'istruzione nota: dati e direttive neutre non cambiano il flusso, il resto (macro, if, repeat…) sì.
            if (!NEUTRAL_DIRECTIVE.test(trimmed.replace(LABEL_PREFIX, '')) && trimmed.replace(LABEL_PREFIX, '').length > 0) {
                barrier = true;
            }
            continue;
        }

        const estimate = estimateInstructionSize(parsed.mnemonic, parsed.operands, mode);
        instructions.push({
            line: lineNumber,
            column: leading + parsed.offset,
            endColumn: leading + trimmed.length,
            mnemonic: parsed.mnemonic,
            text: line.trim(),
            operands: parsed.operands,
            bytes: estimate.bytes,
            sizeKind: estimate.kind,
            mode,
            barrierBefore: barrier
        });
        barrier = FLOW_ENDING.has(parsed.mnemonic);
    }

    addDuplicateRunHints(instructions, diagnostics);
    diagnostics.push(...checkFormat(codes, format, instructions));
    return { instructions, diagnostics, format, constants };
}

/**
 * Toglie etichette e prefissi (rep, lock) e restituisce mnemonic, operandi e posizione del mnemonic
 * in `trimmed`, o null se non è un'istruzione nota.
 */
function parseInstruction(trimmed) {
    const labels = LABEL_PREFIX.exec(trimmed);
    let offset = labels ? labels[0].length : 0;
    let rest = trimmed.slice(offset);
    let prefixed = false;
    for (;;) {
        const match = /^([a-z][\w]*)\b(\s*)(.*)$/i.exec(rest);
        if (!match) {
            return null;
        }
        const word = match[1].toLowerCase();
        if (PREFIXES.has(word) && match[3]) {
            offset += match[1].length + match[2].length;
            rest = match[3];
            prefixed = true;
            continue;
        }
        if (!INSTRUCTIONS.has(word)) {
            return null;
        }
        return { mnemonic: word, operands: match[3].trim(), prefixed, offset };
    }
}

function addDuplicateRunHints(instructions, diagnostics) {
    for (let index = 0; index < instructions.length;) {
        let end = index + 1;
        while (end < instructions.length &&
            instructions[end].line === instructions[end - 1].line + 1 &&
            normalizeInstruction(instructions[end].text) === normalizeInstruction(instructions[index].text)) {
            end += 1;
        }
        if (end - index > 1) {
            diagnostics.push({
                line: instructions[index].line,
                endLine: instructions[end - 1].line,
                severity: 'information',
                code: 'FASM_DUPLICATE_RUN',
                count: end - index,
                instruction: instructions[index].text,
                message: t('static.duplicateRun', { count: end - index })
            });
        }
        index = end;
    }
}

/**
 * Separa il codice dal commento e riconosce le stringhe di FASM: delimitate da ' o ",
 * senza sequenze di escape (il delimitatore si ripete per includerlo nella stringa).
 */
function scanLine(line) {
    let quote = null;
    let quoteStart = -1;
    for (let index = 0; index < line.length; index += 1) {
        const character = line[index];
        if (quote) {
            if (character === quote) {
                quote = null;
            }
        } else if (character === '"' || character === "'") {
            quote = character;
            quoteStart = index;
        } else if (character === ';') {
            return { code: line.slice(0, index), unclosedQuote: null };
        }
    }
    return { code: line, unclosedQuote: quote ? quoteStart : null };
}

function maskStrings(code) {
    let quote = null;
    let masked = '';
    for (const character of code) {
        if (quote) {
            masked += character === quote ? character : ' ';
            if (character === quote) {
                quote = null;
            }
        } else {
            if (character === '"' || character === "'") {
                quote = character;
            }
            masked += character;
        }
    }
    return masked;
}

function checkBrackets(code, line, diagnostics) {
    const masked = maskStrings(code);
    const stack = [];
    for (let index = 0; index < masked.length; index += 1) {
        const character = masked[index];
        if ('([{'.includes(character)) {
            stack.push({ character, index });
        } else if (')]}'.includes(character)) {
            const expected = { ')': '(', ']': '[', '}': '{' }[character];
            if (!stack.length || stack.pop().character !== expected) {
                diagnostics.push({
                    line,
                    start: index,
                    end: index + 1,
                    severity: 'warning',
                    code: 'FASM_UNMATCHED_BRACKET',
                    message: t('static.unmatchedBracket', { char: character })
                });
            }
        }
    }
    for (const bracket of stack) {
        diagnostics.push({
            line,
            start: bracket.index,
            end: bracket.index + 1,
            severity: 'warning',
            code: 'FASM_UNCLOSED_BRACKET',
            message: t('static.unclosedBracket', { char: bracket.character })
        });
    }
}

/**
 * Stima la lunghezza in byte. Valori 'exact' solo per istruzioni di lunghezza fissa;
 * 'estimated' per le forme registro/immediato più comuni; altrimenti 'unknown' (bytes = null):
 * FASM sceglie la codifica più corta in base a simboli e operandi, quindi non si inventano numeri.
 */
function estimateInstructionSize(mnemonic, operands, mode) {
    if (!operands && FIXED_SIZE.has(mnemonic)) {
        return { bytes: FIXED_SIZE.get(mnemonic), kind: 'exact' };
    }
    if (!operands && STACK_FLAGS.has(mnemonic)) {
        const size = STACK_FLAGS.get(mnemonic);
        if (size === 64) {
            return mode === 64 ? { bytes: 1, kind: 'exact' } : { bytes: null, kind: 'unknown' };
        }
        if (mode === 64 && (mnemonic === 'pusha' || mnemonic === 'popa' || mnemonic === 'pushad' || mnemonic === 'popad')) {
            return { bytes: null, kind: 'unknown' }; // non valide in modalità 64 bit
        }
        const natural = size === null || size === (mode === 16 ? 16 : 32);
        if (mode === 64 && size === 32) {
            return { bytes: 1, kind: 'exact' };
        }
        return { bytes: natural ? 1 : 2, kind: 'exact' };
    }
    if (mnemonic === 'int' && /^(?:\d+|0x[\da-f]+|[\da-f]+h)$/i.test(operands) && parseNumber(operands) !== 3) {
        return { bytes: 2, kind: 'estimated' };
    }

    const parts = operands.split(',').map((part) => part.trim().toLowerCase());
    if (ARITHMETIC.has(mnemonic) && parts.length === 2) {
        const left = REGISTER_WIDTH.get(parts[0]);
        const right = REGISTER_WIDTH.get(parts[1]);
        if (left && right) {
            return { bytes: 2 + prefixBytes(left, mode, [parts[0], parts[1]]), kind: 'estimated' };
        }
        // mov reg, imm: per i registri a 64 bit FASM può scegliere più codifiche, quindi non si stima.
        if (mnemonic === 'mov' && left && left < 64 && isImmediate(parts[1])) {
            return { bytes: 1 + left / 8 + prefixBytes(left, mode, [parts[0]]), kind: 'estimated' };
        }
    }
    if (mnemonic === 'imul' && parts.length === 2 && REGISTER_WIDTH.has(parts[0]) && REGISTER_WIDTH.has(parts[1])) {
        return { bytes: 3 + prefixBytes(REGISTER_WIDTH.get(parts[0]), mode, parts), kind: 'estimated' };
    }
    if ((mnemonic === 'push' || mnemonic === 'pop') && REGISTER_WIDTH.has(parts[0]) && !operands.includes(',')) {
        const width = REGISTER_WIDTH.get(parts[0]);
        if (width === 8) {
            return { bytes: null, kind: 'unknown' };
        }
        const natural = mode === 64 ? 64 : mode;
        const extra = isExtendedRegister(parts[0]) ? 1 : 0;
        return { bytes: width === natural ? 1 + extra : (width === 16 || width === 32) && mode !== 64 ? 2 : null, kind: 'estimated' };
    }
    if (SHORT_JUMPS.has(mnemonic) && /^short\b/i.test(operands)) {
        return { bytes: 2, kind: 'estimated' };
    }
    return { bytes: null, kind: 'unknown' };
}

/** Byte aggiuntivi: prefisso 0x66 se la dimensione dell'operando non è quella naturale; REX in modalità 64 bit. */
function prefixBytes(width, mode, registers) {
    let extra = 0;
    if (width === 16 && mode !== 16) {
        extra += 1;
    }
    if (width === 32 && mode === 16) {
        extra += 1;
    }
    if (mode === 64 && (width === 64 || registers.some(isExtendedRegister))) {
        extra += 1;
    }
    return extra;
}

function parseNumber(value) {
    const text = value.toLowerCase();
    if (text.startsWith('0x')) {
        return parseInt(text.slice(2), 16);
    }
    if (text.endsWith('h')) {
        return parseInt(text.slice(0, -1), 16);
    }
    return parseInt(text, 10);
}

function isImmediate(value) {
    return /^(?:[-+]?\d+|0x[\da-f]+|[\da-f]+h|[01]+b)$/i.test(value);
}

function isExtendedRegister(register) {
    return /^r(?:[89]|1[0-5])[dwb]?$/i.test(register);
}

function normalizeInstruction(instruction) {
    return instruction.replace(/\s+/g, ' ').trim().toLowerCase();
}

module.exports = { analyzeSource, scanLine, parseInstruction };
