'use strict';

/**
 * Valutatore di espressioni costanti di FASM (sottoinsieme) senza eval:
 * numeri (decimali, 0x1F, 1Fh, $1F, 101b, 17o, 'c'), costanti già definite,
 * operatori + - * / mod shl shr and or xor not, parentesi.
 * Restituisce un numero oppure null se l'espressione non è risolvibile (simboli sconosciuti, indirizzi, ecc.).
 */

const WORD_OPERATORS = new Set(['mod', 'shl', 'shr', 'and', 'or', 'xor', 'not']);

function tokenize(text) {
    const tokens = [];
    let index = 0;
    while (index < text.length) {
        const character = text[index];
        if (/\s/.test(character)) {
            index += 1;
            continue;
        }
        if (character === "'" || character === '"') {
            const end = text.indexOf(character, index + 1);
            if (end < 0) {
                return null;
            }
            const content = text.slice(index + 1, end);
            // Costante di carattere: i byte formano un intero little-endian (fino a 4 caratteri).
            if (content.length < 1 || content.length > 4) {
                return null;
            }
            let value = 0;
            for (let i = content.length - 1; i >= 0; i -= 1) {
                value = value * 256 + content.charCodeAt(i);
            }
            tokens.push({ type: 'number', value });
            index = end + 1;
            continue;
        }
        const wordMatch = /^(?:0x[0-9a-f]+|\$[0-9][0-9a-f]*|[0-9][0-9a-f]*[hbo]?|[a-z_.$?@][\w.$?@]*)/i.exec(text.slice(index));
        if (wordMatch) {
            const word = wordMatch[0];
            tokens.push(parseWord(word));
            index += word.length;
            continue;
        }
        if ('+-*/()'.includes(character)) {
            tokens.push({ type: 'operator', value: character });
            index += 1;
            continue;
        }
        return null;
    }
    return tokens;
}

function parseWord(word) {
    const lower = word.toLowerCase();
    if (WORD_OPERATORS.has(lower)) {
        return { type: 'operator', value: lower };
    }
    let match;
    if ((match = /^0x([0-9a-f]+)$/.exec(lower))) {
        return { type: 'number', value: parseInt(match[1], 16) };
    }
    if ((match = /^\$([0-9][0-9a-f]*)$/.exec(lower))) {
        return { type: 'number', value: parseInt(match[1], 16) };
    }
    if ((match = /^([0-9][0-9a-f]*)h$/.exec(lower))) {
        return { type: 'number', value: parseInt(match[1], 16) };
    }
    if ((match = /^([01]+)b$/.exec(lower))) {
        return { type: 'number', value: parseInt(match[1], 2) };
    }
    if ((match = /^([0-7]+)o$/.exec(lower))) {
        return { type: 'number', value: parseInt(match[1], 8) };
    }
    if (/^[0-9]+$/.test(lower)) {
        return { type: 'number', value: parseInt(lower, 10) };
    }
    return { type: 'name', value: word };
}

/**
 * @param {string} text espressione
 * @param {Map<string, number|null>} constants costanti note (null = definita ma non valutabile)
 * @returns {{value: number|null, symbol: string|null}} `symbol` è il nome se l'espressione è solo un identificatore
 */
function evaluate(text, constants = new Map()) {
    const tokens = tokenize(String(text).trim());
    if (!tokens || !tokens.length) {
        return { value: null, symbol: null };
    }
    const symbol = tokens.length === 1 && tokens[0].type === 'name' ? tokens[0].value : null;
    let position = 0;
    let failed = false;

    const peek = () => tokens[position];
    const takeOperator = (...operators) => {
        const token = peek();
        if (token && token.type === 'operator' && operators.includes(token.value)) {
            position += 1;
            return token.value;
        }
        return null;
    };

    // Precedenze: or/xor < and < shl/shr < + - < * / mod < unari
    const parseOr = () => {
        let left = parseAnd();
        for (let op = takeOperator('or', 'xor'); op; op = takeOperator('or', 'xor')) {
            const right = parseAnd();
            left = op === 'or' ? (left | right) >>> 0 : (left ^ right) >>> 0;
        }
        return left;
    };
    const parseAnd = () => {
        let left = parseShift();
        while (takeOperator('and')) {
            left = (left & parseShift()) >>> 0;
        }
        return left;
    };
    const parseShift = () => {
        let left = parseSum();
        for (let op = takeOperator('shl', 'shr'); op; op = takeOperator('shl', 'shr')) {
            const right = parseSum();
            left = op === 'shl' ? Math.floor(left * 2 ** right) : Math.floor(left / 2 ** right);
        }
        return left;
    };
    const parseSum = () => {
        let left = parseProduct();
        for (let op = takeOperator('+', '-'); op; op = takeOperator('+', '-')) {
            const right = parseProduct();
            left = op === '+' ? left + right : left - right;
        }
        return left;
    };
    const parseProduct = () => {
        let left = parseUnary();
        for (let op = takeOperator('*', '/', 'mod'); op; op = takeOperator('*', '/', 'mod')) {
            const right = parseUnary();
            if (op === '*') {
                left *= right;
            } else if (right === 0) {
                failed = true;
            } else {
                left = op === '/' ? Math.trunc(left / right) : left % right;
            }
        }
        return left;
    };
    const parseUnary = () => {
        if (takeOperator('-')) {
            return -parseUnary();
        }
        if (takeOperator('+')) {
            return parseUnary();
        }
        if (takeOperator('not')) {
            return (~parseUnary()) >>> 0;
        }
        return parsePrimary();
    };
    const parsePrimary = () => {
        const token = peek();
        if (!token) {
            failed = true;
            return 0;
        }
        position += 1;
        if (token.type === 'number') {
            return token.value;
        }
        if (token.type === 'name') {
            const value = constants.get(token.value);
            if (typeof value !== 'number') {
                failed = true;
                return 0;
            }
            return value;
        }
        if (token.value === '(') {
            const value = parseOr();
            if (!takeOperator(')')) {
                failed = true;
            }
            return value;
        }
        failed = true;
        return 0;
    };

    const value = parseOr();
    if (failed || position !== tokens.length || !Number.isFinite(value)) {
        return { value: null, symbol };
    }
    return { value, symbol };
}

module.exports = { evaluate };
