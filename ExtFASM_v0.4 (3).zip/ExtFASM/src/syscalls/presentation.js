'use strict';

const { t } = require('../i18n/i18n');

/**
 * Trasforma i risultati di `analyzeSyscalls` in ciò che l'editor mostra (diagnostiche, hover, categorie
 * di colore). Nessuna dipendenza da `vscode`: tutto il testo e le regole sono verificabili con i test.
 */

/** Categoria del motore -> modificatore del token semantico `fasmSyscall` (dichiarati in package.json). */
const MODIFIER_BY_CATEGORY = {
    valid: 'syscallValid',
    unknown: 'syscallUnknown',
    'invalid-for-target': 'syscallInvalid',
    unverifiable: 'syscallUnverifiable'
};

const MODIFIER_NAMES = Object.values(MODIFIER_BY_CATEGORY);

const CATEGORY_LABEL_KEYS = {
    valid: 'hover.title.valid',
    unknown: 'hover.title.unknown',
    'invalid-for-target': 'hover.title.invalid',
    unverifiable: 'hover.title.unverifiable'
};

/**
 * Le chiamate valide non producono diagnostiche; quelle da correggere sono avvisi;
 * quelle che l'estensione non può verificare restano un suggerimento discreto (mai un errore inventato).
 */
function toDiagnostics(findings) {
    const items = [];
    for (const finding of findings) {
        if (finding.category === 'valid') {
            continue;
        }
        items.push({
            line: finding.line,
            start: finding.start,
            end: finding.end,
            severity: finding.category === 'unverifiable' ? 'hint' : 'warning',
            message: finding.message,
            code: `syscall-${finding.kind}`
        });
    }
    return items;
}

function hex(number) {
    return `0x${number.toString(16)}`;
}

function formatNumber(finding) {
    return finding.number === null || finding.number === undefined ? t('hover.unknownNumber') : `${hex(finding.number)} (${finding.number})`;
}

/** Testo Markdown dell'hover: solo dati presenti nel risultato, con la provenienza della tabella. */
function hoverMarkdown(finding) {
    const lines = [];
    const title = finding.name ? `**${finding.name}**` : `**${t('hover.syscall')}**`;
    lines.push(`${title} — ${CATEGORY_LABEL_KEYS[finding.category] ? t(CATEGORY_LABEL_KEYS[finding.category]) : finding.category}`);
    lines.push('');
    lines.push(finding.message);
    lines.push('');

    const facts = [];
    facts.push(t('hover.number', { value: formatNumber(finding) }));
    if (finding.os) {
        const target = finding.target || {};
        facts.push(t('hover.target', { os: finding.os, assumed: target.assumed ? t('hover.assumed') : '', reason: target.reason || '' }).replace(/ — $/, ''));
    }
    facts.push(t('hover.entry', { text: finding.text, mode: finding.mode }));
    if (finding.convention) {
        const { number, args, result } = finding.convention;
        facts.push(t('hover.convention', { number, args: args.map((arg) => `\`${arg}\``).join(', '), result }));
        facts.push(t('hover.noArgCount'));
    }
    lines.push(...facts);

    if (finding.detail && finding.detail.candidates) {
        lines.push('', t('hover.perVersion'));
        for (const candidate of finding.detail.candidates.slice(0, 6)) {
            const count = candidate.versions.length;
            lines.push(t('hover.candidate', { name: candidate.name, versions: count === 1 ? t('sys.windows.versions.one') : t('sys.windows.versions.many', { count }) }));
        }
        if (finding.detail.candidates.length > 6) {
            lines.push(t('hover.moreCandidates', { count: finding.detail.candidates.length - 6 }));
        }
    }
    if (finding.notes && finding.notes.length) {
        lines.push('', ...finding.notes.map((note) => `> ${note}`));
    }
    if (finding.table) {
        lines.push('', t('hover.source', { repository: finding.table.repository, commit: finding.table.shortCommit, table: finding.table.table }));
    }
    return lines.join('\n');
}

/** Trova il risultato che copre una posizione (riga, colonna) del documento. */
function findAt(findings, line, character) {
    return findings.find((finding) => finding.line === line && character >= finding.start && character <= finding.end) || null;
}

module.exports = { MODIFIER_BY_CATEGORY, MODIFIER_NAMES, toDiagnostics, hoverMarkdown, findAt };
