'use strict';

const { t } = require('../i18n/i18n');
const { INSTRUCTIONS, PREFIXES } = require('../analysis/instructions');
const { detectFormat } = require('../analysis/formats');
const { scanLine } = require('../analysis/analyzer');
const { evaluateExpression } = require('../analysis/expression');
const { RegisterState, parseRegister, MASKS } = require('../analysis/registers');
const { OPERATING_SYSTEMS, KNOWN_INTERRUPT_VECTORS, resolveTarget } = require('./os');
const tables = require('./tables');

/**
 * Riconoscimento delle chiamate di sistema (`syscall`, `sysenter`, `int 0x80/0x2e/0x40/0x60`) in un
 * sorgente FASM 1, con il numero ricavato dal flusso lineare del codice.
 *
 * Categorie (campo `category`):
 *  - valid              numero riconosciuto e compatibile con il sistema di destinazione;
 *  - unknown            il numero non esiste nella tabella del sistema di destinazione;
 *  - invalid-for-target l'istruzione, la modalità o il numero sono noti ma non utilizzabili su quel sistema;
 *  - unverifiable       mancano informazioni (sistema, tabella, numero non costante, versione di Windows).
 * Il riconoscimento del token NON dice che la chiamata riuscirà a runtime.
 */

const DATA_WORDS = 'db dw dd dp df dq dt du rb rw rd rp rf rq rt';
const DATA_DEFINITION = new RegExp(`^[A-Za-z_.@?][\\w.@?$]*\\s+(?:${DATA_WORDS.split(' ').join('|')}|equ|fix|struc|file)\\b`, 'i');
const IGNORED_DIRECTIVES = new Set([...DATA_WORDS.split(' '), 'include', 'file', 'org', 'entry', 'display', 'assert',
    'public', 'extrn', 'label', 'load', 'store', 'align', 'times', 'dup', 'restore', 'purge', 'define', 'calminstruction']);
const RESET_DIRECTIVES = new Set(['if', 'else', 'end', 'repeat', 'rept', 'irp', 'irps', 'while', 'match', 'postpone',
    'segment', 'section', 'virtual', 'break']);
const CONDITIONAL_JUMP = /^j(?:o|no|b|c|nae|ae|nb|nc|be|na|a|nbe|s|ns|e|z|ne|nz|p|pe|np|po|l|nge|ge|nl|le|ng|g|nle|cxz|ecxz|rcxz)$/;
const NO_REGISTER_WRITE = new Set(['cmp', 'test', 'bt', 'nop', 'wait', 'pause', 'cld', 'std', 'cli', 'sti', 'clc', 'stc', 'cmc',
    'sahf', 'hlt', 'ud2', 'lfence', 'mfence', 'sfence', 'lock', 'invlpg', 'int3', 'into', 'verr', 'verw']);

function maskForWidth(width) {
    return MASKS[width];
}

// --- Costanti ------------------------------------------------------------------------------------------

const CONSTANT_ASSIGNMENT = /^([A-Za-z_.@?][\w.@?$]*)\s*=\s*(.+)$/;
const CONSTANT_EQU = /^([A-Za-z_.@?][\w.@?$]*)\s+equ\s+(.+)$/i;

function parseDefinition(rest) {
    const match = CONSTANT_ASSIGNMENT.exec(rest) || CONSTANT_EQU.exec(rest);
    return match ? { name: match[1], expression: match[2].trim() } : null;
}

/** Costanti definite una sola volta (valgono anche nei riferimenti in avanti). */
function collectStaticConstants(lines) {
    const definitions = new Map();
    for (const line of lines) {
        const { code } = scanLine(line);
        const definition = parseDefinition(code.trim());
        if (definition) {
            definitions.set(definition.name, [...(definitions.get(definition.name) || []), definition.expression]);
        }
    }
    const constants = new Map();
    for (let round = 0; round < 6; round += 1) {
        let changed = false;
        for (const [name, expressions] of definitions) {
            if (expressions.length !== 1 || constants.has(name)) {
                continue;
            }
            const value = evaluateExpression(expressions[0], constants);
            if (value !== null) {
                constants.set(name, value);
                changed = true;
            }
        }
        if (!changed) {
            break;
        }
    }
    return { constants, redefined: new Set([...definitions].filter(([, list]) => list.length > 1).map(([name]) => name)) };
}

// --- Operandi ------------------------------------------------------------------------------------------

function splitOperands(text) {
    const operands = [];
    let depth = 0;
    let quote = null;
    let current = '';
    for (const character of text) {
        if (quote) {
            current += character;
            if (character === quote) quote = null;
        } else if (character === '"' || character === "'") {
            quote = character;
            current += character;
        } else if (character === '[' || character === '(') {
            depth += 1;
            current += character;
        } else if (character === ']' || character === ')') {
            depth -= 1;
            current += character;
        } else if (character === ',' && depth === 0) {
            operands.push(current.trim());
            current = '';
        } else {
            current += character;
        }
    }
    if (current.trim()) {
        operands.push(current.trim());
    }
    return operands;
}

const isMemory = (operand) => /\[/.test(operand) || /^(?:byte|word|dword|qword|ptr)\b/i.test(operand);
const stripSizePrefix = (operand) => operand.replace(/^(?:byte|word|dword|qword)\s+/i, '');

/** Valore di un operando sorgente: registro, costante, oppure null (memoria/sconosciuto). */
function operandValue(operand, state, constants) {
    if (operand === undefined) return null;
    const register = parseRegister(operand);
    if (register) return { value: state.read(register), width: register.width };
    if (isMemory(operand)) return { value: null, width: null };
    return { value: evaluateExpression(stripSizePrefix(operand), constants), width: null };
}

// --- Effetto di una istruzione sui registri ------------------------------------------------------------

function applyInstruction(state, mnemonic, operandsText, mode, constants, repeated) {
    const operands = splitOperands(operandsText);
    const destination = operands[0] !== undefined ? parseRegister(operands[0]) : null;
    const source = operandValue(operands[1], state, constants);

    const writeResult = (value) => {
        if (destination) state.write(destination, value, mode);
    };
    const destinationValue = () => (destination ? state.read(destination) : null);

    if (CONDITIONAL_JUMP.test(mnemonic)) {
        return;
    }
    if (mnemonic.startsWith('loop')) {
        state.clearFamilies(['c']);
        return;
    }

    switch (mnemonic) {
        case 'mov':
            if (destination) {
                const value = source ? source.value : null;
                writeResult(value);
            }
            return;
        case 'movzx':
        case 'movsx':
        case 'movsxd':
            if (destination && source && source.value !== null && source.width) {
                const raw = source.value;
                const signed = mnemonic !== 'movzx' && (raw >> BigInt(source.width - 1)) & 1n;
                writeResult(signed ? raw | (maskForWidth(64) & ~maskForWidth(source.width)) : raw);
            } else {
                writeResult(null);
            }
            return;
        case 'xor':
        case 'sub':
            if (destination && operands[1] && parseRegister(operands[1]) &&
                parseRegister(operands[1]).family === destination.family && parseRegister(operands[1]).width === destination.width &&
                parseRegister(operands[1]).shift === destination.shift) {
                writeResult(0n);
                return;
            }
        // eslint-disable-next-line no-fallthrough
        case 'add':
        case 'and':
        case 'or': {
            const left = destinationValue();
            const right = source ? source.value : null;
            if (destination && left !== null && right !== null) {
                const operators = { add: (a, b) => a + b, sub: (a, b) => a - b, and: (a, b) => a & b, or: (a, b) => a | b, xor: (a, b) => a ^ b };
                writeResult(operators[mnemonic](left, right));
            } else {
                writeResult(null);
            }
            return;
        }
        case 'inc':
        case 'dec':
        case 'neg':
        case 'not': {
            const value = destinationValue();
            if (value === null) {
                writeResult(null);
            } else if (mnemonic === 'inc') {
                writeResult(value + 1n);
            } else if (mnemonic === 'dec') {
                writeResult(value - 1n);
            } else if (mnemonic === 'neg') {
                writeResult(-value);
            } else {
                writeResult(~value);
            }
            return;
        }
        case 'shl':
        case 'sal':
        case 'shr': {
            const value = destinationValue();
            const count = source ? source.value : null;
            if (destination && value !== null && count !== null && count < 64n) {
                writeResult(mnemonic === 'shr' ? value >> count : value << count);
            } else {
                writeResult(null);
            }
            return;
        }
        case 'xchg': {
            const other = operands[1] !== undefined ? parseRegister(operands[1]) : null;
            if (destination && other && destination.width === other.width) {
                const a = state.read(destination);
                const b = state.read(other);
                state.write(destination, b, mode);
                state.write(other, a, mode);
            } else {
                if (destination) state.writeUnknown(destination);
                if (other) state.writeUnknown(other);
            }
            return;
        }
        case 'push': {
            const value = operands[0] === undefined ? null : operandValue(operands[0], state, constants).value;
            state.stack.push(value);
            if (state.stack.length > 64) state.stack.shift();
            return;
        }
        case 'pop': {
            const value = state.stack.length ? state.stack.pop() : null;
            if (destination) state.write(destination, value, mode);
            return;
        }
        case 'pushf':
        case 'pushfd':
        case 'pushfq':
        case 'pushfw':
            state.stack.push(null);
            return;
        case 'popf':
        case 'popfd':
        case 'popfq':
        case 'popfw':
            state.stack.pop();
            return;
        case 'pusha':
        case 'pushad':
            for (let index = 0; index < 8; index += 1) state.stack.push(null);
            return;
        case 'popa':
        case 'popad':
            state.reset();
            return;
        case 'cdq':
        case 'cqo':
        case 'cwd':
            state.clearFamilies(['d']);
            return;
        case 'cdqe':
        case 'cwde':
        case 'cbw':
        case 'lahf':
        case 'xlat':
        case 'xlatb':
        case 'in':
            state.clearFamilies(['a']);
            return;
        case 'mul':
        case 'div':
        case 'idiv':
            state.clearFamilies(['a', 'd']);
            return;
        case 'imul':
            if (operands.length >= 2 && destination) {
                state.writeUnknown(destination);
            } else {
                state.clearFamilies(['a', 'd']);
            }
            return;
        case 'cpuid':
            state.clearFamilies(['a', 'b', 'c', 'd']);
            return;
        case 'rdtsc':
        case 'rdtscp':
        case 'rdmsr':
        case 'rdpmc':
        case 'xgetbv':
            state.clearFamilies(['a', 'c', 'd']);
            return;
        case 'lods': case 'lodsb': case 'lodsw': case 'lodsd': case 'lodsq':
            state.clearFamilies(repeated ? ['a', 'si', 'c'] : ['a', 'si']);
            return;
        case 'stos': case 'stosb': case 'stosw': case 'stosd': case 'stosq':
        case 'scas': case 'scasb': case 'scasw': case 'scasd': case 'scasq':
            state.clearFamilies(repeated ? ['di', 'c'] : ['di']);
            return;
        case 'movs': case 'movsb': case 'movsw': case 'movsd': case 'movsq':
        case 'cmps': case 'cmpsb': case 'cmpsw': case 'cmpsd': case 'cmpsq':
            state.clearFamilies(repeated ? ['si', 'di', 'c'] : ['si', 'di']);
            return;
        case 'enter':
        case 'leave':
            state.clearFamilies(['bp', 'sp']);
            return;
        case 'call':
        case 'jmp':
        case 'ret':
        case 'retn':
        case 'retf':
        case 'iret':
        case 'iretd':
        case 'iretq':
        case 'iretw':
        case 'int':
        case 'sysret':
        case 'sysexit':
            state.reset();
            return;
        default:
            break;
    }

    if (NO_REGISTER_WRITE.has(mnemonic)) {
        return;
    }
    // Qualsiasi altra istruzione nota: se il primo operando è un registro lo si considera modificato.
    if (destination) {
        state.writeUnknown(destination);
    }
}

// --- Passata principale --------------------------------------------------------------------------------

function braceDelta(code) {
    let depth = 0;
    let quote = null;
    for (const character of code) {
        if (quote) {
            if (character === quote) quote = null;
        } else if (character === '"' || character === "'") {
            quote = character;
        } else if (character === '{') {
            depth += 1;
        } else if (character === '}') {
            depth -= 1;
        }
    }
    return depth;
}

/**
 * @param {string} sourceText
 * @param {{os?: string, windowsVersion?: string, format?: object}} [options]
 * @returns {{target: object, sites: object[], findings: object[]}}
 */
function analyzeSyscalls(sourceText, options = {}) {
    const lines = String(sourceText).split(/\r?\n/);
    const format = options.format || detectFormat(sourceText);
    const target = resolveTarget({ format, setting: options.os || 'auto', sourceText });
    const windowsVersion = options.windowsVersion || '';
    const { constants: staticConstants } = collectStaticConstants(lines);
    const constants = new Map(staticConstants);
    const state = new RegisterState();
    const findings = [];
    let mode = format.bits;
    let macroDepth = 0;
    let waitingForBrace = false;

    const endLine = options.untilLine === undefined ? lines.length : Math.min(options.untilLine, lines.length);
    for (let lineNumber = 0; lineNumber < endLine; lineNumber += 1) {
        const { code } = scanLine(lines[lineNumber]);
        if (!code.trim()) {
            continue;
        }

        if (waitingForBrace || macroDepth > 0) {
            // corpo di una macro/struc: non è codice eseguito sul posto
            if (code.includes('{') || macroDepth > 0) {
                macroDepth += braceDelta(code);
                waitingForBrace = false;
                if (macroDepth < 0) macroDepth = 0;
            }
            continue;
        }

        const labelMatch = /^\s*(?:(?:[\w.$?@]+|@@)\s*:\s*)+/.exec(code);
        if (labelMatch) {
            state.reset();
        }
        let offset = labelMatch ? labelMatch[0].length : 0;
        let rest = code.slice(offset);
        if (!rest.trim()) {
            continue;
        }
        offset += rest.length - rest.trimStart().length;
        rest = rest.trim();

        const firstWord = /^([A-Za-z_.@?][\w.@?$]*)/.exec(rest);
        const word = firstWord ? firstWord[1].toLowerCase() : '';

        const modeDirective = /^use(16|32|64)\b/i.exec(rest);
        if (modeDirective) {
            mode = Number(modeDirective[1]);
            continue;
        }
        if (word === 'format') {
            mode = detectFormat(rest).bits;
            continue;
        }
        if (word === 'macro' || word === 'struc') {
            const delta = braceDelta(rest);
            if (rest.includes('{')) {
                macroDepth = Math.max(delta, 0);
            } else {
                waitingForBrace = true;
            }
            continue;
        }
        const definition = parseDefinition(rest);
        if (definition) {
            const value = evaluateExpression(definition.expression, constants);
            if (value !== null) {
                constants.set(definition.name, value);
            } else {
                constants.delete(definition.name);
            }
            continue;
        }
        if (DATA_DEFINITION.test(rest) || IGNORED_DIRECTIVES.has(word)) {
            continue;
        }
        if (RESET_DIRECTIVES.has(word)) {
            state.reset();
            continue;
        }

        // prefissi (rep, lock...) e mnemonic
        let repeated = false;
        let instructionText = rest;
        let instructionOffset = offset;
        for (;;) {
            const match = /^([A-Za-z][\w]*)\b\s*(.*)$/.exec(instructionText);
            if (match && PREFIXES.has(match[1].toLowerCase()) && match[2]) {
                repeated = repeated || /^rep/i.test(match[1]);
                instructionOffset += instructionText.length - match[2].length;
                instructionText = match[2];
                continue;
            }
            break;
        }
        const instructionMatch = /^([A-Za-z][\w]*)\b\s*(.*)$/.exec(instructionText);
        if (!instructionMatch) {
            state.reset();
            continue;
        }
        const mnemonic = instructionMatch[1].toLowerCase();
        const operandsText = instructionMatch[2].trim();

        if (!INSTRUCTIONS.has(mnemonic)) {
            state.reset(); // macro o istruzione sconosciuta: può modificare qualunque registro
            continue;
        }

        const site = detectSite(mnemonic, operandsText, constants);
        if (site) {
            const finding = classify({
                site, target, mode, windowsVersion,
                numberState: readNumber(state)
            });
            finding.line = lineNumber;
            finding.start = instructionOffset;
            finding.end = instructionOffset + instructionMatch[0].trimEnd().length;
            finding.text = instructionMatch[0].trim();
            finding.mode = mode;
            if (finding.category !== 'skipped') {
                findings.push(finding);
            }
            state.clearFamilies(['a', 'b', 'c', 'd', 'r11']);
            continue;
        }
        applyInstruction(state, mnemonic, operandsText, mode, constants, repeated);
    }

    return { target, findings, state, constants, mode };
}

function readNumber(state) {
    return state.read(parseRegister('rax'));
}

/** Riconosce `syscall`, `sysenter` e `int <vettore noto>`; altrimenti null. */
function detectSite(mnemonic, operandsText, constants) {
    if (mnemonic === 'syscall' || mnemonic === 'sysenter') {
        return { instruction: mnemonic };
    }
    if (mnemonic === 'int') {
        const vector = evaluateExpression(operandsText, constants);
        if (vector !== null && KNOWN_INTERRUPT_VECTORS.has(Number(vector))) {
            return { instruction: 'int', vector: Number(vector) };
        }
    }
    return null;
}

// --- Classificazione -----------------------------------------------------------------------------------

const hex = (number) => `0x${number.toString(16).toUpperCase()}`;

function describeInstruction(site) {
    return site.instruction === 'int' ? `int ${hex(site.vector)}` : site.instruction;
}

function conventionOf(mechanism) {
    return { number: mechanism.number, args: mechanism.args, result: mechanism.result };
}

function classify({ site, target, mode, windowsVersion, numberState }) {
    const label = describeInstruction(site);
    const base = { instruction: site.instruction, vector: site.vector ?? null, os: target.os, target, number: null, name: null, notes: [], table: null };
    const make = (category, kind, message, extra = {}) => ({ ...base, category, kind, message, ...extra });

    if (target.os === 'dos') {
        return { category: 'skipped' };
    }
    if (!target.os) {
        return make('unverifiable', 'no-target', t('sys.noTarget', { label, reason: capitalize(target.reason) }));
    }

    const osDefinition = OPERATING_SYSTEMS[target.os];
    const mechanism = osDefinition.mechanisms.find((candidate) =>
        candidate.instruction === site.instruction && (site.instruction !== 'int' || candidate.vector === site.vector));
    const assumption = target.assumed ? t('sys.assumed') : '';

    if (!mechanism) {
        const owners = site.instruction === 'int'
            ? t('sys.entryOwner', { owner: t(KNOWN_INTERRUPT_VECTORS.get(site.vector)) })
            : '';
        const supported = osDefinition.mechanisms.map((candidate) => (candidate.instruction === 'int' ? `int ${hex(candidate.vector)}` : candidate.instruction)).join(', ');
        return make('invalid-for-target', 'wrong-entry', t('sys.wrongEntry', { label, os: osDefinition.label, owners, supported, assumption }));
    }
    if (!mechanism.modes.includes(mode)) {
        return make('invalid-for-target', 'wrong-mode',
            t('sys.wrongMode', { label, os: osDefinition.label, modes: mechanism.modes.join(t('sys.or')), mode, assumption }),
            { convention: conventionOf(mechanism) });
    }

    const notes = [];
    if (mechanism.note) notes.push(t(mechanism.note));
    if (mechanism.modeNotes && mechanism.modeNotes[mode]) notes.push(t(mechanism.modeNotes[mode]));
    if (target.assumed) notes.push(t('sys.noteAssumed', { reason: target.reason }));
    if (target.ambiguousWith) notes.push(t('sys.noteAmbiguous', { os: OPERATING_SYSTEMS[target.ambiguousWith].label }));
    const common = { notes, convention: conventionOf(mechanism) };

    if (mechanism.unverifiable) {
        return make('unverifiable', 'mechanism-unverifiable', t('sys.mechanismUnverifiable', { label, reason: t(mechanism.unverifiable) }), common);
    }
    if (mechanism.table === null) {
        return make('unverifiable', 'no-table', t('sys.noTable', { label, os: osDefinition.label, reason: osDefinition.noTableReason ? t(osDefinition.noTableReason) : '' }).trim(), common);
    }

    // Numero effettivo letto dal registro, secondo la convenzione del sistema.
    if (numberState === null) {
        return make('unverifiable', 'number-unknown',
            t('sys.numberUnknown', { label, register: mechanism.number, assumption }),
            common);
    }
    let number = Number(numberState & 0xffffffffn);
    if (target.os === 'linux' && mechanism.instruction === 'syscall' && numberState > 0xffffffffn) {
        return make('unknown', 'number-out-of-range', t('sys.outOfRange', { label, register: mechanism.number, value: hex(Number(numberState)), assumption }), { ...common, number: Number(numberState & 0xffffffffffffn) });
    }
    if (target.os === 'kolibrios') {
        const low = number & 0xff;
        if (low !== number) {
            notes.push(t('sys.noteLowByte', { from: hex(number), to: low }));
        }
        number = low;
    }

    switch (target.os) {
        case 'linux':
            return linuxResult({ make, label, mechanism, number, common, assumption, osDefinition });
        case 'freebsd':
            return freeBsdResult({ make, label, number, common, assumption });
        case 'windows':
            return windowsResult({ make, label, mechanism, number, common, mode, windowsVersion });
        case 'kolibrios':
            return kolibriResult({ make, label, number, common, assumption });
        default:
            return make('unverifiable', 'no-table', t('sys.noTableGeneric', { label }), common);
    }
}

function capitalize(text) {
    return text.charAt(0).toUpperCase() + text.slice(1);
}

function linuxResult({ make, label, mechanism, number, common, assumption }) {
    const result = tables.lookupLinux(mechanism.table, number);
    const architecture = mechanism.table === 'linux-x86_64' ? 'x86-64' : 'i386';
    const provenance = tables.provenance(mechanism.table);
    if (result.status === 'found') {
        return make('valid', 'recognized', t('sys.linux.ok', { label, name: result.name, number, arch: architecture, assumption }), { ...common, number, name: result.name, table: provenance, detail: { entry: result.entry, noreturn: result.noreturn } });
    }
    return make('unknown', 'number-not-in-table', t('sys.linux.unknown', { label, number, arch: architecture, assumption }), { ...common, number, table: provenance });
}

function freeBsdResult({ make, label, number, common, assumption }) {
    const result = tables.lookupFreeBsd(number);
    const provenance = tables.provenance('freebsd');
    if (result.status === 'found') {
        const compat = result.compat ? t('sys.freebsd.compat', { compat: result.compat }) : '';
        return make('valid', 'recognized', t('sys.freebsd.ok', { label, name: result.name, number, compat, assumption }), { ...common, number, name: result.name, table: provenance });
    }
    if (result.status === 'unusable') {
        return make('invalid-for-target', 'unusable', t('sys.freebsd.unusable', { label, number, state: t(result.type === 'OBSOL' ? 'sys.freebsd.obsolete' : result.type === 'UNIMPL' ? 'sys.freebsd.unimplemented' : 'sys.freebsd.reserved'), named: result.name ? ` (${result.name})` : '', assumption }), { ...common, number, table: provenance });
    }
    return make('unknown', 'number-not-in-table', t('sys.freebsd.unknown', { label, number, assumption }), { ...common, number, table: provenance });
}

function kolibriResult({ make, label, number, common, assumption }) {
    const result = tables.lookupKolibri(number);
    const provenance = tables.provenance('kolibrios');
    const shown = number === 255 ? '-1' : String(number);
    if (result.status === 'found') {
        return make('valid', 'recognized', t('sys.kolibrios.ok', { label, shown, name: result.name, assumption }), { ...common, number, name: result.name, table: provenance, detail: { subfunctions: result.subfunctions } });
    }
    if (result.status === 'unusable') {
        return make('invalid-for-target', 'unusable', t('sys.kolibrios.unusable', { label, shown, reason: t(result.reasonKey), assumption }), { ...common, number, name: result.name, table: provenance });
    }
    return make('unknown', 'number-not-in-table', t('sys.kolibrios.unknown', { label, shown, reason: result.reasonKey ? ` (${t(result.reasonKey)})` : '', assumption }), { ...common, number, table: provenance });
}

function windowsResult({ make, label, mechanism, number, common, mode, windowsVersion }) {
    const arch = mechanism.arch || (mechanism.archByMode && mechanism.archByMode[mode]);
    const provenance = tables.provenance(`windows-${arch}`);
    const result = tables.lookupWindows(arch, number, windowsVersion);
    const numberText = `${hex(number)} (${number})`;

    if (result.status === 'found') {
        return make('valid', 'recognized', t('sys.windows.ok', { label, name: result.name, number: numberText, version: result.version, arch }), { ...common, number, name: result.name, table: provenance });
    }
    if (result.status === 'no-table') {
        return make('unverifiable', 'windows-version-arch', t('sys.windows.noTable', { label, version: result.version, arch, number: numberText }), { ...common, number, table: provenance });
    }
    if (result.status === 'candidates') {
        const plural = (count) => (count === 1 ? t('sys.windows.versions.one') : t('sys.windows.versions.many', { count }));
        const shown = result.candidates.slice(0, 3).map((candidate) => `${candidate.name} (${plural(candidate.versions.length)})`).join(', ');
        const rest = result.candidates.length - 3;
        const more = rest > 0 ? t(rest === 1 ? 'sys.windows.more.one' : 'sys.windows.more.many', { count: rest }) : '';
        return make('unverifiable', 'windows-version-missing',
            t('sys.windows.candidates', { label, number: numberText, arch, shown, more }),
            { ...common, number, table: provenance, detail: { candidates: result.candidates, totalVersions: result.totalVersions } });
    }
    const where = windowsVersion ? t('sys.windows.whereVersion', { version: windowsVersion, arch }) : t('sys.windows.whereAny', { arch });
    return make('unknown', 'number-not-in-table', t('sys.windows.unknown', { label, number: numberText, where }), { ...common, number, table: provenance });
}

module.exports = { analyzeSyscalls, collectStaticConstants, splitOperands, applyInstruction };
