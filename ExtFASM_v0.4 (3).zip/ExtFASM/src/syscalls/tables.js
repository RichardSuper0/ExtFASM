'use strict';

/**
 * Accesso alle tabelle delle syscall (src/data/*.json, importate da fonti originali:
 * vedi scripts/import-*.js e il campo `source` di ogni file). I file sono caricati solo quando servono.
 */

const cache = new Map();

function load(name) {
    if (!cache.has(name)) {
        cache.set(name, require(`../data/${name}.json`));
    }
    return cache.get(name);
}

/** Informazioni sulla provenienza dei dati, per messaggi e hover. */
function provenance(name) {
    const { source } = load(name);
    return {
        table: name,
        repository: source.repository,
        commit: source.commit,
        shortCommit: source.commit.slice(0, 12),
        commitDate: source.commitDate
    };
}

function indexBy(name, build) {
    const key = `index:${name}`;
    if (!cache.has(key)) {
        cache.set(key, build(load(name)));
    }
    return cache.get(key);
}

// --- Linux ---------------------------------------------------------------------------------------------

function lookupLinux(tableName, number) {
    const index = indexBy(tableName, (data) => {
        const map = new Map();
        for (const entry of data.syscalls) {
            if (entry.abi === 'x32') {
                continue; // numeri dell'ABI x32: non validi per un processo x86-64 nativo
            }
            map.set(entry.number, entry);
        }
        return map;
    });
    const entry = index.get(number);
    return entry ? { status: 'found', name: entry.name, entry: entry.entry, noreturn: entry.noreturn } : { status: 'unknown' };
}

// --- FreeBSD -------------------------------------------------------------------------------------------

const FREEBSD_USABLE = new Set(['STD', 'NOSTD', 'NODEF', 'NOARGS', 'NOPROTO', 'SYSMUX']);

function lookupFreeBsd(number) {
    const index = indexBy('freebsd', (data) => new Map(data.syscalls.map((entry) => [entry.number, entry])));
    const entry = index.get(number);
    if (!entry) {
        return { status: 'unknown' };
    }
    if (FREEBSD_USABLE.has(entry.type)) {
        return { status: 'found', name: entry.name, noreturn: entry.noreturn };
    }
    if (entry.type.startsWith('COMPAT')) {
        return { status: 'found', name: entry.name, compat: entry.type };
    }
    return { status: 'unusable', name: entry.name, type: entry.type };
}

// --- KolibriOS -----------------------------------------------------------------------------------------

function lookupKolibri(number) {
    const index = indexBy('kolibrios', (data) => new Map(data.functions.map((entry) => [entry.number, entry])));
    const entry = index.get(number);
    if (!entry) {
        return { status: 'unknown' };
    }
    const title = entry.title || entry.kernelName || null;
    if (entry.status === 'active') {
        return { status: 'found', name: title, kernelName: entry.kernelName, subfunctions: entry.subfunctions || null };
    }
    if (entry.status === 'deprecated') {
        return { status: 'unusable', name: entry.note || entry.kernelName, reasonKey: 'sys.kolibrios.deprecated' };
    }
    return { status: 'unknown', reasonKey: entry.status === 'free' ? 'sys.kolibrios.free' : 'sys.kolibrios.reserved' };
}

// --- Windows -------------------------------------------------------------------------------------------

function windowsServiceFor(number) {
    if (number >= 0x1000 && number < 0x2000) {
        return 'win32k';
    }
    return number < 0x1000 ? 'nt' : null;
}

/** Elenco delle versioni di Windows presenti nelle tabelle (unione x86/x64), nell'ordine delle tabelle. */
function windowsVersions() {
    const seen = new Set();
    for (const arch of ['x86', 'x64']) {
        Object.keys(load(`windows-${arch}`).nt.systems).forEach((label) => seen.add(label));
    }
    return [...seen];
}

function windowsVersionsFor(arch) {
    return Object.keys(load(`windows-${arch}`).nt.systems);
}

/**
 * @param {'x86'|'x64'} arch
 * @param {number} number numero (SSN) in eax
 * @param {string} version etichetta (es. "Windows 10 22H2") oppure '' per cercare in tutte le versioni
 */
function lookupWindows(arch, number, version) {
    const service = windowsServiceFor(number);
    if (!service) {
        return { status: 'unknown', service: null };
    }
    const table = load(`windows-${arch}`)[service];
    const position = number - table.base;
    const nameAt = (systemIndexes) => {
        const nameIndex = systemIndexes[position];
        return nameIndex === undefined || nameIndex === null ? null : table.names[nameIndex];
    };

    if (version) {
        const indexes = table.systems[version];
        if (!indexes) {
            return { status: 'no-table', service, version };
        }
        const name = nameAt(indexes);
        return name ? { status: 'found', name, service, version } : { status: 'unknown', service, version };
    }

    const byName = new Map();
    for (const [label, indexes] of Object.entries(table.systems)) {
        const name = nameAt(indexes);
        if (name) {
            byName.set(name, [...(byName.get(name) || []), label]);
        }
    }
    if (!byName.size) {
        return { status: 'unknown', service, version: '' };
    }
    const candidates = [...byName.entries()].map(([name, versions]) => ({ name, versions })).sort((a, b) => b.versions.length - a.versions.length);
    return { status: 'candidates', service, candidates, totalVersions: Object.keys(table.systems).length };
}

module.exports = {
    load,
    provenance,
    lookupLinux,
    lookupFreeBsd,
    lookupKolibri,
    lookupWindows,
    windowsVersions,
    windowsVersionsFor
};
