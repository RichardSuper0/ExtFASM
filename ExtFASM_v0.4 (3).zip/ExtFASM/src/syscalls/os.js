'use strict';

const { t } = require('../i18n/i18n');

/**
 * Sistemi operativi noti: come si entra nel kernel (istruzione, vettore, modalità CPU),
 * in quali registri vanno numero e argomenti, e quale tabella dati vale.
 * Le convenzioni derivano dai sorgenti/documenti elencati nel README (sezione "Syscall").
 */

const entry = (spec) => spec;

const OPERATING_SYSTEMS = {
    linux: {
        label: 'Linux',
        mechanisms: [
            entry({
                instruction: 'syscall', modes: [64], table: 'linux-x86_64',
                number: 'rax', args: ['rdi', 'rsi', 'rdx', 'r10', 'r8', 'r9'], result: 'rax',
                note: 'sys.note.linux.syscall'
            }),
            entry({
                instruction: 'int', vector: 0x80, modes: [32, 64], table: 'linux-i386',
                number: 'eax', args: ['ebx', 'ecx', 'edx', 'esi', 'edi', 'ebp'], result: 'eax',
                modeNotes: { 64: 'sys.note.linux.int80.mode64' }
            }),
            entry({
                instruction: 'sysenter', modes: [32], table: 'linux-i386',
                number: 'eax', args: ['ebx', 'ecx', 'edx', 'esi', 'edi', 'ebp'], result: 'eax',
                unverifiable: 'sys.unverifiable.linux.sysenter'
            })
        ]
    },
    freebsd: {
        label: 'FreeBSD',
        mechanisms: [
            entry({
                instruction: 'syscall', modes: [64], table: 'freebsd',
                number: 'rax', args: ['rdi', 'rsi', 'rdx', 'r10', 'r8', 'r9'], result: 'rax',
                note: 'sys.note.freebsd.syscall'
            }),
            entry({
                instruction: 'int', vector: 0x80, modes: [32, 64], table: 'freebsd',
                number: 'eax', args: ['[esp+4]', '[esp+8]', '[esp+12]', '[esp+16]', '[esp+20]', '[esp+24]'], result: 'eax',
                note: 'sys.note.freebsd.int80',
                modeNotes: { 64: 'sys.note.freebsd.int80.mode64' }
            })
        ]
    },
    windows: {
        label: 'Windows',
        mechanisms: [
            entry({
                instruction: 'syscall', modes: [64], table: 'windows', arch: 'x64',
                number: 'eax', args: ['r10 (copia di rcx)', 'rdx', 'r8', 'r9', 'stack'], result: 'eax (NTSTATUS)',
                note: 'sys.note.windows.syscall'
            }),
            entry({
                instruction: 'int', vector: 0x2e, modes: [32, 64], table: 'windows',
                archByMode: { 32: 'x86', 64: 'x64' },
                number: 'eax', args: ['edx (puntatore ai parametri)'], result: 'eax (NTSTATUS)',
                note: 'sys.note.windows.int2e'
            }),
            entry({
                instruction: 'sysenter', modes: [32], table: 'windows', arch: 'x86',
                number: 'eax', args: ['edx (puntatore ai parametri)'], result: 'eax (NTSTATUS)',
                note: 'sys.note.windows.sysenter'
            })
        ]
    },
    kolibrios: {
        label: 'KolibriOS',
        mechanisms: [
            entry({
                instruction: 'int', vector: 0x40, modes: [32], table: 'kolibrios',
                number: 'eax', args: ['ebx', 'ecx', 'edx', 'esi', 'edi', 'ebp'], result: 'eax',
                note: 'sys.note.kolibrios.int40'
            }),
            entry({
                instruction: 'sysenter', modes: [32], table: 'kolibrios',
                number: 'eax', args: ['ebx', 'ecx', 'edx', 'esi', 'edi', 'ebp'], result: 'eax',
                note: 'sys.note.kolibrios.sysenter'
            }),
            entry({
                instruction: 'syscall', modes: [32], table: 'kolibrios',
                number: 'eax', args: ['ebx', 'ecx', 'edx', 'esi', 'edi', 'ebp'], result: 'eax',
                note: 'sys.note.kolibrios.syscall'
            })
        ]
    },
    menuetos: {
        label: 'MenuetOS',
        mechanisms: [
            entry({
                instruction: 'int', vector: 0x60, modes: [32, 64], table: null,
                number: 'rax', args: ['rbx', 'rcx', 'rdx', 'r8', 'r9', 'r10', 'r11'], result: 'rax',
                note: 'sys.note.menuetos.int60'
            }),
            entry({
                instruction: 'syscall', modes: [64], table: null,
                number: 'rax', args: ['rbx', 'rcx', 'rdx', 'r8', 'r9', 'r10', 'r11'], result: 'rax',
                note: 'sys.note.menuetos.syscall'
            }),
            entry({
                instruction: 'int', vector: 0x40, modes: [32], table: null,
                number: 'eax', args: ['ebx', 'ecx', 'edx', 'esi', 'edi', 'ebp'], result: 'eax',
                note: 'sys.note.menuetos.int40'
            })
        ],
        noTableReason: 'sys.noTableReason.menuetos'
    }
};

/** Punti di ingresso che l'analisi considera "chiamate di sistema" (int con altri vettori è ignorato). */
const KNOWN_INTERRUPT_VECTORS = new Map([
    [0x80, 'sys.vector.0x80'],
    [0x2e, 'sys.vector.0x2e'],
    [0x40, 'sys.vector.0x40'],
    [0x60, 'sys.vector.0x60']
]);

/** Destinazione ricavata da un header scritto a mano (db/dw/dd/dq) in un sorgente `format binary`. */
function resolveRawTarget(raw) {
    if (raw.kind === 'menuet64') {
        return { os: 'menuetos', source: 'raw-header', assumed: true, reason: t('sys.target.rawMenuet64') };
    }
    if (raw.kind === 'menuet01' || raw.kind === 'menuet02') {
        return {
            os: 'kolibrios', source: 'raw-header', assumed: true, ambiguousWith: 'menuetos',
            reason: t('sys.target.rawMenuet01', { signature: raw.signature })
        };
    }
    if ((raw.kind === 'elf' || raw.kind === 'elf64') && raw.abi === null) {
        return { os: null, source: 'raw-header', assumed: false, reason: t('sys.target.rawNoOsabi') };
    }
    const inner = resolveTarget({
        format: { kind: raw.kind, executable: raw.executable, abi: raw.abi, abiName: raw.abiName },
        setting: 'auto',
        sourceText: ''
    });
    return { ...inner, source: 'raw-header', reason: t('sys.target.rawPrefix', { reason: inner.reason }) };
}

/**
 * Sceglie il sistema di destinazione.
 * Ordine: impostazione dell'utente > formato/ABI della direttiva `format` > firma del programma.
 * @returns {{os: string|null, source: string, assumed: boolean, reason: string, ambiguousWith?: string}}
 */
function resolveTarget({ format, setting = 'auto', sourceText = '' }) {
    if (setting && setting !== 'auto') {
        if (!OPERATING_SYSTEMS[setting]) {
            return { os: null, source: 'setting', assumed: false, reason: t('sys.target.unknownSetting', { value: setting }) };
        }
        return { os: setting, source: 'setting', assumed: false, reason: t('sys.target.setting') };
    }

    if (format.kind === 'binary' && format.raw) {
        return resolveRawTarget(format.raw);
    }

    switch (format.kind) {
        case 'elf':
        case 'elf64': {
            if (!format.executable) {
                return { os: null, source: 'format', assumed: false, reason: t('sys.target.elfObject') };
            }
            if (format.abi === 3) {
                return { os: 'linux', source: 'abi', assumed: false, reason: t('sys.target.abiLinux') };
            }
            if (format.abi === 0) {
                return { os: 'linux', source: 'abi', assumed: true, reason: t('sys.target.abiSysV') };
            }
            if (format.abi === 9) {
                return { os: 'freebsd', source: 'abi', assumed: false, reason: t('sys.target.abiFreeBsd') };
            }
            return { os: null, source: 'abi', assumed: false, abiName: format.abiName, reason: t('sys.target.abiNoTable', { abi: format.abi, name: format.abiName }) };
        }
        case 'pe':
        case 'pe64':
        case 'coff':
        case 'coff64':
            return { os: 'windows', source: 'format', assumed: false, reason: t('sys.target.format', { kind: format.kind.toUpperCase() }) };
        case 'mz':
            return { os: 'dos', source: 'format', assumed: false, reason: t('sys.target.dos') };
        case 'binary':
        default:
            break;
    }

    if (/['"]MENUET64['"]/.test(sourceText)) {
        return { os: 'menuetos', source: 'signature', assumed: true, reason: t('sys.target.sigMenuet64') };
    }
    if (/['"]MENUET0[12]['"]/.test(sourceText)) {
        return {
            os: 'kolibrios', source: 'signature', assumed: true, ambiguousWith: 'menuetos',
            reason: t('sys.target.sigMenuet01')
        };
    }
    return { os: null, source: 'none', assumed: false, reason: t('sys.target.none') };
}

module.exports = { OPERATING_SYSTEMS, KNOWN_INTERRUPT_VECTORS, resolveTarget };
