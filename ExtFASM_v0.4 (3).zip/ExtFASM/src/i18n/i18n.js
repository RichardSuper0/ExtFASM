'use strict';

/**
 * Traduzione dei testi mostrati dall'estensione (messaggi, avvisi, hover, domande).
 * Lingue: en (predefinita), it, fr, es, pl, de. I cataloghi sono in src/i18n/locales/<lingua>.json e vengono
 * generati da scripts/locales-source.js, dove ogni messaggio ha le sei traduzioni affiancate.
 * La lingua è quella di VS Code (`vscode.env.language`); una lingua non supportata usa l'inglese.
 */

const SUPPORTED = ['en', 'it', 'fr', 'es', 'pl', 'de'];
const catalogs = new Map();
let current = 'en';

function load(language) {
    if (!catalogs.has(language)) {
        catalogs.set(language, require(`./locales/${language}.json`));
    }
    return catalogs.get(language);
}

/** Riduce un codice di lingua di VS Code ('fr', 'pt-br', 'zh-cn', 'de-DE'…) a una lingua supportata. */
function normalizeLanguage(code) {
    const base = String(code || '').toLowerCase().split(/[-_]/)[0];
    return SUPPORTED.includes(base) ? base : 'en';
}

function setLanguage(code) {
    current = normalizeLanguage(code);
    return current;
}

function getLanguage() {
    return current;
}

/**
 * @param {string} key chiave del messaggio
 * @param {Object<string, string|number>} [params] valori per i segnaposto `{nome}`
 */
function t(key, params) {
    const template = load(current)[key] ?? load('en')[key];
    if (template === undefined) {
        return key; // chiave mancante: meglio visibile che vuota (un test verifica che non succeda)
    }
    return template.replace(/\{(\w+)\}/g, (match, name) => (params && params[name] !== undefined ? String(params[name]) : match));
}

/** Tutti i messaggi con un certo prefisso nella lingua corrente (con ripiego sull'inglese): per le interfacce in una webview. */
function messagesWithPrefix(prefix) {
    const result = {};
    for (const [key, value] of Object.entries(load('en'))) {
        if (key.startsWith(prefix)) result[key] = value;
    }
    for (const [key, value] of Object.entries(load(current))) {
        if (key.startsWith(prefix)) result[key] = value;
    }
    return result;
}

module.exports = { t, setLanguage, getLanguage, normalizeLanguage, messagesWithPrefix, SUPPORTED };
