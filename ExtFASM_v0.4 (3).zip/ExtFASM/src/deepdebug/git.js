'use strict';

const { execFile, spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

/**
 * Cronologia Git di un file sorgente (sezione File Commits). Tutto ciò che si mostra viene da `git`:
 *  - asse orizzontale: data del commit (committer date, `%ct`);
 *  - altezza: dimensione in byte del SORGENTE a quel commit (blob), non del binario assemblato
 *    (il binario di solito non è versionato: si riporta solo quello attuale, a parte);
 *  - rinominazioni seguite con `--follow`; commit che cancellano il file sono marcati `D` (nessuna dimensione).
 * Git è eseguito senza shell, senza pager, senza hook né fsmonitor del repository (il repository non è fidato).
 */

const SAFE_ARGS = ['--no-pager', '-c', 'core.fsmonitor=false', '-c', 'core.hooksPath=/dev/null', '-c', 'core.pager=cat', '-c', 'protocol.ext.allow=never'];
const SAFE_ENV = () => ({
    PATH: process.env.PATH,
    HOME: process.env.HOME,
    SYSTEMROOT: process.env.SYSTEMROOT,
    LC_ALL: 'C',
    GIT_OPTIONAL_LOCKS: '0',
    GIT_TERMINAL_PROMPT: '0',
    GIT_CONFIG_NOSYSTEM: '1'
});

function git(gitPath, cwd, args, { timeoutMs = 15000 } = {}) {
    return new Promise((resolve, reject) => {
        execFile(gitPath, [...SAFE_ARGS, ...args], {
            cwd, env: SAFE_ENV(), maxBuffer: 16 * 1024 * 1024, timeout: timeoutMs, windowsHide: true, encoding: 'utf8'
        }, (error, stdout, stderr) => {
            if (error) {
                const failure = new Error(String(stderr || error.message).trim().split(/\r?\n/)[0] || 'git');
                failure.code = error.code;
                reject(failure);
            } else {
                resolve(String(stdout));
            }
        });
    });
}

/** Dimensioni dei blob (`<commit>:<path>`) con una sola esecuzione di `git cat-file --batch-check`. */
function blobSizes(gitPath, cwd, specs) {
    return new Promise((resolve) => {
        if (!specs.length) {
            resolve([]);
            return;
        }
        const child = spawn(gitPath, [...SAFE_ARGS, 'cat-file', '--batch-check'], { cwd, env: SAFE_ENV(), stdio: ['pipe', 'pipe', 'ignore'], windowsHide: true });
        let output = '';
        child.stdout.setEncoding('utf8');
        child.stdout.on('data', (chunk) => { output += chunk; });
        child.once('error', () => resolve(specs.map(() => null)));
        child.once('close', () => {
            const lines = output.split(/\r?\n/);
            resolve(specs.map((_, index) => {
                const match = /^[0-9a-f]+ blob (\d+)$/.exec(lines[index] || '');
                return match ? Number(match[1]) : null;
            }));
        });
        child.stdin.end(`${specs.join('\n')}\n`);
    });
}

/**
 * @returns {Promise<{available:boolean, reason?:string, detail?:string, root?:string, relPath?:string,
 *   commits?:object[], worktree?:object, truncated?:boolean}>}
 *   reason: 'git-missing' | 'not-a-repository' | 'not-tracked' | 'error'
 */
async function readFileHistory({ file, gitPath = 'git', maxCommits = 100, binaryPath = null }) {
    const directory = path.dirname(file);
    let root;
    try {
        root = (await git(gitPath, directory, ['rev-parse', '--show-toplevel'])).trim();
    } catch (error) {
        if (error.code === 'ENOENT') {
            return { available: false, reason: 'git-missing' };
        }
        return { available: false, reason: 'not-a-repository', detail: error.message };
    }
    let realRoot = root;
    let realFile = file;
    try {
        realRoot = fs.realpathSync(root);
        realFile = fs.realpathSync(file);
    } catch { /* il file può non esistere più */ }
    const relPath = path.relative(realRoot, realFile).split(path.sep).join('/');

    let log;
    try {
        log = await git(gitPath, realRoot, [
            'log', '--follow', '--no-ext-diff', '--no-color', '--name-status', '-M', `-n${maxCommits + 1}`,
            '--format=%x1e%H%x1f%ct%x1f%an%x1f%s', '--', relPath
        ]);
    } catch (error) {
        return { available: false, reason: 'error', detail: error.message };
    }

    const records = log.split('\x1e').map((record) => record.trim()).filter(Boolean);
    const commits = records.map((record) => {
        const [header, ...rest] = record.split(/\r?\n/);
        const [hash, time, author, ...subject] = header.split('\x1f');
        const change = rest.map((line) => line.split('\t')).find((parts) => parts[0] && /^[AMDRTC]/.test(parts[0]));
        return {
            hash, shortHash: hash.slice(0, 8), time: Number(time), author, subject: subject.join('\x1f'),
            status: change ? change[0][0] : 'M',
            path: change ? (change[0][0] === 'R' || change[0][0] === 'C' ? change[2] : change[1]) : relPath,
            oldPath: change && (change[0][0] === 'R' || change[0][0] === 'C') ? change[1] : null,
            size: null, delta: null
        };
    });
    const truncated = commits.length > maxCommits;
    if (truncated) commits.pop();

    // Percorso del file a ogni commit (si risale rinominazione per rinominazione) e dimensione del blob.
    const specs = commits.map((commit) => (commit.status === 'D' ? null : `${commit.hash}:${commit.path}`));
    const sizes = await blobSizes(gitPath, realRoot, specs.filter(Boolean));
    let cursor = 0;
    commits.forEach((commit, index) => {
        commit.size = specs[index] ? sizes[cursor++] : null;
    });
    for (let index = 0; index < commits.length; index += 1) {
        const older = commits[index + 1];
        commits[index].delta = commits[index].size !== null && older && older.size !== null ? commits[index].size - older.size : null;
    }

    if (!commits.length) {
        return { available: false, reason: 'not-tracked', root: realRoot, relPath };
    }

    // Stato attuale: file di lavoro e modifiche non ancora committate.
    const worktree = { exists: false, size: null, dirty: false, binarySize: null };
    try {
        worktree.size = fs.statSync(file).size;
        worktree.exists = true;
    } catch { /* cancellato nel working tree */ }
    try {
        worktree.dirty = (await git(gitPath, realRoot, ['status', '--porcelain', '--', relPath])).trim().length > 0;
    } catch { /* lascia false */ }
    if (binaryPath) {
        try {
            worktree.binarySize = fs.statSync(binaryPath).size;
        } catch { /* non ancora assemblato */ }
    }
    return { available: true, root: realRoot, relPath, commits, worktree, truncated };
}

module.exports = { readFileHistory };
