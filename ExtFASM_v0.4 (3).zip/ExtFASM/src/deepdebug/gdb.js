'use strict';

const { spawn, execFile } = require('child_process');
const { EventEmitter } = require('events');
const { parseLine } = require('./mi');

/**
 * Registri della CPU letti da GDB (interfaccia GDB/MI). ExtFASM non inventa nessun valore: mostra solo i registri
 * che GDB espone per il processo e li legge dal processo fermo. Il programma viene eseguito sotto GDB (ptrace),
 * quindi si usa solo dopo un'azione esplicita dell'utente, come per «assembla ed esegui».
 * Verificato con GDB 15.1 su Linux x86-64 (ELF); non è stato provato altrove.
 */

const CORE_X86_64 = ['rax', 'rbx', 'rcx', 'rdx', 'rsi', 'rdi', 'rbp', 'rsp', 'r8', 'r9', 'r10', 'r11', 'r12', 'r13', 'r14', 'r15', 'rip', 'eflags', 'cs', 'ss', 'ds', 'es', 'fs', 'gs', 'fs_base', 'gs_base'];
const CORE_I386 = ['eax', 'ebx', 'ecx', 'edx', 'esi', 'edi', 'ebp', 'esp', 'eip', 'eflags', 'cs', 'ss', 'ds', 'es', 'fs', 'gs'];
const FLAGS = [['CF', 0], ['PF', 2], ['AF', 4], ['ZF', 6], ['SF', 7], ['TF', 8], ['IF', 9], ['DF', 10], ['OF', 11]];
const DEFAULT_TIMEOUT_MS = 10000;

function detectGdb(gdbPath) {
    return new Promise((resolve) => {
        execFile(gdbPath, ['--version'], { timeout: 5000, windowsHide: true }, (error, stdout) => {
            if (error) {
                resolve({ available: false, error: String(error.code || error.message) });
            } else {
                resolve({ available: true, version: String(stdout).split(/\r?\n/)[0].trim() });
            }
        });
    });
}

class GdbSession extends EventEmitter {
    constructor({ gdbPath = 'gdb', binary, cwd, timeoutMs = DEFAULT_TIMEOUT_MS }) {
        super();
        this.gdbPath = gdbPath;
        this.binary = binary;
        this.cwd = cwd;
        this.timeoutMs = timeoutMs;
        this.token = 0;
        this.pending = new Map();
        this.stopWaiters = [];
        this.buffer = '';
        this.names = [];
        this.selected = [];
        this.arch = null;
        this.previous = null;
        this.steps = 0;
        this.exited = null;
        this.closed = false;
        this.status = 'idle';
        this.last = null;
    }

    async start() {
        // --nx: nessun file di init (né quelli del repository); startup-with-shell off: nessuna shell di mezzo.
        this.child = spawn(this.gdbPath, ['--interpreter=mi3', '--nx', '--quiet', '--args', this.binary], {
            cwd: this.cwd, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true
        });
        this.child.stdout.setEncoding('utf8');
        this.child.stdout.on('data', (chunk) => this.onData(chunk));
        this.child.stderr.resume();
        this.child.once('error', (error) => this.finish(String(error.code || error.message)));
        this.child.once('close', () => this.finish(null));

        await this.command('-gdb-set startup-with-shell off');
        await this.command('-gdb-set disable-randomization on');
        await this.command('-gdb-set disassembly-flavor intel');
        await this.command('-gdb-set inferior-tty /dev/null'); // l'output del programma non si mescola con quello di GDB
        const names = await this.command('-data-list-register-names');
        this.names = names.results['register-names'] || [];
        this.arch = this.names.includes('rip') ? 'x86-64' : this.names.includes('eip') ? 'i386' : null;
        if (!this.arch) {
            throw new Error('unsupported-architecture');
        }
        const wanted = this.arch === 'x86-64' ? CORE_X86_64 : CORE_I386;
        this.selected = wanted.map((name) => ({ name, index: this.names.indexOf(name) })).filter((item) => item.index >= 0);

        await this.runUntilStop('-interpreter-exec console starti');
        return this.snapshot();
    }

    onData(chunk) {
        this.buffer += chunk;
        let newline;
        while ((newline = this.buffer.indexOf('\n')) >= 0) {
            const line = this.buffer.slice(0, newline).replace(/\r$/, '');
            this.buffer = this.buffer.slice(newline + 1);
            const record = parseLine(line);
            if (!record) continue;
            if (record.kind === 'result' && record.token !== null && this.pending.has(record.token)) {
                const { resolve, reject, timer } = this.pending.get(record.token);
                clearTimeout(timer);
                this.pending.delete(record.token);
                if (record.klass === 'error') {
                    reject(new Error(String(record.results.msg || 'gdb error')));
                } else {
                    resolve(record);
                }
            } else if (record.kind === 'exec' && record.klass === 'stopped') {
                this.onStopped(record.results);
            }
        }
    }

    onStopped(results) {
        const reason = results.reason;
        if (reason === 'exited' || reason === 'exited-normally' || reason === 'exited-signalled') {
            this.exited = {
                reason,
                code: reason === 'exited-normally' ? 0 : results['exit-code'] !== undefined ? parseInt(results['exit-code'], 8) : null,
                signal: results['signal-name'] || null
            };
            this.status = 'ended';
        } else {
            this.status = 'stopped';
        }
        const waiters = this.stopWaiters;
        this.stopWaiters = [];
        waiters.forEach((resolve) => resolve(results));
        this.emit('stopped', results);
    }

    finish(error) {
        if (this.closed) return;
        this.closed = true;
        if (this.status !== 'ended') this.status = error ? 'error' : 'closed';
        const failure = new Error(error || 'gdb-closed');
        for (const { reject, timer } of this.pending.values()) {
            clearTimeout(timer);
            reject(failure);
        }
        this.pending.clear();
        this.stopWaiters.forEach((resolve) => resolve({ reason: 'closed' }));
        this.stopWaiters = [];
        this.emit('closed', { error });
    }

    command(text) {
        return new Promise((resolve, reject) => {
            if (this.closed || !this.child || !this.child.stdin.writable) {
                reject(new Error('gdb-closed'));
                return;
            }
            this.token += 1;
            const token = this.token;
            const timer = setTimeout(() => {
                this.pending.delete(token);
                reject(new Error('gdb-timeout'));
            }, this.timeoutMs);
            this.pending.set(token, { resolve, reject, timer });
            this.child.stdin.write(`${token}${text}\n`);
        });
    }

    /** Esegue un comando che fa ripartire il processo e attende il prossimo arresto. */
    async runUntilStop(text, timeoutMs = this.timeoutMs) {
        const stopped = new Promise((resolve) => this.stopWaiters.push(resolve));
        await this.command(text);
        let timer;
        const timeout = new Promise((resolve) => { timer = setTimeout(() => resolve({ reason: 'timeout' }), timeoutMs); });
        const result = await Promise.race([stopped, timeout]);
        clearTimeout(timer);
        if (result.reason === 'timeout') {
            this.stop();
        }
        return result;
    }

    async step(count = 1) {
        let result = null;
        for (let index = 0; index < count && this.status === 'stopped'; index += 1) {
            result = await this.runUntilStop('-exec-step-instruction');
            this.steps += 1;
        }
        return this.snapshot(result);
    }

    async continueRun(timeoutMs = this.timeoutMs) {
        const result = await this.runUntilStop('-exec-continue', timeoutMs);
        return this.snapshot(result);
    }

    /**
     * Stato corrente. `status`: 'live' (processo fermo sotto GDB, valori letti adesso), 'snapshot' (il processo è
     * terminato o la sessione è chiusa: restano gli ultimi valori letti), 'unavailable' (mai letti).
     */
    async snapshot(stopInfo = null) {
        if (this.status !== 'stopped') {
            const base = this.last ? { ...this.last, registers: this.last.registers.map((item) => ({ ...item, changed: false })) } : null;
            return {
                ...(base || { arch: this.arch, registers: [], flags: [], pc: null, sp: null, instruction: null }),
                status: base ? 'snapshot' : 'unavailable',
                exit: this.exited,
                stop: stopInfo ? stopInfo.reason || null : null,
                steps: this.steps
            };
        }
        const indexes = this.selected.map((item) => item.index);
        const response = await this.command(`-data-list-register-values x ${indexes.join(' ')}`);
        const values = new Map();
        for (const entry of response.results['register-values'] || []) {
            values.set(Number(entry.number), BigInt(entry.value));
        }
        const registers = this.selected
            .filter((item) => values.has(item.index))
            .map((item) => {
                const value = values.get(item.index);
                const before = this.previous ? this.previous.get(item.name) : undefined;
                return { name: item.name, value, hex: `0x${value.toString(16)}`, decimal: value.toString(10), changed: before !== undefined && before !== value };
            });
        const byName = new Map(registers.map((item) => [item.name, item]));
        const pcName = this.arch === 'x86-64' ? 'rip' : 'eip';
        const spName = this.arch === 'x86-64' ? 'rsp' : 'esp';
        const flagsRegister = byName.get('eflags');
        const previousFlags = this.previous ? this.previous.get('eflags') : undefined;
        const flags = flagsRegister ? FLAGS.map(([name, bit]) => {
            const set = ((flagsRegister.value >> BigInt(bit)) & 1n) === 1n;
            const was = previousFlags === undefined ? set : ((previousFlags >> BigInt(bit)) & 1n) === 1n;
            return { name, set, changed: previousFlags !== undefined && was !== set };
        }) : [];

        let instruction = null;
        const pc = byName.get(pcName);
        if (pc) {
            try {
                const disassembly = await this.command(`-data-disassemble -s 0x${pc.value.toString(16)} -e 0x${(pc.value + 1n).toString(16)} -- 0`);
                const first = (disassembly.results.asm_insns || [])[0];
                if (first) {
                    instruction = { address: first.address, text: String(first.inst).replace(/\s+/g, ' ').trim() };
                }
            } catch {
                instruction = null;
            }
        }
        this.previous = new Map(registers.map((item) => [item.name, item.value]));
        this.last = { arch: this.arch, registers, flags, pc: pc ? { name: pcName, hex: pc.hex } : null, sp: byName.get(spName) ? { name: spName, hex: byName.get(spName).hex } : null, instruction };
        return { ...this.last, status: 'live', exit: null, stop: stopInfo ? stopInfo.reason || null : null, steps: this.steps };
    }

    stop() {
        if (this.closed) return;
        try {
            this.child.stdin.write('-gdb-exit\n');
            this.child.stdin.end();
        } catch { /* già chiuso */ }
        const killer = setTimeout(() => this.child.kill('SIGKILL'), 1500);
        killer.unref();
        this.child.once('close', () => clearTimeout(killer));
        if (this.status === 'stopped') this.status = 'closed';
    }
}

module.exports = { GdbSession, detectGdb };
