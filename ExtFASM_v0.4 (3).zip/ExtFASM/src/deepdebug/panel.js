'use strict';

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { t, getLanguage, messagesWithPrefix } = require('../i18n/i18n');
const { debuggerHtml } = require('../ui/debuggerView');
const { readFileHistory } = require('./git');
const { buildErrorList } = require('./errors');
const { describeHardware, snapshotDirectory, diffSnapshots } = require('./resources');
const { GdbSession, detectGdb } = require('./gdb');
const { detectFormat, nativePlatform } = require('../analysis/formats');

/**
 * Pannello «Apri Debugger»: quattro sezioni con dati reali (File Commits, File Errors, Resources & Performance,
 * CPU Registers). Questo modulo collega la vista (webview) ai moduli di raccolta dati; tutto ciò che dipende
 * da VS Code arriva da `host`, così il comportamento si prova senza VS Code.
 *
 * host: {
 *   settings(uri) -> {get(key, default)}, isTrusted() -> bool, activeDocument() -> document|null,
 *   diagnostics(document) -> {assembler, static, syscall}, lastRun(document) -> {exitCode, signal, error}|null,
 *   outputPathFor(document) -> string|null, assemble(document) -> Promise<{outputPath, format}|null>,
 *   confirmRun(document, outputPath) -> Promise<boolean>,
 *   runMeasured(document, format, outputPath, {intervalMs}) -> Promise<object|null>, reveal(uri, line, column)
 * }
 */

class DebuggerPanel {
    constructor({ vscode, host }) {
        this.vscode = vscode;
        this.host = host;
        this.panel = null;
        this.document = null;
        this.session = null;
        this.registers = { busy: false, error: null, snapshot: null, unsupported: null, gdb: null };
        this.report = null;
        this.running = false;
        this.tab = 'commits';
        this.ready = false;
    }

    /** Apre (o porta in primo piano) il pannello per il documento dato. */
    open(document) {
        const config = this.host.settings(document ? document.uri : undefined);
        if (!config.get('deepDebug.enabled', true)) {
            this.vscode.window.showInformationMessage(t('dbg.disabled'));
            return null;
        }
        this.document = document || this.document;
        if (this.panel) {
            this.panel.reveal(this.vscode.ViewColumn.Beside);
            this.refreshAll();
            return this.panel;
        }
        this.panel = this.vscode.window.createWebviewPanel('fasm1Debugger', t('panel.debugger'), this.vscode.ViewColumn.Beside, {
            enableScripts: true, retainContextWhenHidden: true, localResourceRoots: []
        });
        this.panel.webview.html = debuggerHtml({ nonce: crypto.randomBytes(16).toString('base64').replace(/[^A-Za-z0-9]/g, ''), language: getLanguage() });
        this.panel.webview.onDidReceiveMessage((message) => this.onMessage(message));
        this.panel.onDidDispose(() => {
            this.stopSession();
            this.panel = null;
            this.ready = false;
        });
        return this.panel;
    }

    post(type, data) {
        if (this.panel && this.ready) {
            this.panel.webview.postMessage({ type, data });
        }
    }

    setDocument(document) {
        if (!document || (this.document && this.document.uri.toString() === document.uri.toString())) {
            return;
        }
        this.document = document;
        this.stopSession();
        this.report = null;
        this.registers = { busy: false, error: null, snapshot: null, unsupported: null, gdb: this.registers.gdb };
        this.refreshAll();
    }

    async onMessage(message) {
        try {
            switch (message && message.command) {
                case 'ready':
                    this.ready = true;
                    this.panel.webview.postMessage({ type: 'init', labels: messagesWithPrefix('dbg.'), locale: getLanguage(), tab: this.tab });
                    this.refreshAll();
                    break;
                case 'tab': this.tab = ['commits', 'errors', 'resources', 'registers'].includes(message.tab) ? message.tab : this.tab; break;
                case 'refreshCommits': await this.refreshCommits(); break;
                case 'refreshResources': await this.refreshResources(); break;
                case 'goto': this.goto(Number(message.line), Number(message.column)); break;
                case 'measure': await this.measure(); break;
                case 'regStart': await this.startSession(); break;
                case 'regStep': await this.step(Number(message.count) === 10 ? 10 : 1); break;
                case 'regContinue': await this.continueRun(); break;
                case 'regStop': this.stopSession(true); break;
                default: break;
            }
        } catch (error) {
            this.registers = { ...this.registers, busy: false, error: String(error && error.message || error) };
            this.running = false;
            this.postRegisters();
            this.postResources();
        }
    }

    goto(line, column) {
        if (this.document && Number.isInteger(line) && line >= 0) {
            this.host.reveal(this.document.uri, line, Number.isInteger(column) && column >= 0 ? column : 0);
        }
    }

    refreshAll() {
        this.post('file', undefined);
        if (this.panel && this.ready) {
            this.panel.webview.postMessage({ type: 'file', name: this.document ? path.basename(this.document.uri.fsPath) : null });
        }
        if (!this.document) return;
        this.refreshErrors();
        this.refreshCommits();
        this.refreshResources();
        this.refreshRegisterSupport();
    }

    // -- File Errors ---------------------------------------------------------------------------------------
    refreshErrors() {
        if (!this.document) return;
        const diagnostics = this.host.diagnostics(this.document);
        this.post('errors', { items: buildErrorList({ ...diagnostics, run: this.host.lastRun(this.document) }) });
    }

    // -- File Commits --------------------------------------------------------------------------------------
    async refreshCommits() {
        if (!this.document) return;
        const config = this.host.settings(this.document.uri);
        if (!this.host.isTrusted()) {
            this.post('commits', { available: false, reason: 'untrusted' });
            return;
        }
        const history = await readFileHistory({
            file: this.document.uri.fsPath,
            maxCommits: config.get('deepDebug.maxCommits', 100),
            binaryPath: this.host.outputPathFor(this.document)
        });
        this.post('commits', history);
    }

    // -- Resources & Performance ---------------------------------------------------------------------------
    async refreshResources() {
        if (!this.document) return;
        const file = this.document.uri.fsPath;
        const outputPath = this.host.outputPathFor(this.document);
        const sizeOf = (target) => {
            try {
                return target ? fs.statSync(target).size : null;
            } catch {
                return null;
            }
        };
        this.resourceBase = {
            hardware: await describeHardware(path.dirname(outputPath || file)),
            sourceSize: sizeOf(file),
            binarySize: sizeOf(outputPath),
            intervalMs: this.host.settings(this.document.uri).get('deepDebug.sampleIntervalMs', 100)
        };
        this.postResources();
    }

    postResources() {
        if (this.resourceBase) {
            this.post('resources', { ...this.resourceBase, report: this.report, running: this.running });
        }
    }

    async measure() {
        if (!this.document || this.running) return;
        this.running = true;
        this.postResources();
        try {
            const built = await this.host.assemble(this.document);
            if (!built) return;
            const report = await this.host.runMeasured(this.document, built.format, built.outputPath, { intervalMs: this.resourceBase ? this.resourceBase.intervalMs : 100 });
            if (report) {
                this.report = report;
            }
        } finally {
            this.running = false;
            await this.refreshResources();
            this.refreshErrors();
        }
    }

    // -- CPU Registers -------------------------------------------------------------------------------------
    registerSupport() {
        if (!this.document) return { key: 'dbg.noFile', params: {} };
        const format = detectFormat(this.document.getText());
        if (process.platform !== 'linux') return { key: 'dbg.reg.unsupported.platform', params: {} };
        if (nativePlatform(format) !== 'linux') return { key: 'dbg.reg.unsupported.format', params: { format: format.kind.toUpperCase() } };
        return null;
    }

    async refreshRegisterSupport() {
        const unsupported = this.registerSupport();
        this.registers = { ...this.registers, unsupported };
        if (!unsupported) {
            const gdbPath = 'gdb';
            this.registers.gdb = await detectGdb(gdbPath);
            if (!this.registers.gdb.available) {
                this.registers.unsupported = { key: 'dbg.reg.unsupported.gdb', params: { error: this.registers.gdb.error } };
            }
        }
        this.postRegisters();
    }

    postRegisters() {
        const snapshot = this.registers.snapshot;
        this.post('registers', {
            ...this.registers,
            snapshot: snapshot ? {
                ...snapshot,
                registers: snapshot.registers.map((item) => ({ name: item.name, hex: item.hex, decimal: item.decimal, changed: item.changed }))
            } : null
        });
    }

    async startSession() {
        if (this.registers.busy || !this.document) return;
        const unsupported = this.registerSupport();
        if (unsupported || !this.registers.gdb || !this.registers.gdb.available) {
            await this.refreshRegisterSupport();
            return;
        }
        this.stopSession();
        this.registers = { ...this.registers, busy: true, error: null, snapshot: null };
        this.postRegisters();
        try {
            const built = await this.host.assemble(this.document);
            if (!built) return;
            if (!(await this.host.confirmRun(this.document, built.outputPath))) return;
            const gdbPath = 'gdb';
            this.session = new GdbSession({ gdbPath, binary: built.outputPath, cwd: path.dirname(built.outputPath) });
            this.registers.snapshot = await this.session.start();
        } catch (error) {
            this.stopSession();
            this.registers.error = error.message === 'unsupported-architecture' ? t('dbg.reg.unsupported.arch') : t('dbg.reg.failed', { error: error.message });
        } finally {
            this.registers.busy = false;
            this.postRegisters();
        }
    }

    async withSession(action) {
        if (!this.session || this.registers.busy) return;
        this.registers = { ...this.registers, busy: true, error: null };
        this.postRegisters();
        try {
            this.registers.snapshot = await action(this.session);
        } catch (error) {
            this.registers.error = t('dbg.reg.failed', { error: error.message });
        } finally {
            this.registers.busy = false;
            this.postRegisters();
        }
    }

    step(count) {
        return this.withSession((session) => session.step(count));
    }

    continueRun() {
        return this.withSession((session) => session.continueRun(10000));
    }

    stopSession(refresh = false) {
        if (this.session) {
            const last = this.session.last;
            this.session.stop();
            this.session = null;
            if (last) {
                this.registers.snapshot = { ...last, status: 'snapshot', exit: null, stop: null, steps: this.registers.snapshot ? this.registers.snapshot.steps : 0 };
            }
        }
        if (refresh) this.postRegisters();
    }
}

module.exports = { DebuggerPanel };
