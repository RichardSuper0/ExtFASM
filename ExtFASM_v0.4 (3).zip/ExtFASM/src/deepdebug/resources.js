'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFile, execFileSync } = require('child_process');

/**
 * Risorse (sezione Resources & Performance). Quattro tipi di dato, tenuti separati:
 *   A. statico   dimensione di sorgente e binario;
 *   B. dinamico  consumo del processo durante l'esecuzione (campionato da /proc su Linux);
 *   C. osservato prestazioni di QUESTA esecuzione (non un punteggio di potenza né un requisito minimo);
 *   D. hardware  caratteristiche del componente, come le espone il sistema.
 * Ogni metrica ha uno stato: 'ok' | 'not-measurable' | 'not-supported' | 'absent' | 'undetectable'.
 * Solo Linux è implementato e verificato; altrove il campionamento per processo risulta `not-supported`.
 */

const PCI_VENDORS = { 0x10de: 'NVIDIA', 0x1002: 'AMD', 0x8086: 'Intel', 0x1af4: 'Red Hat (virtio)', 0x15ad: 'VMware', 0x1234: 'QEMU/Bochs', 0x1414: 'Microsoft' };

const readText = (file) => {
    try {
        return fs.readFileSync(file, 'utf8');
    } catch {
        return null;
    }
};

// ---------------------------------------------------------------------------------------------------------
// D. Hardware
// ---------------------------------------------------------------------------------------------------------

function describeCpu() {
    const cpus = os.cpus() || [];
    const info = { status: cpus.length ? 'ok' : 'undetectable', model: cpus[0] ? cpus[0].model.trim() : null, logicalCores: cpus.length || null, physicalCores: null, architecture: os.arch(), frequencyMHz: null, frequencySource: null };
    if (process.platform === 'linux') {
        const text = readText('/proc/cpuinfo');
        if (text) {
            const pairs = new Set();
            let physical = null;
            let core = null;
            for (const line of text.split('\n')) {
                const [key, value] = line.split(':').map((part) => part && part.trim());
                if (key === 'physical id') physical = value;
                if (key === 'core id') core = value;
                if (line.trim() === '' && core !== null) {
                    pairs.add(`${physical}/${core}`);
                    physical = null;
                    core = null;
                }
            }
            if (pairs.size) info.physicalCores = pairs.size;
        }
        const current = readText('/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq');
        if (current && /^\d+/.test(current)) {
            info.frequencyMHz = Math.round(Number(current) / 1000);
            info.frequencySource = 'cpufreq';
        }
    }
    return info;
}

function describeRam() {
    return { status: 'ok', totalBytes: os.totalmem(), availableBytes: os.freemem(), scope: 'system' };
}

function listDirectory(directory) {
    try {
        return fs.readdirSync(directory);
    } catch {
        return null;
    }
}

function describeGpu() {
    if (process.platform !== 'linux') {
        return { status: 'undetectable', devices: [] };
    }
    const entries = listDirectory('/sys/class/drm');
    if (entries === null) {
        return { status: 'undetectable', devices: [] };
    }
    const devices = entries.filter((name) => /^card\d+$/.test(name)).map((name) => {
        const base = `/sys/class/drm/${name}/device`;
        const vendor = parseInt((readText(`${base}/vendor`) || '').trim(), 16);
        const device = parseInt((readText(`${base}/device`) || '').trim(), 16);
        let driver = null;
        try {
            driver = path.basename(fs.readlinkSync(`${base}/driver`));
        } catch { /* nessun driver */ }
        return {
            name,
            vendor: Number.isFinite(vendor) ? (PCI_VENDORS[vendor] || `PCI 0x${vendor.toString(16)}`) : null,
            vendorId: Number.isFinite(vendor) ? vendor : null,
            deviceId: Number.isFinite(device) ? device : null,
            driver,
            model: null, memoryTotalMiB: null, memoryUsedMiB: null, utilizationPercent: null
        };
    });
    return { status: devices.length ? 'ok' : 'absent', devices };
}

/** Per le GPU NVIDIA, se esiste `nvidia-smi`, aggiunge nome, memoria e utilizzo DEL SISTEMA (non del programma). */
function enrichNvidia(gpu) {
    return new Promise((resolve) => {
        if (!gpu.devices.some((device) => device.vendorId === 0x10de)) {
            resolve(gpu);
            return;
        }
        execFile('nvidia-smi', ['--query-gpu=name,memory.total,memory.used,utilization.gpu', '--format=csv,noheader,nounits'], { timeout: 4000, windowsHide: true }, (error, stdout) => {
            if (!error) {
                const rows = String(stdout).trim().split(/\r?\n/).map((line) => line.split(',').map((part) => part.trim()));
                gpu.devices.filter((device) => device.vendorId === 0x10de).forEach((device, index) => {
                    const row = rows[index];
                    if (row && row.length >= 4) {
                        [device.model] = row;
                        device.memoryTotalMiB = Number(row[1]);
                        device.memoryUsedMiB = Number(row[2]);
                        device.utilizationPercent = Number(row[3]);
                    }
                });
            }
            resolve(gpu);
        });
    });
}

function describeNpu() {
    if (process.platform !== 'linux') {
        return { status: 'undetectable', devices: [] };
    }
    const entries = listDirectory('/sys/class/accel');
    if (entries === null) {
        return { status: 'undetectable', devices: [] }; // senza il sottosistema accel non si può dire se esista una NPU
    }
    const devices = entries.filter((name) => /^accel\d+$/.test(name)).map((name) => {
        let driver = null;
        try {
            driver = path.basename(fs.readlinkSync(`/sys/class/accel/${name}/device/driver`));
        } catch { /* nessun driver */ }
        return { name, driver };
    });
    return { status: devices.length ? 'ok' : 'absent', devices };
}

function describeDisk(directory) {
    try {
        const stats = fs.statfsSync(directory);
        return { status: 'ok', totalBytes: stats.blocks * stats.bsize, freeBytes: stats.bavail * stats.bsize };
    } catch {
        return { status: 'undetectable', totalBytes: null, freeBytes: null };
    }
}

async function describeHardware(directory) {
    return {
        platform: process.platform,
        cpu: describeCpu(),
        ram: describeRam(),
        gpu: await enrichNvidia(describeGpu()),
        npu: describeNpu(),
        disk: describeDisk(directory)
    };
}

// ---------------------------------------------------------------------------------------------------------
// B/C. Campionamento del processo (Linux, /proc)
// ---------------------------------------------------------------------------------------------------------

let clockTicks = null;
function clockTicksPerSecond() {
    if (clockTicks === null) {
        try {
            clockTicks = { value: Number(execFileSync('getconf', ['CLK_TCK'], { encoding: 'utf8', timeout: 2000 }).trim()), verified: true };
        } catch {
            clockTicks = { value: 100, verified: false };
        }
        if (!(clockTicks.value > 0)) clockTicks = { value: 100, verified: false };
    }
    return clockTicks;
}

function readProcStat(pid) {
    const text = readText(`/proc/${pid}/stat`);
    if (!text) return null;
    const fields = text.slice(text.lastIndexOf(')') + 2).split(' ');
    return { utime: Number(fields[11]), stime: Number(fields[12]), cutime: Number(fields[13]), cstime: Number(fields[14]) };
}

function readProcStatus(pid) {
    const text = readText(`/proc/${pid}/status`);
    if (!text) return null;
    const pick = (key) => {
        const match = new RegExp(`^${key}:\\s+(\\d+)`, 'm').exec(text);
        return match ? Number(match[1]) : null;
    };
    return { rssKb: pick('VmRSS'), peakRssKb: pick('VmHWM'), virtualKb: pick('VmSize'), threads: pick('Threads') };
}

function readProcIo(pid) {
    const text = readText(`/proc/${pid}/io`);
    if (!text) return null;
    const pick = (key) => {
        const match = new RegExp(`^${key}:\\s+(\\d+)`, 'm').exec(text);
        return match ? Number(match[1]) : null;
    };
    return { readBytes: pick('read_bytes'), writeBytes: pick('write_bytes'), readChars: pick('rchar'), writeChars: pick('wchar'), readCalls: pick('syscr'), writeCalls: pick('syscw') };
}

/** Tempo CPU dei figli già terminati del processo corrente: serve come limite superiore (può includere altri figli dell'extension host). */
function childrenCpuMs() {
    const stat = readProcStat('self');
    if (!stat) return null;
    const { value } = clockTicksPerSecond();
    return ((stat.cutime + stat.cstime) * 1000) / value;
}

class ProcessSampler {
    /**
     * @param {{pid:number, executable:string, intervalMs?:number}} options
     * `executable`: il campione vale solo quando /proc/<pid>/exe è davvero il programma (subito dopo fork il
     * processo è ancora una copia di Node: quei valori non sarebbero del programma).
     */
    constructor({ pid, executable, intervalMs = 100 }) {
        this.pid = pid;
        this.intervalMs = Math.max(10, intervalMs);
        this.supported = process.platform === 'linux';
        try {
            this.executable = fs.realpathSync(executable);
        } catch {
            this.executable = executable;
        }
        this.series = [];
        this.started = Date.now();
        this.overheadNs = 0n;
        this.attempts = 0;
        this.peakRssKb = null;
        this.io = null;
        this.lastCpuMs = null;
        this.timer = null;
        this.stopped = false;
        this.childrenBefore = this.supported ? childrenCpuMs() : null;
    }

    start() {
        if (!this.supported) return;
        const tick = () => {
            if (this.stopped) return;
            this.sample();
            this.timer = setTimeout(tick, this.intervalMs);
        };
        this.sample();
        this.timer = setTimeout(tick, this.intervalMs);
    }

    sample() {
        const begin = process.hrtime.bigint();
        this.attempts += 1;
        try {
            let exe = null;
            try {
                exe = fs.readlinkSync(`/proc/${this.pid}/exe`);
            } catch { /* processo finito */ }
            if (exe === this.executable || (exe && exe.replace(/ \(deleted\)$/, '') === this.executable)) {
                const stat = readProcStat(this.pid);
                const status = readProcStatus(this.pid);
                const io = readProcIo(this.pid);
                if (stat && status) {
                    const { value } = clockTicksPerSecond();
                    this.lastCpuMs = ((stat.utime + stat.stime) * 1000) / value;
                    this.userMs = (stat.utime * 1000) / value;
                    this.systemMs = (stat.stime * 1000) / value;
                    this.series.push({ t: Date.now() - this.started, cpuMs: this.lastCpuMs, rssKb: status.rssKb, threads: status.threads });
                    this.peakRssKb = Math.max(this.peakRssKb || 0, status.peakRssKb || 0, status.rssKb || 0);
                    this.virtualKb = status.virtualKb;
                    if (io) this.io = io;
                }
            }
        } finally {
            this.overheadNs += process.hrtime.bigint() - begin;
        }
    }

    /** @param {{wallMs:number}} run */
    finish(run) {
        this.stopped = true;
        clearTimeout(this.timer);
        const childrenAfter = this.supported ? childrenCpuMs() : null;
        const ticks = clockTicksPerSecond();
        const samples = this.series.length;
        const lastT = samples ? this.series[samples - 1].t : null;
        return {
            supported: this.supported,
            intervalMs: this.intervalMs,
            wallMs: run.wallMs,
            samples,
            attempts: this.attempts,
            overheadMs: Number(this.overheadNs) / 1e6,
            clockTicksVerified: ticks.verified,
            cpu: {
                status: !this.supported ? 'not-supported' : samples ? 'ok' : 'not-measurable',
                sampledCpuMs: samples ? this.lastCpuMs : null,
                userMs: samples ? this.userMs : null,
                systemMs: samples ? this.systemMs : null,
                averagePercentOfOneCore: samples && lastT > 0 ? Math.min(this.lastCpuMs / lastT * 100, 100 * (os.cpus().length || 1)) : null,
                upperBoundMs: this.childrenBefore !== null && childrenAfter !== null ? Math.max(0, childrenAfter - this.childrenBefore) : null
            },
            memory: {
                status: !this.supported ? 'not-supported' : samples ? 'ok' : 'not-measurable',
                peakRssKb: samples ? this.peakRssKb : null,
                lastRssKb: samples ? this.series[samples - 1].rssKb : null,
                virtualKb: samples ? this.virtualKb : null
            },
            io: { status: !this.supported ? 'not-supported' : this.io ? 'ok' : 'not-measurable', ...(this.io || {}) },
            series: this.series
        };
    }
}

// ---------------------------------------------------------------------------------------------------------
// A. File creati/modificati/eliminati durante la prova
// ---------------------------------------------------------------------------------------------------------

const SKIP_DIRECTORIES = new Set(['.git', 'node_modules']);

function snapshotDirectory(root, { maxEntries = 2000, maxDepth = 3 } = {}) {
    const result = new Map();
    let truncated = false;
    const walk = (directory, depth) => {
        let entries;
        try {
            entries = fs.readdirSync(directory, { withFileTypes: true });
        } catch {
            return;
        }
        for (const entry of entries) {
            if (result.size >= maxEntries) {
                truncated = true;
                return;
            }
            const full = path.join(directory, entry.name);
            if (entry.isDirectory()) {
                if (depth < maxDepth && !SKIP_DIRECTORIES.has(entry.name)) walk(full, depth + 1);
            } else if (entry.isFile()) {
                try {
                    const stats = fs.statSync(full);
                    result.set(path.relative(root, full), { size: stats.size, mtimeMs: stats.mtimeMs });
                } catch { /* sparito nel frattempo */ }
            }
        }
    };
    walk(root, 0);
    return { files: result, truncated };
}

function diffSnapshots(before, after) {
    const created = [];
    const modified = [];
    const deleted = [];
    for (const [file, info] of after.files) {
        const old = before.files.get(file);
        if (!old) created.push({ file, size: info.size });
        else if (old.size !== info.size || old.mtimeMs !== info.mtimeMs) modified.push({ file, size: info.size, previousSize: old.size });
    }
    for (const file of before.files.keys()) {
        if (!after.files.has(file)) deleted.push({ file });
    }
    return { created, modified, deleted, truncated: before.truncated || after.truncated };
}

module.exports = { describeHardware, describeCpu, describeRam, describeGpu, describeNpu, describeDisk, ProcessSampler, snapshotDirectory, diffSnapshots, PCI_VENDORS };
