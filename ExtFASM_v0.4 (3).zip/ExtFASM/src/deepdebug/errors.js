'use strict';

const { t } = require('../i18n/i18n');

/**
 * Elenco unico degli errori di un file (sezione File Errors), con l'ORIGINE sempre dichiarata:
 *   assembler  messaggio del vero fasm (riga sì, colonna no);
 *   static     analisi statica di ExtFASM (posizione esatta, ma non è l'assemblatore);
 *   syscall    controllo delle syscall sulle tabelle di riferimento;
 *   runtime    problema osservato durante l'esecuzione (nessuna posizione nel sorgente).
 * Gli errori di compilazione e quelli del programma in esecuzione non si mescolano senza dirlo.
 */

const ORIGINS = ['assembler', 'static', 'syscall', 'runtime'];
const SEVERITY_ORDER = { error: 0, warning: 1, information: 2, hint: 3 };

/** vscode.DiagnosticSeverity (0 Error, 1 Warning, 2 Information, 3 Hint) -> nome. */
const severityName = (value) => (typeof value === 'string' ? value : ['error', 'warning', 'information', 'hint'][value] || 'warning');

function fromDiagnostics(origin, diagnostics) {
    return (diagnostics || []).map((item) => {
        const range = item.range || {};
        const startLine = range.start ? range.start.line : range.startLine;
        const startColumn = range.start ? range.start.character : range.startCharacter;
        const code = item.code && typeof item.code === 'object' ? item.code.value : item.code;
        return {
            origin,
            severity: severityName(item.severity),
            line: startLine + 1,
            // fasm indica solo la riga: la colonna dell'assemblatore sarebbe solo l'inizio dell'evidenziazione
            column: origin === 'assembler' ? null : startColumn + 1,
            message: String(item.message),
            category: code ? String(code) : null
        };
    });
}

/** Problema del programma in esecuzione (da `{exitCode, signal, error}` dell'ultima prova). */
function runtimeItems(run) {
    if (!run) return [];
    const base = { origin: 'runtime', severity: 'error', line: null, column: null, category: null };
    if (run.error) {
        return [{ ...base, message: t('dbg.errors.runtimeSpawn', { error: run.error }), category: 'spawn' }];
    }
    if (run.signal) {
        return [{ ...base, message: t('dbg.errors.runtimeSignal', { signal: run.signal }), category: run.signal }];
    }
    if (run.exitCode) {
        return [{ ...base, severity: 'warning', message: t('dbg.errors.runtimeExit', { code: run.exitCode }), category: 'exit-code' }];
    }
    return [];
}

function reasonOf(item) {
    return t(`dbg.errors.reason.${item.origin}`, { category: item.category || '—' });
}

/**
 * @param {{assembler?:object[], static?:object[], syscall?:object[], run?:object|null}} sources
 * @returns {object[]} voci con `reason`, ordinate per origine, riga e gravità
 */
function buildErrorList(sources) {
    const items = [
        ...fromDiagnostics('assembler', sources.assembler),
        ...fromDiagnostics('static', sources.static),
        ...fromDiagnostics('syscall', sources.syscall),
        ...runtimeItems(sources.run)
    ];
    items.sort((a, b) => ORIGINS.indexOf(a.origin) - ORIGINS.indexOf(b.origin)
        || (a.line ?? 1e9) - (b.line ?? 1e9)
        || SEVERITY_ORDER[a.severity] - SEVERITY_ORDER[b.severity]);
    return items.map((item) => ({ ...item, reason: reasonOf(item) }));
}

module.exports = { buildErrorList, fromDiagnostics, runtimeItems, ORIGINS };
