'use strict';

/**
 * Parser minimo dell'output GDB/MI (https://sourceware.org/gdb/current/onlinedocs/gdb.html/GDB_002fMI-Output-Syntax.html).
 * Una riga è: [token]^risultato | *asincrono | ~console | @target | &log, con valori
 * c-string, tuple {k=v,...} e liste [v,...] / [k=v,...].
 */

function parseCString(text, start) {
    let result = '';
    let index = start + 1;
    while (index < text.length && text[index] !== '"') {
        if (text[index] === '\\') {
            index += 1;
            const escape = text[index];
            const map = { n: '\n', t: '\t', '"': '"', '\\': '\\', r: '\r' };
            if (escape in map) {
                result += map[escape];
            } else if (/[0-7]/.test(escape)) {
                let octal = escape;
                while (octal.length < 3 && /[0-7]/.test(text[index + 1] || '')) {
                    index += 1;
                    octal += text[index];
                }
                result += String.fromCharCode(parseInt(octal, 8));
            } else {
                result += escape;
            }
        } else {
            result += text[index];
        }
        index += 1;
    }
    return { value: result, end: index + 1 };
}

function parseValue(text, start) {
    const character = text[start];
    if (character === '"') {
        return parseCString(text, start);
    }
    if (character === '{' || character === '[') {
        const close = character === '{' ? '}' : ']';
        const container = character === '{' ? {} : [];
        let index = start + 1;
        while (index < text.length && text[index] !== close) {
            if (text[index] === ',') {
                index += 1;
                continue;
            }
            if (character === '[' && (text[index] === '"' || text[index] === '{' || text[index] === '[')) {
                const item = parseValue(text, index);
                container.push(item.value);
                index = item.end;
                continue;
            }
            const equals = text.indexOf('=', index);
            const key = text.slice(index, equals);
            const item = parseValue(text, equals + 1);
            if (character === '{') {
                container[key] = item.value;
            } else {
                container.push({ [key]: item.value });
            }
            index = item.end;
        }
        return { value: container, end: index + 1 };
    }
    throw new Error(`MI: valore inatteso in posizione ${start}`);
}

function parseResults(text) {
    // "key=value,key=value"
    const result = {};
    let index = 0;
    while (index < text.length) {
        if (text[index] === ',') {
            index += 1;
            continue;
        }
        const equals = text.indexOf('=', index);
        if (equals < 0) break;
        const key = text.slice(index, equals);
        const item = parseValue(text, equals + 1);
        result[key] = item.value;
        index = item.end;
    }
    return result;
}

/** @returns {{kind:string, token:number|null, klass?:string, results?:object, text?:string}|null} */
function parseLine(line) {
    const match = /^(\d*)([\^*=~@&+])(.*)$/.exec(line);
    if (!match) {
        return null;
    }
    const token = match[1] ? Number(match[1]) : null;
    const [, , sigil, rest] = match;
    if (sigil === '~' || sigil === '@' || sigil === '&') {
        return { kind: { '~': 'console', '@': 'target', '&': 'log' }[sigil], token, text: parseCString(rest, 0).value };
    }
    const comma = rest.indexOf(',');
    const klass = comma < 0 ? rest : rest.slice(0, comma);
    let results = {};
    try {
        results = comma < 0 ? {} : parseResults(rest.slice(comma + 1));
    } catch {
        results = { raw: rest.slice(comma + 1) };
    }
    return { kind: { '^': 'result', '*': 'exec', '=': 'notify', '+': 'status' }[sigil], token, klass, results };
}

module.exports = { parseLine, parseValue };
