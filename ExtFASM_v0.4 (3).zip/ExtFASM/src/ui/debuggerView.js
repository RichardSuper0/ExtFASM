'use strict';

const fs = require('fs');
const path = require('path');

/**
 * Guscio HTML del pannello «Apri Debugger». Il contenuto viene disegnato da media/debugger.js con i dati che
 * l'estensione invia via postMessage: nessuno script esterno, CSP con nonce, nessun dato inserito come HTML.
 */

let clientScript = null;
function readClientScript() {
    if (clientScript === null) {
        clientScript = fs.readFileSync(path.join(__dirname, '..', '..', 'media', 'debugger.js'), 'utf8');
    }
    return clientScript;
}

const STYLE = `
:root { color-scheme: light dark; }
body { margin: 0; padding: 18px 22px; color: var(--vscode-foreground); background: var(--vscode-editor-background); font-family: var(--vscode-font-family); font-size: var(--vscode-font-size); }
header { display: flex; align-items: baseline; gap: 14px; flex-wrap: wrap; border-bottom: 1px solid var(--vscode-panel-border); padding-bottom: 10px; }
h1 { font-size: 17px; margin: 0; font-weight: 600; }
h3 { margin: 0 0 6px; font-size: 14px; }
h4 { margin: 10px 0 4px; font-size: 11px; text-transform: uppercase; color: var(--vscode-descriptionForeground); letter-spacing: 0; }
.tabs { display: flex; gap: 4px; margin: 12px 0; flex-wrap: wrap; }
.tabs button { background: transparent; color: var(--vscode-foreground); border: 1px solid transparent; border-bottom: 2px solid transparent; padding: 6px 10px; cursor: pointer; font: inherit; }
.tabs button[aria-selected="true"] { border-bottom-color: var(--vscode-focusBorder); font-weight: 600; }
button { font: inherit; }
button:focus-visible, .bar:focus-visible, tr:focus-visible, select:focus-visible { outline: 2px solid var(--vscode-focusBorder); outline-offset: 1px; }
.toolbar { display: flex; gap: 8px; flex-wrap: wrap; margin: 0 0 10px; }
.toolbar button, li.error button { background: var(--vscode-button-secondaryBackground); color: var(--vscode-button-secondaryForeground); border: 0; padding: 4px 10px; cursor: pointer; }
.toolbar button:first-child { background: var(--vscode-button-background); color: var(--vscode-button-foreground); }
button:disabled { opacity: .5; cursor: default; }
select { background: var(--vscode-dropdown-background); color: var(--vscode-dropdown-foreground); border: 1px solid var(--vscode-dropdown-border); padding: 3px 6px; }
.note { margin: 8px 0; max-width: 90ch; }
.note.warn { border-left: 3px solid var(--vscode-editorWarning-foreground); padding: 6px 10px; background: var(--vscode-textBlockQuote-background); }
.muted { color: var(--vscode-descriptionForeground); }
.mono, code { font-family: var(--vscode-editor-font-family); }
.card { border: 1px solid var(--vscode-panel-border); padding: 10px 12px; margin: 10px 0; }
.cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 12px; }
.cards .card { margin: 0; min-width: 0; }
.metric { padding: 2px 0; overflow-wrap: anywhere; }
.chart { width: 100%; max-width: 760px; height: auto; display: block; }
.chart .axis { stroke: var(--vscode-panel-border); stroke-width: 1; }
.chart .tick { fill: var(--vscode-descriptionForeground); font-size: 10px; }
.bar { fill: var(--vscode-charts-blue, #3794ff); cursor: pointer; }
.bar.worktree { fill: var(--vscode-charts-green, #89d185); }
.bar.worktree.dirty { fill: var(--vscode-charts-yellow, #cca700); }
.bar.nosize { fill: var(--vscode-charts-red, #f14c4c); }
.bar.selected { stroke: var(--vscode-focusBorder); stroke-width: 2; }
.bar.compared { stroke: var(--vscode-charts-orange, #d18616); stroke-width: 2; stroke-dasharray: 3 2; }
.scroll { overflow-x: auto; }
table { border-collapse: collapse; width: 100%; font-size: 12px; }
th, td { text-align: left; padding: 4px 8px; border-bottom: 1px solid var(--vscode-panel-border); white-space: nowrap; }
td.num { text-align: right; }
tr.selected, tr.changed { background: var(--vscode-editor-findMatchHighlightBackground); }
tr[tabindex] { cursor: pointer; }
ul.errors { list-style: none; margin: 0; padding: 0; }
li.error { border-left: 3px solid var(--vscode-editorInfo-foreground); padding: 6px 10px; margin: 6px 0; background: var(--vscode-textBlockQuote-background); }
li.error.error { border-left-color: var(--vscode-editorError-foreground); }
li.error.warning { border-left-color: var(--vscode-editorWarning-foreground); }
li.error .origin { font-size: 11px; text-transform: uppercase; color: var(--vscode-descriptionForeground); }
li.error .text { font-family: var(--vscode-editor-font-family); margin: 2px 0; overflow-wrap: anywhere; }
.chip { display: inline-block; padding: 3px 9px; border: 1px solid var(--vscode-panel-border); margin: 4px 0 8px; font-weight: 600; }
.chip.live { border-color: var(--vscode-charts-green, #89d185); }
.chip.snapshot { border-color: var(--vscode-charts-yellow, #cca700); }
.flags { display: flex; gap: 10px; flex-wrap: wrap; align-items: center; margin: 10px 0; font-family: var(--vscode-editor-font-family); }
.flag.on { font-weight: 700; }
.flag.off { color: var(--vscode-descriptionForeground); }
.flag.changed { background: var(--vscode-editor-findMatchHighlightBackground); padding: 0 3px; }
.spark { width: 100%; max-width: 360px; height: 60px; display: block; margin: 4px 0; }
.spark path { stroke-width: 1.5; }
.spark.rss path { stroke: var(--vscode-charts-blue, #3794ff); }
.spark.cpu path { stroke: var(--vscode-charts-orange, #d18616); }
@media (max-width: 520px) { body { padding: 12px; } }
@media (forced-colors: active) { .bar { fill: Highlight; } }
`;

/** @param {{nonce:string, cspSource?:string, language:string}} options */
function debuggerHtml({ nonce, language }) {
    return `<!DOCTYPE html>
<html lang="${String(language).replace(/[^A-Za-z-]/g, '')}">
<head>
<meta charset="UTF-8">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'nonce-${nonce}'; script-src 'nonce-${nonce}';">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ExtFASM</title>
<style nonce="${nonce}">${STYLE}</style>
</head>
<body>
<main id="app"></main>
<script nonce="${nonce}">${readClientScript()}</script>
</body>
</html>`;
}

module.exports = { debuggerHtml, readClientScript };
