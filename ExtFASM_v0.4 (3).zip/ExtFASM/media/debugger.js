/* Interfaccia del pannello «Apri Debugger». Gira nella webview: nessun dato viene inserito come HTML,
   tutto il testo passa da textContent. I messaggi arrivano dall'estensione (postMessage). */
(function () {
    'use strict';
    const vscode = acquireVsCodeApi();
    const state = { labels: {}, locale: 'en', tab: 'commits', file: null, commits: null, errors: null, resources: null, registers: null, selected: null, compare: null, filter: 'all' };
    const TABS = ['commits', 'errors', 'resources', 'registers'];

    const fmt = (key, params) => String(state.labels[key] !== undefined ? state.labels[key] : key)
        .replace(/\{(\w+)\}/g, (match, name) => (params && params[name] !== undefined ? String(params[name]) : match));
    const number = (value) => (value === null || value === undefined ? fmt('dbg.na') : new Intl.NumberFormat(state.locale).format(value));
    const when = (seconds) => new Intl.DateTimeFormat(state.locale, { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(seconds * 1000));
    const status = (name) => fmt(`dbg.status.${name}`);

    function el(tag, attributes, ...children) {
        const node = document.createElement(tag);
        for (const [key, value] of Object.entries(attributes || {})) {
            if (key === 'class') node.className = value;
            else if (key.startsWith('on')) node.addEventListener(key.slice(2), value);
            else if (value !== null && value !== undefined && value !== false) node.setAttribute(key, value === true ? '' : value);
        }
        for (const child of children.flat()) {
            if (child === null || child === undefined || child === false) continue;
            node.append(child.nodeType ? child : document.createTextNode(String(child)));
        }
        return node;
    }
    const svg = (tag, attributes, ...children) => {
        const node = document.createElementNS('http://www.w3.org/2000/svg', tag);
        for (const [key, value] of Object.entries(attributes || {})) node.setAttribute(key, value);
        children.forEach((child) => child && node.append(child));
        return node;
    };
    const send = (command, extra) => vscode.postMessage({ command, ...extra });
    const note = (text, cls) => el('p', { class: `note ${cls || ''}` }, text);

    // ------------------------------------------------------------------------------------------ File Commits
    function renderCommits(root) {
        const data = state.commits;
        root.append(el('div', { class: 'toolbar' }, el('button', { onclick: () => send('refreshCommits') }, fmt('dbg.refresh'))));
        if (!data) return;
        if (!data.available) {
            root.append(note(fmt(`dbg.commits.unavailable.${data.reason}`, { detail: data.detail || '' }), 'warn'));
            return;
        }
        root.append(note(fmt('dbg.commits.axis')));
        const bars = data.commits.slice().reverse().map((commit, index) => ({ kind: 'commit', commit, key: commit.hash, index }));
        const worktree = data.worktree;
        if (worktree) bars.push({ kind: 'worktree', key: 'worktree', size: worktree.size });
        const sizeOf = (bar) => (bar.kind === 'commit' ? bar.commit.size : bar.size);
        const label = (bar) => (bar.kind === 'commit' ? bar.commit.shortHash : fmt('dbg.commits.worktree'));
        const max = Math.max(1, ...bars.map((bar) => sizeOf(bar) || 0));
        const width = 720; const height = 190; const pad = 36; const barWidth = Math.max(4, Math.min(26, Math.floor((width - pad * 2) / Math.max(bars.length, 1) / 1.6)));
        const times = data.commits.map((commit) => commit.time);
        const t0 = Math.min(...times); const t1 = Math.max(...times);
        const slot = (bar, order) => {
            if (bar.kind === 'worktree') return width - pad - barWidth;
            if (t1 === t0) return pad + (width - pad * 2 - barWidth) / 2 - (bars.length > 1 ? barWidth : 0);
            return pad + ((bar.commit.time - t0) / (t1 - t0)) * (width - pad * 2 - barWidth * 3);
        };
        const chart = svg('svg', { viewBox: `0 0 ${width} ${height}`, role: 'img', class: 'chart', 'aria-label': fmt('dbg.commits.axis') });
        chart.append(svg('line', { x1: pad, y1: height - 24, x2: width - pad + 8, y2: height - 24, class: 'axis' }));
        chart.append(Object.assign(svg('text', { x: 4, y: 14, class: 'tick' }), { textContent: `${number(max)} B` }));
        chart.append(Object.assign(svg('text', { x: pad, y: height - 6, class: 'tick' }), { textContent: when(t0) }));
        const last = Object.assign(svg('text', { x: width - pad, y: height - 6, class: 'tick', 'text-anchor': 'end' }), { textContent: when(t1) });
        chart.append(last);
        bars.forEach((bar, order) => {
            const size = sizeOf(bar);
            const barHeight = size === null ? 3 : Math.max(2, (size / max) * (height - 50));
            const selected = state.selected === bar.key; const compared = state.compare === bar.key;
            const cls = `bar ${bar.kind} ${size === null ? 'nosize' : ''} ${worktree && bar.kind === 'worktree' && worktree.dirty ? 'dirty' : ''} ${selected ? 'selected' : ''} ${compared ? 'compared' : ''}`;
            const rect = svg('rect', { x: slot(bar, order), y: height - 24 - barHeight, width: barWidth, height: barHeight, class: cls, tabindex: 0, role: 'button', 'aria-label': `${label(bar)}: ${size === null ? fmt('dbg.na') : `${number(size)} B`}` });
            const choose = (event) => { if (event.shiftKey && state.selected && state.selected !== bar.key) state.compare = bar.key; else { state.selected = bar.key; state.compare = null; } render(); };
            rect.addEventListener('click', choose);
            rect.addEventListener('keydown', (event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); choose(event); } });
            rect.append(Object.assign(svg('title', {}), { textContent: `${label(bar)} · ${size === null ? fmt('dbg.na') : `${number(size)} B`}` }));
            chart.append(rect);
        });
        root.append(chart, note(fmt('dbg.commits.hint'), 'muted'));

        const find = (key) => bars.find((bar) => bar.key === key);
        const picked = find(state.selected);
        if (picked) {
            const card = el('div', { class: 'card' });
            if (picked.kind === 'commit') {
                const c = picked.commit;
                card.append(el('strong', {}, `${c.shortHash} · ${c.subject}`), el('div', { class: 'muted' }, `${c.author} · ${when(c.time)}`),
                    el('div', {}, fmt(`dbg.commits.change.${c.status}`, { path: c.oldPath || '' }), ' · ', c.path),
                    el('div', {}, `${fmt('dbg.commits.col.size')}: ${number(c.size)}`, c.delta !== null ? ` · ${fmt('dbg.commits.col.delta')}: ${c.delta > 0 ? '+' : ''}${number(c.delta)}` : ''));
            } else {
                card.append(el('strong', {}, fmt('dbg.commits.worktree')), el('div', {}, `${fmt('dbg.commits.col.size')}: ${number(worktree.size)}`),
                    el('div', {}, !worktree.exists ? fmt('dbg.commits.fileGone') : worktree.dirty ? fmt('dbg.commits.dirty') : fmt('dbg.commits.clean')));
            }
            const other = find(state.compare);
            if (other) {
                const a = sizeOf(picked); const b = sizeOf(other);
                card.append(el('div', { class: 'compare' }, a === null || b === null ? fmt('dbg.commits.compareNone') : fmt('dbg.commits.compare', { a: label(picked), b: label(other), delta: `${b - a > 0 ? '+' : ''}${number(b - a)}`, percent: a === 0 ? fmt('dbg.na') : `${(b - a) / a * 100 > 0 ? '+' : ''}${((b - a) / a * 100).toFixed(1)}%` })));
            }
            root.append(card);
        }
        if (data.truncated) root.append(note(fmt('dbg.commits.truncated', { n: data.commits.length }), 'muted'));
        root.append(note(worktree && worktree.binarySize !== null ? fmt('dbg.commits.binary', { size: number(worktree.binarySize) }) : fmt('dbg.commits.binaryNone'), 'muted'));

        const head = ['commit', 'date', 'size', 'delta', 'change', 'author', 'subject'].map((name) => el('th', { scope: 'col' }, fmt(`dbg.commits.col.${name}`)));
        const rows = data.commits.map((c) => el('tr', { class: state.selected === c.hash ? 'selected' : '', tabindex: 0, onclick: () => { state.selected = c.hash; state.compare = null; render(); } },
            el('td', {}, c.shortHash), el('td', {}, when(c.time)), el('td', { class: 'num' }, number(c.size)),
            el('td', { class: 'num' }, c.delta === null ? fmt('dbg.na') : `${c.delta > 0 ? '+' : ''}${number(c.delta)}`),
            el('td', {}, fmt(`dbg.commits.change.${c.status}`, { path: c.oldPath || '' })), el('td', {}, c.author), el('td', {}, c.subject)));
        root.append(el('div', { class: 'scroll' }, el('table', {}, el('thead', {}, el('tr', {}, head)), el('tbody', {}, rows))));
    }

    // ------------------------------------------------------------------------------------------ File Errors
    function renderErrors(root) {
        const data = state.errors;
        if (!data) return;
        const origins = ['assembler', 'static', 'syscall', 'runtime'];
        const counts = Object.fromEntries(origins.map((origin) => [origin, data.items.filter((item) => item.origin === origin).length]));
        const select = el('select', { 'aria-label': fmt('dbg.errors.all'), onchange: (event) => { state.filter = event.target.value; render(); } },
            el('option', { value: 'all', selected: state.filter === 'all' }, `${fmt('dbg.errors.all')} (${data.items.length})`),
            origins.map((origin) => el('option', { value: origin, selected: state.filter === origin }, `${fmt(`dbg.errors.origin.${origin}`)} (${counts[origin]})`)));
        root.append(el('div', { class: 'toolbar' }, select));
        const items = data.items.filter((item) => state.filter === 'all' || item.origin === state.filter);
        if (!items.length) { root.append(note(fmt('dbg.errors.none'))); return; }
        const list = el('ul', { class: 'errors' });
        for (const item of items) {
            const severity = fmt(`dbg.severity.${item.severity}`);
            const text = item.line === null ? fmt('dbg.errors.noPosition', { severity, message: item.message })
                : item.column === null ? fmt('dbg.errors.lineNoColumn', { severity, line: item.line, message: item.message })
                    : fmt('dbg.errors.line', { severity, line: item.line, column: item.column, message: item.message });
            list.append(el('li', { class: `error ${item.severity}` },
                el('div', { class: 'origin' }, fmt(`dbg.errors.origin.${item.origin}`)),
                el('div', { class: 'text' }, text),
                el('div', { class: 'muted' }, fmt('dbg.errors.reason', { reason: item.reason })),
                item.line === null ? null : el('button', { onclick: () => send('goto', { line: item.line - 1, column: item.column === null ? 0 : item.column - 1 }) }, fmt('dbg.errors.go'))));
        }
        root.append(list);
    }

    // ------------------------------------------------------------------------------------------ Resources & Performance
    function sparkline(points, key, cls) {
        const width = 320; const height = 60;
        const values = points.map((point) => point[key]).filter((value) => value !== null && value !== undefined);
        if (values.length < 2) return null;
        const max = Math.max(...values, 1); const tMax = Math.max(...points.map((point) => point.t), 1);
        const path = points.map((point, index) => `${index ? 'L' : 'M'}${(point.t / tMax) * (width - 4) + 2},${height - 4 - (point[key] / max) * (height - 8)}`).join(' ');
        return svg('svg', { viewBox: `0 0 ${width} ${height}`, class: `spark ${cls}`, role: 'img' }, svg('path', { d: path, fill: 'none' }));
    }

    function line(text, cls) { return el('div', { class: `metric ${cls || ''}` }, text); }
    const kib = (value) => (value === null || value === undefined ? fmt('dbg.na') : number(value));
    const mib = (bytes) => `${number(Math.round(bytes / 1048576))} MiB`;

    function renderResources(root) {
        const data = state.resources;
        if (!data) return;
        const hardware = data.hardware; const report = data.report;
        root.append(el('div', { class: 'toolbar' },
            el('button', { disabled: data.running, onclick: () => send('measure') }, fmt('dbg.res.measure')),
            el('button', { onclick: () => send('refreshResources') }, fmt('dbg.refresh'))));
        root.append(note(fmt('dbg.res.measureNote', { interval: data.intervalMs })));
        root.append(note(data.running ? fmt('dbg.res.running') : report ? fmt('dbg.res.runInfo', { name: report.name, wall: number(Math.round(report.wallMs)), outcome: report.outcome }) : fmt('dbg.res.notRunYet'), 'muted'));

        const grid = el('div', { class: 'cards' });
        // CPU
        const cpu = el('section', { class: 'card' }, el('h3', {}, fmt('dbg.res.cpu')));
        cpu.append(el('h4', {}, fmt('dbg.res.kind.hardware')));
        cpu.append(line(fmt('dbg.res.cpu.model', { model: hardware.cpu.model || fmt('dbg.na') })));
        cpu.append(line(hardware.cpu.physicalCores ? fmt('dbg.res.cpu.cores', { logical: hardware.cpu.logicalCores, physical: hardware.cpu.physicalCores }) : fmt('dbg.res.cpu.coresLogicalOnly', { logical: hardware.cpu.logicalCores })));
        cpu.append(line(hardware.cpu.frequencyMHz ? fmt('dbg.res.cpu.freq', { mhz: number(hardware.cpu.frequencyMHz) }) : fmt('dbg.res.cpu.noFreq')));
        cpu.append(el('h4', {}, fmt('dbg.res.kind.observed')));
        if (!report) cpu.append(line(fmt('dbg.res.notRunYet'), 'muted'));
        else if (report.cpu.status !== 'ok') cpu.append(line(`${status(report.cpu.status)}${report.cpu.status === 'not-measurable' ? ` — ${fmt('dbg.res.tooShort')}` : ''}`));
        else cpu.append(line(fmt('dbg.res.cpu.time', { ms: number(Math.round(report.cpu.sampledCpuMs)), user: number(Math.round(report.cpu.userMs)), system: number(Math.round(report.cpu.systemMs)) })),
            report.cpu.averagePercentOfOneCore === null ? null : line(fmt('dbg.res.cpu.average', { percent: report.cpu.averagePercentOfOneCore.toFixed(1) })));
        if (report && report.cpu.upperBoundMs !== null) cpu.append(line(fmt('dbg.res.cpu.upper', { ms: number(Math.round(report.cpu.upperBoundMs)) }), 'muted'));
        grid.append(cpu);
        // GPU
        const gpu = el('section', { class: 'card' }, el('h3', {}, fmt('dbg.res.gpu')), el('h4', {}, fmt('dbg.res.kind.hardware')));
        if (hardware.gpu.status !== 'ok') gpu.append(line(status(hardware.gpu.status)));
        else {
            gpu.append(line(fmt('dbg.res.gpu.devices', { count: hardware.gpu.devices.length })));
            hardware.gpu.devices.forEach((device) => {
                gpu.append(line(fmt('dbg.res.gpu.device', { name: device.name, vendor: device.vendor || fmt('dbg.na'), id: device.deviceId === null ? '?' : device.deviceId.toString(16), driver: device.driver || fmt('dbg.na') })));
                if (device.model) gpu.append(line(fmt('dbg.res.gpu.smi', { model: device.model, used: number(device.memoryUsedMiB), total: number(device.memoryTotalMiB), util: device.utilizationPercent })));
            });
            gpu.append(line(fmt('dbg.res.gpu.usage'), 'muted'));
        }
        grid.append(gpu);
        // NPU
        const npu = el('section', { class: 'card' }, el('h3', {}, fmt('dbg.res.npu')), el('h4', {}, fmt('dbg.res.kind.hardware')));
        npu.append(line(hardware.npu.status === 'absent' ? fmt('dbg.res.npu.absent') : hardware.npu.status === 'undetectable' ? fmt('dbg.res.npu.undetectable') : fmt('dbg.res.npu.found', { names: hardware.npu.devices.map((device) => `${device.name}${device.driver ? ` (${device.driver})` : ''}`).join(', ') })));
        grid.append(npu);
        // RAM
        const ram = el('section', { class: 'card' }, el('h3', {}, fmt('dbg.res.ram')), el('h4', {}, fmt('dbg.res.kind.hardware')));
        ram.append(line(fmt('dbg.res.ram.system', { total: mib(hardware.ram.totalBytes), available: mib(hardware.ram.availableBytes) })));
        ram.append(el('h4', {}, fmt('dbg.res.kind.dynamic')));
        if (!report) ram.append(line(fmt('dbg.res.notRunYet'), 'muted'));
        else if (report.memory.status !== 'ok') ram.append(line(`${status(report.memory.status)}${report.memory.status === 'not-measurable' ? ` — ${fmt('dbg.res.tooShort')}` : ''}`));
        else ram.append(line(fmt('dbg.res.ram.process', { peak: kib(report.memory.peakRssKb), last: kib(report.memory.lastRssKb) })));
        grid.append(ram);
        // Disco
        const disk = el('section', { class: 'card' }, el('h3', {}, fmt('dbg.res.disk')), el('h4', {}, fmt('dbg.res.kind.static')));
        disk.append(line(fmt('dbg.res.disk.source', { size: number(data.sourceSize) })));
        disk.append(line(data.binarySize === null ? fmt('dbg.res.disk.binaryNone') : fmt('dbg.res.disk.binary', { size: number(data.binarySize) })));
        if (hardware.disk.status === 'ok') disk.append(line(fmt('dbg.res.disk.free', { free: mib(hardware.disk.freeBytes), total: mib(hardware.disk.totalBytes) })));
        disk.append(el('h4', {}, fmt('dbg.res.kind.dynamic')));
        if (!report) disk.append(line(fmt('dbg.res.notRunYet'), 'muted'));
        else {
            disk.append(line(fmt('dbg.res.disk.files', { created: report.files.created.length, modified: report.files.modified.length, deleted: report.files.deleted.length }) + (report.files.truncated ? ` ${fmt('dbg.res.disk.filesTruncated')}` : '')));
            disk.append(line(report.io.status === 'ok' ? fmt('dbg.res.disk.io', { read: number(report.io.readBytes), written: number(report.io.writeBytes) }) : `I/O: ${status(report.io.status)}`));
        }
        grid.append(disk);
        root.append(grid);

        if (report) {
            root.append(note(fmt('dbg.res.sampling', { samples: report.samples, interval: report.intervalMs, overhead: report.overheadMs.toFixed(2) }), 'muted'));
            const rss = sparkline(report.series, 'rssKb', 'rss'); const cpuLine = sparkline(report.series, 'cpuMs', 'cpu');
            if (rss || cpuLine) root.append(el('div', { class: 'card' }, el('div', { class: 'muted' }, fmt('dbg.res.series')), rss, cpuLine));
        }
        root.append(note(fmt('dbg.res.limits'), 'muted'));
    }

    // ------------------------------------------------------------------------------------------ CPU Registers
    function renderRegisters(root) {
        const data = state.registers;
        if (!data) return;
        if (data.unsupported) { root.append(note(fmt(data.unsupported.key, data.unsupported.params), 'warn')); return; }
        const snap = data.snapshot;
        const active = Boolean(snap && snap.status === 'live');
        root.append(el('div', { class: 'toolbar' },
            el('button', { disabled: data.busy || active, onclick: () => send('regStart') }, fmt('dbg.reg.start')),
            el('button', { disabled: data.busy || !active, onclick: () => send('regStep', { count: 1 }) }, fmt('dbg.reg.step')),
            el('button', { disabled: data.busy || !active, onclick: () => send('regStep', { count: 10 }) }, fmt('dbg.reg.step10')),
            el('button', { disabled: data.busy || !active, onclick: () => send('regContinue') }, fmt('dbg.reg.continue')),
            el('button', { disabled: !snap || (!active && !data.busy), onclick: () => send('regStop') }, fmt('dbg.reg.stop'))));
        root.append(el('p', { class: `chip ${snap ? snap.status : 'unavailable'}`, role: 'status' }, fmt(`dbg.reg.status.${snap ? snap.status : 'unavailable'}`)));
        if (data.busy) root.append(note(fmt('dbg.reg.busy'), 'muted'));
        if (data.error) root.append(note(data.error, 'warn'));
        if (snap && snap.stop === 'timeout') root.append(note(fmt('dbg.reg.timeout'), 'warn'));
        if (snap && snap.registers && snap.registers.length) {
            root.append(note(fmt('dbg.reg.arch', { arch: snap.arch, version: data.gdb && data.gdb.version ? data.gdb.version : 'gdb' }), 'muted'));
            if (snap.pc) root.append(line(fmt('dbg.reg.pc', { name: snap.pc.name, hex: snap.pc.hex, sp: snap.sp ? snap.sp.name : '?', sphex: snap.sp ? snap.sp.hex : fmt('dbg.na') })));
            if (snap.instruction) root.append(line(fmt('dbg.reg.instruction', { address: snap.instruction.address, text: snap.instruction.text }), 'mono'));
            root.append(line(fmt('dbg.reg.steps', { steps: snap.steps })));
            if (snap.exit) root.append(note(fmt('dbg.reg.exit', { reason: snap.exit.reason, code: snap.exit.code === null ? fmt('dbg.na') : snap.exit.code }), 'muted'));
            const rows = snap.registers.map((reg) => el('tr', { class: reg.changed ? 'changed' : '' }, el('th', { scope: 'row' }, reg.name), el('td', { class: 'mono' }, reg.hex), el('td', { class: 'mono num' }, number(Number(reg.decimal) <= Number.MAX_SAFE_INTEGER ? Number(reg.decimal) : reg.decimal))));
            root.append(el('div', { class: 'scroll' }, el('table', {}, el('thead', {}, el('tr', {}, el('th', { scope: 'col' }, fmt('dbg.reg.col.name')), el('th', { scope: 'col' }, fmt('dbg.reg.col.hex')), el('th', { scope: 'col' }, fmt('dbg.reg.col.dec')))), el('tbody', {}, rows))));
            if (snap.flags.length) root.append(el('div', { class: 'flags' }, el('strong', {}, fmt('dbg.reg.flags')), snap.flags.map((flag) => el('span', { class: `flag ${flag.set ? 'on' : 'off'} ${flag.changed ? 'changed' : ''}` }, `${flag.name}=${flag.set ? 1 : 0}`))));
            root.append(note(fmt('dbg.reg.changed'), 'muted'));
        }
        root.append(note(fmt('dbg.reg.note'), 'muted'));
    }

    // ------------------------------------------------------------------------------------------ Struttura
    function render() {
        const app = document.getElementById('app');
        app.replaceChildren();
        if (!state.file) { app.append(note(fmt('dbg.noFile'))); return; }
        const tablist = el('div', { role: 'tablist', class: 'tabs' }, TABS.map((tab) => el('button', {
            role: 'tab', id: `tab-${tab}`, 'aria-selected': state.tab === tab ? 'true' : 'false', 'aria-controls': 'panel', tabindex: state.tab === tab ? 0 : -1,
            onclick: () => { state.tab = tab; send('tab', { tab }); render(); },
            onkeydown: (event) => {
                const index = TABS.indexOf(tab);
                const next = event.key === 'ArrowRight' ? TABS[(index + 1) % TABS.length] : event.key === 'ArrowLeft' ? TABS[(index + TABS.length - 1) % TABS.length] : null;
                if (next) { state.tab = next; send('tab', { tab: next }); render(); document.getElementById(`tab-${next}`).focus(); }
            }
        }, fmt(`dbg.tab.${tab}`))));
        const panel = el('div', { role: 'tabpanel', id: 'panel', 'aria-labelledby': `tab-${state.tab}` });
        ({ commits: renderCommits, errors: renderErrors, resources: renderResources, registers: renderRegisters })[state.tab](panel);
        app.append(el('header', {}, el('h1', {}, 'ExtFASM'), el('span', { class: 'muted' }, fmt('dbg.file', { name: state.file }))), tablist, panel);
    }

    window.addEventListener('message', (event) => {
        const message = event.data;
        if (message.type === 'init') { state.labels = message.labels; state.locale = message.locale; state.tab = message.tab || state.tab; }
        else if (message.type === 'file') { state.file = message.name; state.selected = null; state.compare = null; }
        else if (['commits', 'errors', 'resources', 'registers'].includes(message.type)) { state[message.type] = message.data; }
        render();
    });
    send('ready');
}());
