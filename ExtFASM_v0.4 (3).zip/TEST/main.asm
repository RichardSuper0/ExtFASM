format ELF64 executable 3
entry start
segment readable executable
start : 
   mov eax, 1
   mov edi, 1
   mov esi, m
   mov edx, 13
   syscall 
   mov eax, 60
   xor edi, edi
   syscall
segment readable writable
m db "Hello, World!", 10